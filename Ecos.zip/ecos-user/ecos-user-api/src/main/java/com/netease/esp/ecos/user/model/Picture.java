package com.netease.esp.ecos.user.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class Picture implements Serializable {
	private static final long serialVersionUID = 2L;
	
	private Long id;
	private String url;
	private Timestamp createTime;
	
	public Picture() {}
	
	public Picture(String url, Timestamp createTime) {
		super();
		this.url = url;
		this.createTime = createTime;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public Timestamp getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Timestamp createTime) {
		this.createTime = createTime;
	}
	
}
