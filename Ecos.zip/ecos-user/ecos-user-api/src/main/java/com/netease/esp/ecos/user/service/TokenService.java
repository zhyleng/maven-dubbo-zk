package com.netease.esp.ecos.user.service;

public interface TokenService {
	String TOKEN = "TOKEN";
	String getToken(long userId);
	boolean validate(long userId, String token);
}
