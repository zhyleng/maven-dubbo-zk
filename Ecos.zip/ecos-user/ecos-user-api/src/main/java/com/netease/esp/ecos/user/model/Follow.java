package com.netease.esp.ecos.user.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class Follow implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private Long fromUserId;
	private Long toUserId;
	private Timestamp time;
	
	public Follow() {}
	
	public Follow(Long fromUserId, Long toUserId) {
		super();
		this.fromUserId = fromUserId;
		this.toUserId = toUserId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getFromUserId() {
		return fromUserId;
	}

	public void setFromUserId(Long fromUserId) {
		this.fromUserId = fromUserId;
	}

	public Long getToUserId() {
		return toUserId;
	}

	public void setToUserId(Long toUserId) {
		this.toUserId = toUserId;
	}

	public Timestamp getTime() {
		return time;
	}

	public void setTime(Timestamp time) {
		this.time = time;
	}
	
}
