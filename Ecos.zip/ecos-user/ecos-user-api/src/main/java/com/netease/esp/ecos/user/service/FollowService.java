package com.netease.esp.ecos.user.service;

import java.util.List;

import com.netease.esp.ecos.user.model.Follow;
import com.netease.esp.ecos.user.model.dto.FollowDTO;

public interface FollowService {
	boolean follow(Follow follow);
	boolean cancelFollow(Follow follow);
	
	List<FollowDTO> getFansByUserId(long userId, int pages, int pageSize); 
	List<FollowDTO> getFollowOtherByUserId(long userId, int pages, int pageSize); 
}
