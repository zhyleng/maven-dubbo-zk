package com.netease.esp.ecos.user.service;

import java.util.List;

import com.netease.esp.ecos.user.model.dto.UserDTO;

public interface UserService {
	UserDTO addUserDTO(UserDTO userDto);
	UserDTO getUserDTO(long id);
	UserDTO getOtherUserDTO(long id, long toUserId);
	List<UserDTO> getUserDTOList(List<Long> ids);
	List<UserDTO> getPartUserDTOList(List<Long> ids);
	boolean hasRegisterByPhone(String phone);
	UserDTO getUserDTOByPhoneAndPwd(String phone, String pwd);
	boolean modifyUserPwd(long userId, String oldPwd, String newPwd);
	boolean resetUserPwd(String phone, String pwd);
	UserDTO updateUser(UserDTO userDto);
}
