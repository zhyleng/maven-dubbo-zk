package com.netease.esp.ecos.user.model.dto;

import java.io.Serializable;

import com.netease.esp.ecos.user.model.Follow;

public class FollowDTO extends Follow implements Serializable {
	private static final long serialVersionUID = 4L;
	
	private UserDTO toUserDto;
	private UserDTO fromUserDto;
	
	public UserDTO getToUserDto() {
		return toUserDto;
	}
	public void setToUserDto(UserDTO toUserDto) {
		this.toUserDto = toUserDto;
	}
	public UserDTO getFromUserDto() {
		return fromUserDto;
	}
	public void setFromUserDto(UserDTO fromUserDto) {
		this.fromUserDto = fromUserDto;
	}
	
}
