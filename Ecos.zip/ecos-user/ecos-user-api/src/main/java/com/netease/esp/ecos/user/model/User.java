package com.netease.esp.ecos.user.model;

import java.io.Serializable;

public class User implements Serializable {
	private static final long serialVersionUID = 3L;
	
	private Long id;
    private String phone;
    private String pwd;
    private String nickname;
    private Long coverUrlId;
	private Long avatarUrlId;
    private String characterSignature;
    private String gender;
    private String roles;
    private Integer cityCode;
    private Double longitude;
    private Double latitude;
    private String imId;
    private String imToken;
    private String registerTime;
	
    public User() {}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public Long getAvatarUrlId() {
		return avatarUrlId;
	}

	public void setAvatarUrlId(Long avatarUrlId) {
		this.avatarUrlId = avatarUrlId;
	}

	public String getCharacterSignature() {
		return characterSignature;
	}

	public void setCharacterSignature(String characterSignature) {
		this.characterSignature = characterSignature;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getRoles() {
		return roles;
	}

	public void setRoles(String roles) {
		this.roles = roles;
	}

	public Integer getCityCode() {
		return cityCode;
	}

	public void setCityCode(Integer cityCode) {
		this.cityCode = cityCode;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public String getImId() {
		return imId;
	}

	public void setImId(String imId) {
		this.imId = imId;
	}
    
	public Long getCoverUrlId() {
		return coverUrlId;
	}
	
	public void setCoverUrlId(Long coverUrlId) {
		this.coverUrlId = coverUrlId;
	}

	public String getImToken() {
		return imToken;
	}

	public void setImToken(String imToken) {
		this.imToken = imToken;
	}

	public String getRegisterTime() {
		return registerTime;
	}

	public void setRegisterTime(String registerTime) {
		this.registerTime = registerTime;
	}
}
