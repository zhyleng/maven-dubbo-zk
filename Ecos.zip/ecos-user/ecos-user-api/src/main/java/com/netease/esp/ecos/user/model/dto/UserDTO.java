package com.netease.esp.ecos.user.model.dto;

import java.io.Serializable;

import com.netease.esp.ecos.user.model.User;

public class UserDTO extends User implements Serializable {
	private static final long serialVersionUID = 4L;
	
	private Long userId = null;
	private String coverUrl = null;
	private String avatarUrl = null;
	private String cityName = null;
	private Integer fansNum = null;
	private Integer followOtherNum = null;
	private String token = null;
	
	private Boolean hasBeFollowed = null;
	private Boolean hasFollowed = null;
	
	private Boolean hasRegister = null;
	
	public String getAvatarUrl() {
		return avatarUrl;
	}
	
	public void setAvatarUrl(String avatarUrl) {
		this.avatarUrl = avatarUrl;
	}

	public String getCoverUrl() {
		return coverUrl;
	}

	public void setCoverUrl(String coverUrl) {
		this.coverUrl = coverUrl;
	}

	public Boolean getHasRegister() {
		return hasRegister;
	}

	public void setHasRegister(Boolean hasRegister) {
		this.hasRegister = hasRegister;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public Integer getFansNum() {
		return fansNum;
	}

	public void setFansNum(Integer fansNum) {
		this.fansNum = fansNum;
	}

	public Integer getFollowOtherNum() {
		return followOtherNum;
	}

	public void setFollowOtherNum(Integer followOtherNum) {
		this.followOtherNum = followOtherNum;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public Boolean getHasFollowed() {
		return hasFollowed;
	}

	public void setHasFollowed(Boolean hasFollowed) {
		this.hasFollowed = hasFollowed;
	}

	public Boolean getHasBeFollowed() {
		return hasBeFollowed;
	}

	public void setHasBeFollowed(Boolean hasBeFollowed) {
		this.hasBeFollowed = hasBeFollowed;
	}
	
}
