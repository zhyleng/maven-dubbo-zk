package com.netease.esp.ecos.user.model;

import java.io.Serializable;
import java.util.UUID;

public class Token implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private long userId;
	private String random;
	
	public Token() {}
	
	public Token(long userId) {
		super();
		this.userId = userId;
		this.random = UUID.randomUUID().toString();
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getRandom() {
		return random;
	}
	public void setRandom(String random) {
		this.random = random;
	}
	
}
