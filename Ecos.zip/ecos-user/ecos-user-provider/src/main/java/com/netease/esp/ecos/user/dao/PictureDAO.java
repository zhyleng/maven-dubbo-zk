package com.netease.esp.ecos.user.dao;

import org.springframework.dao.DataAccessException;

import com.netease.esp.ecos.user.model.Picture;


public interface PictureDAO {
	int insert(Picture picture) throws DataAccessException;
	Picture query(long id) throws DataAccessException;
}
