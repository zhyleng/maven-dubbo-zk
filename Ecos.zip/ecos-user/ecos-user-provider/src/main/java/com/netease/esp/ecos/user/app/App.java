package com.netease.esp.ecos.user.app;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
	public static boolean close = false;
	public static void main(String[] args) {
		System.out.println("ecos-user-provider 启动 ...");
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(new String[] {"classpath:config/spring.xml", "classpath:config/dubbo.xml"});
		context.start();
		System.out.println("ecos-user-provider 运行中 ...");
		
//		UserService us = (UserService)context.getBean("userService");
//		List<Long> ids = new ArrayList<Long>();
//		ids.add(1l);
//		ids.add(2l);
//		ids.add(3l);
//		System.out.println(JSON.toJSONString(us.getUserDTOList(ids)));

		Runtime r = Runtime.getRuntime();
		System.out.println("free mem:" + r.freeMemory()/(1024*1024) + "M");
		System.out.println("total mem:" + r.totalMemory()/(1024*1024) + "M");
		System.out.println("max mem:" + r.maxMemory()/(1024*1024) + "M");
		// 为保证服务一直开着，利用输入流的阻塞来模拟
		while(!close) {
			
		}
		context.close();
	}
}
