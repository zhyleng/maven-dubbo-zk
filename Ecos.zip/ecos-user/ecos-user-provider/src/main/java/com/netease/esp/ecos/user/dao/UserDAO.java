package com.netease.esp.ecos.user.dao;


import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.dao.DataAccessException;

import com.netease.esp.ecos.user.model.User;


public interface UserDAO {
	int insert(User user) throws DataAccessException;
	User query(long id) throws DataAccessException;
	List<User> queryByIds(@Param("ids") List<Long> ids) throws DataAccessException;
	List<User> queryPartInfoByIds(@Param("ids") List<Long> ids) throws DataAccessException;
	boolean queryIsExistByPhone(@Param("phone") String phone) throws DataAccessException;
	User queryByPhoneAndPwd(@Param("phone") String phone, @Param("pwd") String pwd) throws DataAccessException;
	
	boolean updatePwdById(@Param("id") long id, @Param("oldPwd") String oldPwd, @Param("newPwd") String newPwd) throws DataAccessException;
	boolean updatePwdByPhone(@Param("phone") String phone, @Param("pwd") String pwd) throws DataAccessException;

	boolean update(User user) throws DataAccessException;
}
