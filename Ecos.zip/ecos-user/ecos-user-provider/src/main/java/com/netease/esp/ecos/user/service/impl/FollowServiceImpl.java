package com.netease.esp.ecos.user.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.netease.esp.ecos.user.dao.FollowDAO;
import com.netease.esp.ecos.user.dao.PictureDAO;
import com.netease.esp.ecos.user.dao.UserDAO;
import com.netease.esp.ecos.user.model.Follow;
import com.netease.esp.ecos.user.model.User;
import com.netease.esp.ecos.user.model.dto.FollowDTO;
import com.netease.esp.ecos.user.model.dto.UserDTO;
import com.netease.esp.ecos.user.service.FollowService;
import com.netease.esp.ecos.util.EntityDtoConverter;

@Service("followService")
@Transactional(propagation=Propagation.REQUIRED)
public class FollowServiceImpl implements FollowService {
	//	private Logger logger = Logger.getLogger(this.getClass());
	@Resource
	private FollowDAO followDAO;
	@Resource
	private UserDAO userDAO;
	@Autowired
	PictureDAO pictureDAO;

	@Override
	public boolean follow(Follow follow) {
		// TODO Auto-generated method stub
		boolean result = true;
		if(followDAO.queryExists(follow.getFromUserId(), follow.getToUserId())) {
			result = false;
		} else {
			followDAO.insert(follow);
		}

		return result;
	}

	@Override
	public boolean cancelFollow(Follow follow) {
		// TODO Auto-generated method stub
		boolean result = true;
		if(!followDAO.queryExists(follow.getFromUserId(), follow.getToUserId())) {
			result = false;
		} else {
			followDAO.delete(follow.getFromUserId(), follow.getToUserId());
		}
		return result;
	}

	@Override
	public List<FollowDTO> getFansByUserId(long userId, int pages, int pageSize) {
		// TODO Auto-generated method stub
		List<Follow> follows = followDAO.queryFansFollow(userId, (pages-1)*pageSize, pageSize);
		if(follows == null || follows.size() == 0) {
			return null;
		}

		List<FollowDTO> fansFollowDtos = new ArrayList<FollowDTO>();
		List<Long> ids = new ArrayList<Long>();
		for(Follow follow : follows) {
			ids.add(follow.getFromUserId());
		}
		FollowDTO followDto = null;
		UserDTO fromUserDto = null;
		List<User> users = userDAO.queryByIds(ids);
		for(Follow follow : follows) {
			for(User user : users) {
				if(user.getId().equals(follow.getFromUserId())) {
					followDto = new FollowDTO();
					fromUserDto = new UserDTO();
					EntityDtoConverter.entityConvertDto(follow, followDto);
					EntityDtoConverter.entityConvertDto(user, fromUserDto);

					String avatarUrl = null;
					try {
						if(user.getAvatarUrlId() != null) {
							avatarUrl = pictureDAO.query(user.getAvatarUrlId()).getUrl();
						}
					} catch (Exception e) {}

					fromUserDto.setAvatarUrl(avatarUrl);
					fromUserDto.setUserId(user.getId());
					followDto.setFromUserDto(fromUserDto);
					fansFollowDtos.add(followDto);
				}
			}
		}

		return fansFollowDtos;
	}

	@Override
	public List<FollowDTO> getFollowOtherByUserId(long userId, int pages, int pageSize) {
		// TODO Auto-generated method stub
		List<Follow> follows = followDAO.queryFollowOther(userId, (pages-1)*pageSize, pageSize);
		if(follows == null || follows.size() == 0) {
			return null;
		}

		List<FollowDTO> followDtos = new ArrayList<FollowDTO>();
		List<Long> ids = new ArrayList<Long>();
		for(Follow follow : follows) {
			ids.add(follow.getToUserId());
		}
		FollowDTO followDto = null;
		UserDTO toUserDto = null;
		List<User> users = userDAO.queryPartInfoByIds(ids);
		for(Follow follow : follows) {
			for(User user : users) {
				if(user.getId().equals(follow.getToUserId())) {
					followDto = new FollowDTO();
					toUserDto = new UserDTO();
					EntityDtoConverter.entityConvertDto(follow, followDto);
					EntityDtoConverter.entityConvertDto(user, toUserDto);

					String avatarUrl = null;
					try {
						if(user.getAvatarUrlId() != null) {
							avatarUrl = pictureDAO.query(user.getAvatarUrlId()).getUrl();
						}
					} catch (Exception e) {}

					toUserDto.setAvatarUrl(avatarUrl);
					toUserDto.setUserId(user.getId());
					followDto.setToUserDto(toUserDto);
					followDtos.add(followDto);
				}
			}
		}

		return followDtos;
	}

}
