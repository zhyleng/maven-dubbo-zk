package com.netease.esp.ecos.user.service.impl;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.alibaba.fastjson.JSON;
import com.netease.esp.ecos.redis.RedisTool;
import com.netease.esp.ecos.user.model.Token;
import com.netease.esp.ecos.user.service.TokenService;
import com.netease.esp.ecos.user.util.MD5;
import com.netease.esp.ecos.util.AES;

@Service("tokenService")
public class TokenServiceImpl implements TokenService {
	private Logger logger = Logger.getLogger(this.getClass());
	private static final long EXPIRE_DAYS = 14*24*60*60*1000;//14天
	private static final long UPDATE_INTERVAL = 1*24*60*60*1000;//1天
//	private static final long EXPIRE_DAYS = 10*1000;
	
	private String getTokenKey(long userId) {
		return MD5.md5(String.valueOf(userId));
	}
	
	private String getTokenExpireTimeKey(long userId) {
		return MD5.md5(userId+"time");
	}

	@Override
	public String getToken(long userId) {
		// TODO Auto-generated method stub
		String tokenKey = getTokenKey(userId);
		String tokenExpireTimeKey = getTokenExpireTimeKey(userId);
		
		RedisTool<String, String> redisTool = new RedisTool<String, String>();
		Token token = new Token(userId);
		String tokenString = AES.encrypt(JSON.toJSONString(token));
		boolean result1 = redisTool.set(tokenKey, tokenString);
		boolean result2 = redisTool.set(tokenExpireTimeKey, String.valueOf(System.currentTimeMillis()).toString());
		logger.debug("redis token :" + tokenString);
		if(!result1 || !result2) {
			logger.error("error \tresult1: " + result1 + "\tresult2: " + result2);
			tokenString = getToken(userId);
		}
		return tokenString;
	}

	@Override
	public boolean validate(long userId, String token) {
		// TODO Auto-generated method stub
		if(StringUtils.isEmpty(token)) {
			return false;
		}
		
		String tokenKey = getTokenKey(userId);
		String tokenExpireTimeKey = getTokenExpireTimeKey(userId);
		
		RedisTool<String, String> redisTool = new RedisTool<String, String>();
		String serverTokenString = redisTool.get(tokenKey);
		String serverTokenExpireTimeString = redisTool.get(tokenExpireTimeKey);
		/** 数据库里应该存一份*/
		if(StringUtils.isEmpty(serverTokenString) || StringUtils.isEmpty(serverTokenExpireTimeString)) {
			return false;
		}
		
		long createTime = 0;
		try {
			createTime = Long.parseLong(serverTokenExpireTimeString);
		} catch (Exception e) {
			/** 解析失败验证失败*/
			return false;
		}
		
		/** 验证token */
		if(!serverTokenString.equals(token)) {
			return false;
		}
		
		/** 验证过期时间  */
		long timeDiff = System.currentTimeMillis() - createTime;
		if(timeDiff > EXPIRE_DAYS) {
			return false;
		}
		
		if(timeDiff > UPDATE_INTERVAL) {
			boolean result = redisTool.set(tokenExpireTimeKey, String.valueOf(System.currentTimeMillis()).toString());
			logger.debug("update expire :" + result);
		}
		
		return true;
	}
	
}
