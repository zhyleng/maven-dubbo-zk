package com.netease.esp.ecos.user.util;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

public class LBSService {
	private static final String BAIDU_AK = "D2e7489659aa6c0a5baf27646c93e82e";
	private int status = -1;
	private int cityCode;
	private String country;
	private String city;
	private String district;
	private String street;
	private String formattedAddress;
	private double longitude;
	private double latitude;
	
	public static void main(String[] args) {
		LBSService lbs = new LBSService(120, 30);
		System.out.println(lbs.getStatus());
		if(lbs.getStatus() == 0) {
			System.out.println(lbs.getCity());
			System.out.println(lbs.getCountry());
			System.out.println(lbs.getCityCode());
			System.out.println(lbs.getDistrict());
			System.out.println(lbs.getFormattedAddress());
			System.out.println(lbs.getStreet());
			
		} 
	}
	
	public LBSService(double postLongitude, double postLatitude) {
		this.longitude = postLongitude;
		this.latitude = postLatitude;
		String uri = "http://api.map.baidu.com/geocoder/v2/?ak=" + BAIDU_AK + "&location=" + postLatitude + "," + postLongitude + "&output=json";
		String data = null;
		try {
			HttpClient client = new HttpClient();
			GetMethod get = new GetMethod(uri);
			client.executeMethod(get);
			data = get.getResponseBodyAsString();
			data = data.trim();
			
			JSONObject jsonObject = JSON.parseObject(data);
			this.status = jsonObject.getIntValue("status");
			if(this.status == 0) {
				JSONObject result = jsonObject.getJSONObject("result");
				JSONObject addressComponent = result.getJSONObject("addressComponent");
				this.cityCode = result.getIntValue("cityCode");
				this.formattedAddress = result.getString("formatted_address");
				this.country = addressComponent.getString("country");
				this.city = addressComponent.getString("city");
				this.district = addressComponent.getString("district");
				this.street = addressComponent.getString("street");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getFormattedAddress() {
		return formattedAddress;
	}

	public void setFormattedAddress(String formattedAddress) {
		this.formattedAddress = formattedAddress;
	}

	public void setLatitude(long latitude) {
		this.latitude = latitude;
	}

	public int getCityCode() {
		return cityCode;
	}

	public void setCityCode(int cityCode) {
		this.cityCode = cityCode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}
	
}
