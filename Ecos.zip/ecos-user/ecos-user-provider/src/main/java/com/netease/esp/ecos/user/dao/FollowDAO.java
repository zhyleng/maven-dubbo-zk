package com.netease.esp.ecos.user.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.dao.DataAccessException;

import com.netease.esp.ecos.user.model.Follow;


public interface FollowDAO {
	int insert(Follow follow) throws DataAccessException;
	int delete(@Param("fromUserId")long fromUserId, @Param("toUserId")long toUserId) throws DataAccessException;
	boolean queryExists(@Param("fromUserId")long fromUserId, @Param("toUserId")long toUserId) throws DataAccessException;
	Follow query(@Param("fromUserId")long fromUserId, @Param("toUserId")long toUserId) throws DataAccessException;
	int queryFansNum(@Param("userId")long userId) throws DataAccessException;
	int queryFollowOtherNum(@Param("userId")long userId) throws DataAccessException;
	List<Follow> queryFansFollow(@Param("userId")long userId, @Param("offset")int offset, @Param("size")int size) throws DataAccessException;
	List<Follow> queryFollowOther(@Param("userId")long userId, @Param("offset")int offset, @Param("size")int size) throws DataAccessException;
}
