package com.netease.esp.ecos.user.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.alibaba.fastjson.JSON;
import com.netease.esp.ecos.user.dao.FollowDAO;
import com.netease.esp.ecos.user.dao.PictureDAO;
import com.netease.esp.ecos.user.dao.UserDAO;
import com.netease.esp.ecos.user.model.Picture;
import com.netease.esp.ecos.user.model.User;
import com.netease.esp.ecos.user.model.dto.UserDTO;
import com.netease.esp.ecos.user.service.UserService;
import com.netease.esp.ecos.user.util.MD5;
import com.netease.esp.ecos.user.yxim.IMRequest;
import com.netease.esp.ecos.user.yxim.IMResponse;
import com.netease.esp.ecos.util.EntityDtoConverter;

@Service("userService")
@Transactional(propagation=Propagation.REQUIRED)
public class UserServiceImpl implements UserService {
	private Logger logger = Logger.getLogger(this.getClass());

	@Autowired
	UserDAO userDAO;
	@Autowired
	PictureDAO pictureDAO;
	@Autowired
	FollowDAO followDAO;

	/**
	 * 增加用户
	 */
	@Override
	public UserDTO addUserDTO(UserDTO userDto) {
		// TODO Auto-generated method stub
		if(userDto == null) {
			return null;
		}
		
		User user = new User();
		EntityDtoConverter.DtoConvertEntity(userDto, user);
		logger.debug(JSON.toJSONString(user));

		/** 如果有头像保存头像 */
		String avatarUrl = userDto.getAvatarUrl();
		if(avatarUrl != null) {
			Picture picture = new Picture(avatarUrl, new Timestamp(System.currentTimeMillis()));
			pictureDAO.insert(picture);
			user.setAvatarUrlId(picture.getId());
		}

		IMResponse resp = IMRequest.createAccount(MD5.md5(userDto.getPhone()+"soce", 16), userDto.getNickname(), userDto.getAvatarUrl(), MD5.md5(user.getPwd()+"soce"));
		user.setImId(resp.getAccid());
		user.setImToken(resp.getToken());

		userDAO.insert(user);
		userDto = getUserDTO(user.getId());
		return userDto;
	}

	/**
	 * 获取用户详情信息
	 * @return null表示用户不存在
	 */
	@Override
	public UserDTO getUserDTO(long id) {
		// TODO Auto-generated method stub
		UserDTO userDto = new UserDTO();
		User user = userDAO.query(id);
		if(user == null) {
			return null;
		}
		EntityDtoConverter.entityConvertDto(user, userDto);

		String coverUrl = null;
		String avatarUrl = null;
		try {
			if(user.getAvatarUrlId() != null) {
				avatarUrl = pictureDAO.query(user.getAvatarUrlId()).getUrl();
			}
			if(user.getCoverUrlId() != null) {
				coverUrl = pictureDAO.query(user.getCoverUrlId()).getUrl();
			}
			if(user.getCityCode() != null) {
				
			}
		} catch (Exception e) {}
		userDto.setUserId(user.getId());
		userDto.setAvatarUrl(avatarUrl);
		userDto.setCoverUrl(coverUrl);
		userDto.setFansNum(followDAO.queryFansNum(id));
		userDto.setFollowOtherNum(followDAO.queryFollowOtherNum(id));
		
		return userDto;
	}
	
	/**
	 * 获取用户详情信息
	 * @return null表示用户不存在
	 */
	@Override
	public UserDTO getOtherUserDTO(long id, long toUserId) {
		// TODO Auto-generated method stub
		UserDTO userDto = new UserDTO();
		User user = userDAO.query(toUserId);
		if(user == null) {
			return null;
		}
		EntityDtoConverter.entityConvertDto(user, userDto);
		
		String coverUrl = null;
		String avatarUrl = null;
		try {
			if(user.getAvatarUrlId() != null) {
				avatarUrl = pictureDAO.query(user.getAvatarUrlId()).getUrl();
			}
			if(user.getCoverUrlId() != null) {
				coverUrl = pictureDAO.query(user.getCoverUrlId()).getUrl();
			}
			if(user.getCityCode() != null) {
				
			}
		} catch (Exception e) {}
		userDto.setUserId(user.getId());
		userDto.setAvatarUrl(avatarUrl);
		userDto.setCoverUrl(coverUrl);
		userDto.setFansNum(followDAO.queryFansNum(toUserId));
		userDto.setFollowOtherNum(followDAO.queryFollowOtherNum(toUserId));
		

		boolean hasFollowed = followDAO.queryExists(id, toUserId);
		boolean hasBeFollowed = followDAO.queryExists(toUserId, id);
		userDto.setHasFollowed(hasFollowed);
		userDto.setHasBeFollowed(hasBeFollowed);
		
		return userDto;
	}

	@Override
	public List<UserDTO> getUserDTOList(List<Long> ids) {
		// TODO Auto-generated method stub
		if(ids == null || ids.size() == 0) {
			return null;
		}
		List<UserDTO> userDtos = new ArrayList<UserDTO>();
		List<User> users = userDAO.queryByIds(ids);
		UserDTO userDto = null;
		for(User user : users) {
			userDto = new UserDTO();
			EntityDtoConverter.entityConvertDto(user, userDto);

			String coverUrl = null;
			String avatarUrl = null;
			try {
				if(user.getAvatarUrlId() != null) {
					avatarUrl = pictureDAO.query(user.getAvatarUrlId()).getUrl();
				}
				if(user.getCoverUrlId() != null) {
					coverUrl = pictureDAO.query(user.getCoverUrlId()).getUrl();
				}
			} catch (Exception e) {}
			
			userDto.setUserId(user.getId());
			userDto.setAvatarUrl(avatarUrl);
			userDto.setCoverUrl(coverUrl);
			userDto.setFansNum(followDAO.queryFansNum(userDto.getId()));
			userDto.setFollowOtherNum(followDAO.queryFollowOtherNum(userDto.getId()));
			
			userDtos.add(userDto);
		}
		
		return userDtos;
	}

	/**
	 * 获取部分信息
	 * `id`, `nickname`, `avatarUrlId`, `characterSignature`, `gender`, `roles`
	 * avatarUrl
	 */
	@Override
	public List<UserDTO> getPartUserDTOList(List<Long> ids) {
		if(ids == null || ids.size() == 0) {
			return null;
		}
		List<UserDTO> userDtos = new ArrayList<UserDTO>();
		List<User> users = userDAO.queryPartInfoByIds(ids);
		if(users == null) {
			return null;
		}
		
		UserDTO userDto = null;
		for(User user : users) {
			userDto = new UserDTO();
			EntityDtoConverter.entityConvertDto(user, userDto);

			String avatarUrl = null;
			try {
				if(user.getAvatarUrlId() != null) {
					avatarUrl = pictureDAO.query(user.getAvatarUrlId()).getUrl();
				}
			} catch (Exception e) {}
			
			userDto.setAvatarUrl(avatarUrl);
			userDto.setUserId(user.getId());
			userDtos.add(userDto);
		}
		return userDtos;
	}
	
	/** 
	 * 手机号是否注册
	 */
	@Override
	public boolean hasRegisterByPhone(String phone) {
		if(StringUtils.isEmpty(phone)) {
			return false;
		}
		
		boolean hasRegister = userDAO.queryIsExistByPhone(phone);
		return hasRegister;
	}

	/**
	 * 通过手机号和密码获取用户
	 */
	@Override
	public UserDTO getUserDTOByPhoneAndPwd(String phone, String pwd) {
		User user = userDAO.queryByPhoneAndPwd(phone, pwd);
		/** 用户密码错误 */
		if(user == null) {
			return null;
		}
		/** 获取用户DTO */
		UserDTO userDto = getUserDTO(user.getId());
		return userDto;
	}

	/**
	 * 修改密码
	 * @return false表示之前的密码错误
	 */
	@Override
	public boolean modifyUserPwd(long userId, String oldPwd, String newPwd) {
		// TODO Auto-generated method stub
		return userDAO.updatePwdById(userId, oldPwd, newPwd);
	}

	/**
	 * 重置密码
	 */
	@Override
	public boolean resetUserPwd(String phone, String pwd) {
		return userDAO.updatePwdByPhone(phone, pwd);
	}

	/**
	 * 更新用户信息
	 */
	@Override
	public UserDTO updateUser(UserDTO userDto) {
		User user = new User();
		EntityDtoConverter.DtoConvertEntity(userDto, user);
		if(userDto.getAvatarUrl() != null) {
			Picture picture = new Picture(userDto.getAvatarUrl() , new Timestamp(System.currentTimeMillis()));
			pictureDAO.insert(picture);
			user.setAvatarUrlId(picture.getId());
		}
		if(userDto.getCoverUrl() != null) {
			Picture picture = new Picture(userDto.getCoverUrl() , new Timestamp(System.currentTimeMillis()));
			pictureDAO.insert(picture);
			user.setCoverUrlId(picture.getId());
		}
		userDAO.update(user);
		userDto = getUserDTO(user.getId());
		return userDto;
	}

}
