package com.netease.esp.ecos.redis;

import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSON;

public class RedisApp {

	/*public static void main(String[] args) {
		Jedis jedis = new Jedis("10.166.224.57", 6379);
		jedis.set("foo", "bar");
		String value = jedis.get("foo");
		System.out.println(value);
	}*/
	
	public static void main(String[] args) {
		/*List<String> stringList = new ArrayList<String>();
		stringList.add("test");
		stringList.add("test2");*/
		String valueString = "I am value";
		String keyString = "I am key";
		RedisTool<String, String> redisStringTool = new RedisTool<String, String>();
		redisStringTool.set(keyString, valueString, 30);
		String resultString = redisStringTool.get(keyString);
		System.out.println("get:" + resultString);
//		RedisTool<String, Map<String, String>> redisTool1 = new RedisTool<String, Map<String, String>>();
//		Map<String, String> stringList = new HashMap<String, String>();
//		stringList.put("test", "tt");
//		redisTool1.set("poi", stringList);
		/*RedisTool<String, String> redisTool = new RedisTool<String, String>();
		redisTool.set("foz", "fod", 100);
		String resultList = redisTool.get("foz");*/
//		Map<String, String> resultList = redisTool1.get("poi");
//		System.out.println(JSON.toJSONString(resultList));
//		redisTool1.delete("fof");
	}

}
