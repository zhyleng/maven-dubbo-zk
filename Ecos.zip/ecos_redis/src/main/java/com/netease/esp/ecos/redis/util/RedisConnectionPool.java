package com.netease.esp.ecos.redis.util;


import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

public class RedisConnectionPool {

	public static JedisPool jedisPool = null;
	
	public static JedisPool getPool() {
		if (null == jedisPool) {
			synchronized(JedisPool.class) {
				if (null == jedisPool) {
					JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
					jedisPoolConfig.setMaxTotal(500);
					jedisPoolConfig.setMaxIdle(5);
					jedisPoolConfig.setMaxWaitMillis(1000 * 10);
					jedisPoolConfig.setTestOnBorrow(true);
					jedisPool = new JedisPool("10.166.224.57", 6379);
				}
			}
		}
		return jedisPool;
	}
	
	public static void returnResourceToPool(JedisPool jedisPool, Jedis jedis) {
		if (null != jedis && null != jedisPool) {
			jedisPool.returnResource(jedis);
		}
	}
}
