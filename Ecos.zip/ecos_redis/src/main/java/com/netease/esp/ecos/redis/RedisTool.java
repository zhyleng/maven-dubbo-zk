package com.netease.esp.ecos.redis;

import com.netease.esp.ecos.redis.dao.RedisDAO;
import com.netease.esp.ecos.redis.dao.impl.RedisDAOImpl;
import com.netease.esp.ecos.redis.util.SerializeUtil;

public class RedisTool<K, V> {


	public boolean set(K key, V value) {
		return set(key, value, -1);
	}
	
	public boolean set(K key, V value, int seconds) {
		boolean result = false;
		RedisDAO redisDAO = new RedisDAOImpl();
		if (seconds < 0) {
			result = redisDAO.set(SerializeUtil.serialize(key), SerializeUtil.serialize(value));
		} else {
			result = redisDAO.set(SerializeUtil.serialize(key), SerializeUtil.serialize(value), seconds);
		}
		
		if (false == result) {
			return false;
		}
		
		return result;
	}

	@SuppressWarnings("unchecked")
	public V get(K key) {
		V value = null;
		
		RedisDAO redisDAO = new RedisDAOImpl();
		byte[] resultBytes = redisDAO.get(SerializeUtil.serialize(key));
		if (null == resultBytes) {
			return null;
		}
		value = (V)SerializeUtil.unserialize(resultBytes);
		return value;
	}

	public boolean delete(K key) {
		boolean result = false;
		RedisDAO redisDAO = new RedisDAOImpl();
		result = redisDAO.delete(SerializeUtil.serialize(key));
		if (false == result) {
			return false;
		}
		return result;
	}
}
