package com.netease.esp.ecos.redis.dao;

public interface RedisDAO {
	public boolean set(byte[] key, byte[] value);
	public boolean set(byte[] key, byte[] value, int seconds);
	public byte[] get(byte[] key);
	public boolean delete(byte[] key);
}
