package com.netease.esp.ecos.redis.dao.impl;

import org.apache.log4j.Logger;

import com.netease.esp.ecos.redis.dao.RedisDAO;
import com.netease.esp.ecos.redis.util.RedisConnectionPool;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

public class RedisDAOImpl implements RedisDAO {
	private static Logger logger = Logger.getLogger(RedisDAO.class);

	@Override
	public boolean set(byte[] key, byte[] value) {
		return set(key, value, -1);
	}
	
	@Override
	public boolean set(byte[] key, byte[] value, int seconds) {
		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = RedisConnectionPool.getPool();
			jedis = pool.getResource();
			jedis.set(key, value);
			if (seconds > 0)
				jedis.expire(key, seconds);
		} catch(Exception e) {
			pool.returnBrokenResource(jedis);
			logger.error(e.getMessage());
			return false;
		} finally {
			try {
				RedisConnectionPool.returnResourceToPool(pool, jedis);
			} catch (Exception e) {
				logger.error(e.getMessage());
			}
		}
		return true;
	}

	@Override
	public byte[] get(byte[] key) {
		byte[] value = null;
		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = RedisConnectionPool.getPool();
			jedis = pool.getResource();
			value = jedis.get(key);
		} catch (Exception e) {
			pool.returnBrokenResource(jedis);
			logger.error(e.getMessage());
		} finally {
			try {
				RedisConnectionPool.returnResourceToPool(pool, jedis);
			} catch (Exception e) {
				logger.error(e.getMessage());
			}
		}
		return value;
	}

	@Override
	public boolean delete(byte[] key) {
		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = RedisConnectionPool.getPool();
			jedis = pool.getResource();
			jedis.del(key);
		} catch (Exception e) {
			pool.returnBrokenResource(jedis);
			logger.error(e.getMessage());
			return false;
		} finally {
			RedisConnectionPool.returnResourceToPool(pool, jedis);
		}
		return true;
	}

}
