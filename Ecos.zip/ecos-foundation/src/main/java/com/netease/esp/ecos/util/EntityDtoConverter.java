package com.netease.esp.ecos.util;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class EntityDtoConverter {
	public static void main(String[] args) {
		//		User user = new User();
		//		UserDTO userDto = new UserDTO();
		//		userDto.setPhone("123");
		//		DtoConvertEntity(userDto, user);
		//		System.out.println(JSON.toJSONString(user));
	}

	public static Object DtoConvertEntity(Object objDto, Object obj) {
		Class<?> clazz = obj.getClass();
		Class<?> dtoClazz = objDto.getClass();
		Field[] fields = clazz.getDeclaredFields();
		for (Field f : fields) {
			String fieldName = f.getName();
			String upperName = Character.toUpperCase(fieldName.charAt(0))+ fieldName.substring(1);
			String getterName = "get" + upperName;
			String setterName = "set" + upperName;
			Method objSetterMethod = null;
			Method objDtoGetterMethod = null;
			try {
				objSetterMethod = clazz.getMethod(setterName, f.getType());
				objDtoGetterMethod = dtoClazz.getMethod(getterName);
			} catch (NoSuchMethodException e) {
			}
			if (objSetterMethod != null && objDtoGetterMethod != null) {
				try {
					objSetterMethod.invoke(obj, objDtoGetterMethod.invoke(objDto));
				} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return obj;
	}

	public static Object entityConvertDto(Object obj, Object objDto) {
		Class<?> clazz = obj.getClass();
		Class<?> dtoClazz = objDto.getClass();
		Field[] fields = clazz.getDeclaredFields();
		for (Field f : fields) {
			String fieldName = f.getName();
			String upperName = Character.toUpperCase(fieldName.charAt(0))+ fieldName.substring(1);
			String getterName = "get" + upperName;
			String setterName = "set" + upperName;
			Method objGetterMethod = null;
			Method objDtoSetterMethod = null;
			try {
				objGetterMethod = clazz.getMethod(getterName);
				objDtoSetterMethod = dtoClazz.getMethod(setterName, f.getType());
			} catch (NoSuchMethodException e) {
			}
			if (objGetterMethod != null && objDtoSetterMethod != null) {
				try {
					objDtoSetterMethod.invoke(objDto, objGetterMethod.invoke(obj));
				} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return objDto;
	}

}
