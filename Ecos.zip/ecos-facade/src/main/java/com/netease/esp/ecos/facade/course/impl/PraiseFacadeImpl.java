package com.netease.esp.ecos.facade.course.impl;

import com.netease.esp.ecos.course.model.Praise;
import com.netease.esp.ecos.course.service.PraiseService;
import com.netease.esp.ecos.facade.course.PraiseFacade;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service("praiseFacade")
public class PraiseFacadeImpl implements PraiseFacade {
    Logger logger = Logger.getLogger(this.getClass());
    @Resource
    PraiseService praiseService;


    @Override
    public Praise createPraise(long userId,int type, long refid) {
        Praise praise = new Praise();
        praise.setUserId(userId);
        praise.setType(type);
        praise.setRefId(refid);

        long id  = praiseService.createPraise(praise).getId();
        Praise result = praiseService.getPraiseById(id);
        return result;
    }

    @Override
    public Praise cancelPraise(long userId,int type, long refid) {
        Praise result =null;

        try {
            Praise praise = new Praise();
            praise.setUserId(userId);
            praise.setType(type);
            praise.setRefId(refid);
            result=praiseService.deletePraiseByContent(praise);

            return result;
        }catch (Exception e){
            logger.error("cancelPraise error！");
            return  result;
        }
    }

    @Override
    public boolean judgePraiseOrNot(long userId, int type, long refid) {
        if(praiseService.getPraiseByContent(userId,type,refid)==1){
            return true;
        }else {
            return false;
        }
    }
}
