package com.netease.esp.ecos.facade.csr;

import java.util.List;

import com.netease.esp.ecos.csr.model.Recruit;
import com.netease.esp.ecos.csr.model.RecruitDis;
import com.netease.esp.ecos.csr.model.UserForRecruit;

/**
 * RecruitFacade
 */
public interface RecruitFacade {
	public Recruit createRecruit(Long userId, Double price, String description, Long shareId, String priceUnit,
			String coverUrl, String title, Long recruitType);
	public RecruitDis getDetailRecruit(Long recruitId,Long userId);
	public UserForRecruit getUserForRecruit(Long userId);
	public List<RecruitDis> getDetailList(Long userId, Boolean isMyself, Long recruitType, Long cityCode, String sortRule, Long pageSize,Long pages);
}