package com.netease.esp.ecos.facade.csr.impl;

import java.util.List;
import javax.annotation.Resource;
import org.springframework.stereotype.Service;
import com.netease.esp.ecos.csr.model.Comment;
import com.netease.esp.ecos.csr.model.ShareComment;
import com.netease.esp.ecos.csr.service.CommentService;
import com.netease.esp.ecos.facade.csr.CommentFacade;

/**
 * 用户comment
 *
 */
@Service("commentFacade")
public class CommentFacadeImpl implements CommentFacade{
	@Resource
    CommentService commentService;

	@Override
	public Comment creatComment(Long commentType, Long commentTypeId, String content, Long parentId,Long userId) {
		// TODO Auto-generated method stub
		return commentService.creatComment(commentType, commentTypeId, content, parentId,userId);
	}
	@Override
	public Comment getCommentContent(Long commentId) {
		// TODO Auto-generated method stub
		return commentService.getCommentContent(commentId);
	}

	@Override
	public Comment deleteComment(Long commentId) {
		// TODO Auto-generated method stub
		return commentService.deleteComment(commentId);
	}
	@Override
	public String getAvatarUrlByUserId(Long userId) {
		// TODO Auto-generated method stub
		return commentService.getAvatarUrlByUserId(userId);
	}
	@Override
	public String getNicknameByUserId(Long userId) {
		// TODO Auto-generated method stub
		return commentService.getUserNameByUserId(userId);
	}
	@Override
	public List<ShareComment> getComments(Long type, Long shareId,Long pageSize,Long pages) {
		// TODO Auto-generated method stub
		return commentService.getComments(type, shareId,pageSize,pages);
	}
	
}
