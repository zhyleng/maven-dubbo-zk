package com.netease.esp.ecos.facade.activity.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.netease.esp.ecos.activity.model.Activity;
import com.netease.esp.ecos.activity.model.ActivityDTO;
import com.netease.esp.ecos.activity.model.City;
import com.netease.esp.ecos.activity.model.Picture;
import com.netease.esp.ecos.activity.model.Province;
import com.netease.esp.ecos.activity.model.SignUp;
import com.netease.esp.ecos.activity.service.ActivityService;
import com.netease.esp.ecos.activity.service.CityService;
import com.netease.esp.ecos.activity.service.PictureService;
import com.netease.esp.ecos.activity.service.ProvinceService;
import com.netease.esp.ecos.facade.activity.ActivityFacade;
import com.netease.esp.ecos.user.model.dto.UserDTO;
import com.netease.esp.ecos.user.service.UserService;
import com.netease.esp.ecos.util.EntityDtoConverter;

/**
 * 用户Facade
 *
 */
@Service("activityFacade")
public class ActivityFacadeImpl implements ActivityFacade{
	@Resource
	ActivityService activityService;
	@Resource
	PictureService pictureService;
	@Resource
	UserService userService;
	@Resource
	private CityService cityService;
	@Resource
	ProvinceService provinceService;
	
	@Override
	public ActivityDTO getActivity(long id, long userId) {
		ActivityDTO activityDTO = new ActivityDTO();
		Activity activity = activityService.getActivity(id);
		EntityDtoConverter.entityConvertDto(activity, activityDTO);
		UserDTO owenr = userService.getUserDTO(activityDTO.getUserId());
		if (owenr.getAvatarUrlId() != null)
			activityDTO.setOwerUrl(pictureService.getPicture(owenr.getAvatarUrlId()).getUrl());
		activityDTO.setOwerNickName(owenr.getNickname());
		List<Long> signUpUserIdList = new ArrayList<Long>();
		signUpUserIdList = activityService.getSignUpUserIdList(id);
		if (activity.getDetailAddress() != null) {
			activityDTO.setDetailAddress(activity.getDetailAddress());
		}
		List<UserDTO> userList = null;
		if (signUpUserIdList != null && signUpUserIdList.size() > 0) {
			userList = userService.getUserDTOList(signUpUserIdList);
		}
		List<String> signUpUserPhotoUrlList = new ArrayList<String>();
		List<String> signUpUserNameList = new ArrayList<String>();
		if (userList != null) {
			for (UserDTO user : userList) {
				signUpUserPhotoUrlList.add(user.getAvatarUrl());
				signUpUserNameList.add(user.getNickname());
			}
		}
		Timestamp nowTime = new Timestamp(System.currentTimeMillis());
		if (nowTime.before(activityDTO.getStartTime())) {
			activityDTO.setStarted(false);
		} else {
			activityDTO.setStarted(true);
		}
		if (nowTime.after(activityDTO.getEndTime())) {
			activityDTO.setFinished(true);
		} else {
			activityDTO.setFinished(false);
		}
		if (signUpUserIdList.contains(userId)) {
			activityDTO.setSignUp(true);
		} else {
			activityDTO.setSignUp(false);
		}
		activityDTO.setLogoUrl(pictureService.getPicture(activityDTO.getLogoUrlId()).getUrl());
		activityDTO.setSignUpUserIdList(signUpUserIdList);
		activityDTO.setSignUpUserNameList(signUpUserNameList);
		activityDTO.setSignUpUserPhotoUrlList(signUpUserPhotoUrlList);
		return activityDTO;
	}

	@Override
	public List<ActivityDTO> getActivityDTOList(Long provinceId, Long typeId, Long userId, Long pageSize, Long pages, boolean isMyself) {
		List<ActivityDTO> activityDTOList = new ArrayList<ActivityDTO>();
		List<Activity> activitieList = new ArrayList<Activity>();
		if (isMyself) {
			activitieList = activityService.getActivityListByUserId(userId, pageSize, pages);
			
		} else {
			activitieList = activityService.getActivityList(provinceId, typeId, pageSize, pages);
		}
		for (Activity activity : activitieList) {
			ActivityDTO activityDTO = new ActivityDTO();
			EntityDtoConverter.entityConvertDto(activity, activityDTO);
			if (activity.getDetailAddress() != null) {
				activityDTO.setDetailAddress(activity.getDetailAddress());
			}
			UserDTO owenr = userService.getUserDTO(activityDTO.getUserId());
			if (owenr.getAvatarUrlId() != null)
				activityDTO.setOwerUrl(pictureService.getPicture(owenr.getAvatarUrlId()).getUrl());
			List<Long> signUpUserIdList = new ArrayList<Long>();
			signUpUserIdList = activityService.getSignUpUserIdList(activityDTO.getId());
			if (signUpUserIdList != null && signUpUserIdList.size() > 0) {
				List<String> signUpUserPhotoUrlList = new ArrayList<String>();
				List<String> signUpUserNameList = new ArrayList<String>();
				List<UserDTO> signUpUserList = userService.getUserDTOList(signUpUserIdList);
				for (UserDTO user : signUpUserList) {
					signUpUserPhotoUrlList.add(user.getAvatarUrl());
					signUpUserNameList.add(user.getNickname());
				}
				activityDTO.setSignUpUserIdList(signUpUserIdList);
				activityDTO.setSignUpUserNameList(signUpUserNameList);
				activityDTO.setSignUpUserPhotoUrlList(signUpUserPhotoUrlList);
			}
			Timestamp nowTime = new Timestamp(System.currentTimeMillis());
			if (nowTime.before(activityDTO.getStartTime())) {
				activityDTO.setStarted(false);
			} else {
				activityDTO.setStarted(true);
			}
			if (nowTime.after(activityDTO.getEndTime())) {
				activityDTO.setFinished(true);
			} else {
				activityDTO.setFinished(false);
			}
			activityDTO.setLogoUrl(pictureService.getPicture(activityDTO.getLogoUrlId()).getUrl());
			activityDTOList.add(activityDTO);
		}
		return activityDTOList;
	}

	@Override
	public ActivityDTO setActivity(ActivityDTO activityDTO) {
		try {
			Activity activity = new Activity();
			EntityDtoConverter.DtoConvertEntity(activityDTO, activity);
			activity.setDetailAddress(activityDTO.getDetailAddress());
			activity.setProvinceId(activityDTO.getProvinceId());
			activity.setDayStartTime(activityDTO.getDayStartTime());
			activity.setDayEndTime(activityDTO.getDayEndTime());
			Picture picture = new Picture();
			picture.setUrl(activityDTO.getOwerUrl());
			picture = pictureService.setPicture(picture);
			activity.setLogoUrlId(picture.getId());
			activity = activityService.setActivity(activity);
			activity = activityService.getActivity(activity.getId());
			EntityDtoConverter.entityConvertDto(activity, activityDTO);
		} catch (Exception e) {
			return null;
		}
		return activityDTO;
	}

	@Override
	public List<UserDTO> getUserList(long activityId, Long pages, Long pageSize) {
		List<Long> userIdList = activityService.getSignUpUserIdList(activityId, pages, pageSize);
		List<UserDTO> userDTOList = userService.getUserDTOList(userIdList);
		if (userDTOList == null)
			return userDTOList = new ArrayList<UserDTO>();
		return userDTOList;
	}
	
	@Override
	public List<UserDTO> getUserList(long activityId) {
		List<Long> userIdList = activityService.getSignUpUserIdList(activityId);
		List<UserDTO> userDTOList = userService.getUserDTOList(userIdList);
		return userDTOList;
	}

	@Override
	public String getCityName(int cityid) {
		return cityService.getCityName(cityid);
	}

	@Override
	public ActivityDTO delActivity(long activityId) {
		Activity activity = activityService.delActivity(activityId);
		ActivityDTO activityDTO = new ActivityDTO();
		EntityDtoConverter.entityConvertDto(activity, activityDTO);
		return activityDTO;
	}
	
	public SignUp signUp(Long activityId, Long userId) {
		SignUp signUp = new SignUp();
		signUp = activityService.signUpActivity(userId, activityId);
		return signUp;
	}

	@Override
	public SignUp cancelSignUp(Long activityId, Long userId) {
		SignUp signUp = null;
		signUp = activityService.cancelSignUpActivity(userId, activityId);
		return signUp;
	}

	@Override
	public List<City> getCityList() {
		List<City> cityList = cityService.getCityList();
		return cityList;
	}

	@Override
	public List<Province> getProvinceList() {
		List<Province> provinceList = provinceService.getProvinceList();
		return provinceList;
	}

	
}
