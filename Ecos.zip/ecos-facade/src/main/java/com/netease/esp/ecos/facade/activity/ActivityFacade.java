package com.netease.esp.ecos.facade.activity;

import java.util.List;

import com.netease.esp.ecos.activity.model.ActivityDTO;
import com.netease.esp.ecos.activity.model.City;
import com.netease.esp.ecos.activity.model.Province;
import com.netease.esp.ecos.activity.model.SignUp;
import com.netease.esp.ecos.user.model.dto.UserDTO;

/**
 * 活动Facade
 */
public interface ActivityFacade {
	
	ActivityDTO getActivity(long activityId, long userId);
	List<ActivityDTO> getActivityDTOList(Long provinceId, Long typeId, Long userId, Long pageSize, Long pages, boolean isMyself);
	ActivityDTO setActivity(ActivityDTO activityDTO);
	List<UserDTO> getUserList(long activityId, Long pages, Long pageSize);
	List<UserDTO> getUserList(long activityId);
	ActivityDTO delActivity(long activityId);
	String getCityName(int city);
	public SignUp signUp(Long activityId, Long userId);
	public SignUp cancelSignUp(Long activityId, Long userId);
	public List<City> getCityList();
	public List<Province> getProvinceList();
}
