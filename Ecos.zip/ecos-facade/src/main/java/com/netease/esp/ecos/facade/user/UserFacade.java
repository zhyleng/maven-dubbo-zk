package com.netease.esp.ecos.facade.user;

import java.util.List;

import com.netease.esp.ecos.user.model.dto.UserDTO;

/**
 * 用户Facade
 */
public interface UserFacade {
	
	UserDTO register(UserDTO userDto);
	UserDTO login(UserDTO userDto);
	UserDTO getUserDTO(long id);
	UserDTO getOtherUserDTO(long id, long toUserId);
	List<UserDTO> getUserDTOList(List<Long> ids);
	List<UserDTO> getUserPartDTOList(List<Long> ids);
	
	boolean modifyPwd(long userId, String oldPwd, String newPwd);
	boolean resetPwd(String phone, String pwd);
	UserDTO updateUser(UserDTO userDto);
}
