package com.netease.esp.ecos.facade.course.vo;

import java.io.Serializable;
import java.sql.Timestamp;

public class CourseAssigmentVO implements Serializable{
    private static final long serialVersionUID = 1L;
    /**
     *             JSONObject
     {
     userid:作者id
     nickname：作者名称
     description：内容
     imgUrl：图片url
     authorAvatarUrl：作者头像url
     issueTimeStamp：发布时间时间戳

     */
    private  long assigmentId;
    private long userId;
    private String nickname;
    private String description;
    private String imageUrl;
    private String authorAvatarUrl;
    private Timestamp issueTimeStamp;

    public long getAssigmentId() {
        return assigmentId;
    }

    public void setAssigmentId(long assigmentId) {
        this.assigmentId = assigmentId;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getAuthorAvatarUrl() {
        return authorAvatarUrl;
    }

    public void setAuthorAvatarUrl(String authorAvatarUrl) {
        this.authorAvatarUrl = authorAvatarUrl;
    }

    public Timestamp getIssueTimeStamp() {
        return issueTimeStamp;
    }

    public void setIssueTimeStamp(Timestamp issueTimeStamp) {
        this.issueTimeStamp = issueTimeStamp;
    }

    @Override
    public String toString() {
        return "CourseAssigmentVO{" +
                "assigmentId=" + assigmentId +
                ", userId=" + userId +
                ", nickname='" + nickname + '\'' +
                ", description='" + description + '\'' +
                ", imageUrl='" + imageUrl + '\'' +
                ", authorAvatarUrl='" + authorAvatarUrl + '\'' +
                ", issueTimeStamp=" + issueTimeStamp +
                '}';
    }
}
