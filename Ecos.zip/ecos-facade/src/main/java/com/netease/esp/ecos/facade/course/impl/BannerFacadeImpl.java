package com.netease.esp.ecos.facade.course.impl;

import javax.annotation.Resource;

import com.netease.esp.ecos.course.model.Banner;
import com.netease.esp.ecos.course.service.BannerService;
import com.netease.esp.ecos.facade.course.BannerFacade;
import org.springframework.stereotype.Service;

import java.util.List;


/**
 * 用户Facade
 *
 */
@Service("bannerFacade")
public class BannerFacadeImpl implements BannerFacade{
	@Resource
    BannerService bannerService;

    @Override
    public Banner getBanner(long id) {
        return bannerService.getBanner(id);
    }

    @Override
    public List<Banner> getBannerList() {
        return bannerService.getBannerList();
    }

}
