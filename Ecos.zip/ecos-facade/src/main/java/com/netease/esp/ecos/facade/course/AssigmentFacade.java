package com.netease.esp.ecos.facade.course;

import com.netease.esp.ecos.course.dto.AssigmentDto;
import com.netease.esp.ecos.facade.course.vo.AssigmentCommentVO;
import com.netease.esp.ecos.facade.course.vo.AssigmentListVO;
import com.netease.esp.ecos.facade.course.vo.CourseVO;

import java.util.List;

public interface AssigmentFacade {
    public AssigmentDto createAssigment(AssigmentDto assigmentDto);
    public AssigmentDto deleteAssigment(long assigmentId);
    public List<AssigmentListVO> getAssigmentList(long userId,long courseId,int offset,int size);
    public AssigmentCommentVO getAssigmentDetail(long userId,long id);


}
