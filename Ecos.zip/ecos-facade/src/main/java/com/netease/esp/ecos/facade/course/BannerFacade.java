package com.netease.esp.ecos.facade.course;

import com.netease.esp.ecos.course.model.Banner;

import java.util.List;

/**
 * 教程Facade
 */
public interface BannerFacade {
	Banner getBanner(long id);
    List<Banner> getBannerList();
}
