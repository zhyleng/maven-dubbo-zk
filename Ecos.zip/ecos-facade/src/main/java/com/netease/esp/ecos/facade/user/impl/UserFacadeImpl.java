package com.netease.esp.ecos.facade.user.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.netease.esp.ecos.activity.service.CityService;
import com.netease.esp.ecos.facade.user.UserFacade;
import com.netease.esp.ecos.user.model.dto.UserDTO;
import com.netease.esp.ecos.user.service.TokenService;
import com.netease.esp.ecos.user.service.UserService;

/**
 * 用户Facade
 *
 */
@Service("userFacade")
public class UserFacadeImpl implements UserFacade{
	@Resource
    UserService userService;
	@Resource
	TokenService tokenService;
	@Resource
	CityService cityService;

	@Override
	public UserDTO getUserDTO(long id) {
		UserDTO userDto = userService.getUserDTO(id); 
		userDto = addCityName(userDto);
		return userDto;
	}

	@Override
	public UserDTO register(UserDTO userDto) {
		// TODO Auto-generated method stub
		boolean hasRegister = userService.hasRegisterByPhone(userDto.getPhone());
		if(hasRegister) {
			userDto.setHasRegister(true);
		} else {
			userDto = userService.addUserDTO(userDto);
			if(userDto != null) {
				userDto.setHasRegister(false);
				userDto.setToken(tokenService.getToken(userDto.getId()));
			}
		}
		userDto = addCityName(userDto);
		return userDto;
	}

	@Override
	public List<UserDTO> getUserDTOList(List<Long> ids) {
		// TODO Auto-generated method stub
		List<UserDTO> list = userService.getUserDTOList(ids);
		for(UserDTO userDto : list) {
			userDto = addCityName(userDto);
		}
		return list;
	}

	@Override
	public List<UserDTO> getUserPartDTOList(List<Long> ids) {
		// TODO Auto-generated method stub
		return userService.getPartUserDTOList(ids);
	}

	/**
	 * 登录
	 * @return null表示密码错误
	 */
	@Override
	public UserDTO login(UserDTO userDto) {
		// TODO Auto-generated method stub
		boolean hasRegister = userService.hasRegisterByPhone(userDto.getPhone());
		if(!hasRegister) {
			userDto.setHasRegister(false);
		} else {
			userDto = userService.getUserDTOByPhoneAndPwd(userDto.getPhone(), userDto.getPwd());
			if(userDto != null) {
				userDto.setHasRegister(true);
				userDto.setToken(tokenService.getToken(userDto.getId()));
			}
		}
		userDto = addCityName(userDto);
		return userDto;
	}

	@Override
	public boolean modifyPwd(long userId, String oldPwd, String newPwd) {
		// TODO Auto-generated method stub
		return userService.modifyUserPwd(userId, oldPwd, newPwd);
	}

	@Override
	public boolean resetPwd(String phone, String pwd) {
		// TODO Auto-generated method stub
		return userService.resetUserPwd(phone, pwd);
	}

	@Override
	public UserDTO updateUser(UserDTO userDto) {
		// TODO Auto-generated method stub
		userDto = userService.updateUser(userDto);
		userDto = addCityName(userDto);
		return userDto;
	}
	
	public UserDTO addCityName(UserDTO userDto) {
		// TODO Auto-generated method stub
		if(userDto != null && userDto.getCityCode() != null) {
			try {
				userDto.setCityName(cityService.getCityName(userDto.getCityCode()));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return userDto;
	}

	@Override
	public UserDTO getOtherUserDTO(long id, long toUserId) {
		UserDTO userDto = userService.getOtherUserDTO(id, toUserId);
		userDto = addCityName(userDto);
		return userDto;
	}
}
