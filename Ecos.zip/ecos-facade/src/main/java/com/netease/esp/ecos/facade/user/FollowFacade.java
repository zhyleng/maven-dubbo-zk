package com.netease.esp.ecos.facade.user;

import com.netease.esp.ecos.facade.user.vo.FollowUserVO;

/**
 * 用户Facade
 */
public interface FollowFacade {
	boolean follow(long fromUserId, long toUserId);
	boolean cancelFollow(long fromUserId, long toUserId);
	
	FollowUserVO getFansByUserId(long userId, int pages, int pageSize); 
	FollowUserVO getFollowOtherByUserId(long userId, int pages, int pageSize); 
}
