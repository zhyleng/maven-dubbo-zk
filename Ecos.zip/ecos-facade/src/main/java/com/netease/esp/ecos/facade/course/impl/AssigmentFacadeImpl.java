package com.netease.esp.ecos.facade.course.impl;

import com.netease.esp.ecos.course.dto.AssigmentDto;
import com.netease.esp.ecos.course.model.Assigment;
import com.netease.esp.ecos.course.service.AssigmentService;
import com.netease.esp.ecos.course.service.PraiseService;
import com.netease.esp.ecos.csr.model.ShareComment;
import com.netease.esp.ecos.csr.service.CommentService;
import com.netease.esp.ecos.facade.course.AssigmentFacade;
import com.netease.esp.ecos.facade.course.vo.AssigmentCommentVO;
import com.netease.esp.ecos.facade.course.vo.AssigmentListVO;
import com.netease.esp.ecos.user.model.dto.UserDTO;
import com.netease.esp.ecos.user.service.UserService;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Service("assigmentFacade")
public class AssigmentFacadeImpl implements AssigmentFacade {

    Logger logger =Logger.getLogger(this.getClass());
    @Resource
    AssigmentService assigmentService;
    @Resource
    UserService userService;
    @Resource
    PraiseService praiseService;
    @Resource
    CommentService commentService;

    @Override
    public AssigmentDto createAssigment(AssigmentDto assigmentDto) {
        return assigmentService.createAssigment(assigmentDto);
    }

    @Override
    public AssigmentDto deleteAssigment(long id) {
        return assigmentService.deteleAssigment(id);
    }

    @Override
    public List<AssigmentListVO> getAssigmentList(long userId,long courseId, int offset, int size) {
        List<AssigmentListVO> assigmentListVOList = new ArrayList<AssigmentListVO>();
        List<AssigmentDto> assigmentDtoList = assigmentService.getAssigmentList(courseId, offset, size);
        for(AssigmentDto assigmentDto : assigmentDtoList) {
            AssigmentListVO assigmentListVO = new AssigmentListVO();

            assigmentListVO.setUserId(assigmentDto.getUserId());
            assigmentListVO.setAssigmentId(assigmentDto.getId());
            assigmentListVO.setImgUrl(assigmentDto.getImgUrl());
            assigmentListVO.setDescription(assigmentDto.getDescription());

            UserDTO userDTO = userService.getUserDTO(assigmentDto.getUserId());
            assigmentListVO.setNickname(userDTO.getNickname());
            assigmentListVO.setAuthorAvatarUrl(userDTO.getAvatarUrl());
            assigmentListVO.setPublishTime(assigmentDto.getPublishTime());

            if (praiseService.getPraiseByContent(userId, 4, assigmentDto.getId()) == 1) {
                assigmentListVO.setHasPraised(true);
            }else{
                assigmentListVO.setHasPraised(false);
            }
            assigmentListVOList.add(assigmentListVO);
        }

        return assigmentListVOList;
    }

    @Override
    public AssigmentCommentVO getAssigmentDetail(long userId,long id) {
        try{
            AssigmentDto assigmentDto = assigmentService.getAssigment(id);
            AssigmentCommentVO assigmentCommentVO = new AssigmentCommentVO();

            assigmentCommentVO.setUserId(assigmentDto.getUserId());
            assigmentCommentVO.setAssigmentId(assigmentDto.getId());
            assigmentCommentVO.setCourseId(assigmentDto.getCourseId());
            assigmentCommentVO.setImgUrl(assigmentDto.getImgUrl());
            assigmentCommentVO.setDescription(assigmentDto.getDescription());

            UserDTO userDTO = userService.getUserDTO(assigmentDto.getUserId());

            assigmentCommentVO.setUserAvatarUrl(userDTO.getAvatarUrl());
            assigmentCommentVO.setPraiseNum(praiseService.getPraiseCountByCourseId(4,assigmentDto.getId()));
            assigmentCommentVO.setCommentNum(commentService.getCommentNum(Long.parseLong("4"),assigmentDto.getId()));
            assigmentCommentVO.setPublishTime(assigmentDto.getPublishTime());

            List<ShareComment> comments = commentService.getComments(Long.parseLong("4"), assigmentDto.getId(), Long.parseLong(99+""), Long.parseLong(99+""));

            assigmentCommentVO.setComments(comments);

            if(praiseService.getPraiseByContent(userId,4,assigmentDto.getId()) == 1) {
                assigmentCommentVO.setHasPraised(true);
            }else {
                assigmentCommentVO.setHasPraised(false);
            }

            logger.info("get assigmentDetail successful!");
            return assigmentCommentVO;

        }catch (Exception e){
            logger.error("get assigment detail error!");
            return null;

        }


    }
}
