package com.netease.esp.ecos.facade.course;

import com.netease.esp.ecos.course.dto.AssigmentDto;
import com.netease.esp.ecos.course.model.Praise;
import com.netease.esp.ecos.facade.course.vo.AssigmentCommentVO;
import com.netease.esp.ecos.facade.course.vo.AssigmentListVO;

import java.util.List;

public interface PraiseFacade {
    public Praise createPraise(long userId,int type, long refid);
    public Praise cancelPraise(long userId,int type, long refid);
    public boolean judgePraiseOrNot(long userId,int type,long refid);
}
