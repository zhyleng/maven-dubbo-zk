package com.netease.esp.ecos.facade.user.vo;

import java.util.List;

import com.netease.esp.ecos.user.model.dto.UserDTO;

public class FollowUserVO {
	private int size;
	private boolean hasMore = true;
	private List<UserDTO> users = null;
	
	public FollowUserVO() {}
	
	public FollowUserVO(int size, boolean hasMore, List<UserDTO> users) {
		super();
		this.size = size;
		this.hasMore = hasMore;
		this.users = users;
	}

	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public boolean isHasMore() {
		return hasMore;
	}
	public void setHasMore(boolean hasMore) {
		this.hasMore = hasMore;
	}
	public List<UserDTO> getUsers() {
		return users;
	}
	public void setUsers(List<UserDTO> users) {
		this.users = users;
	}
	
}
