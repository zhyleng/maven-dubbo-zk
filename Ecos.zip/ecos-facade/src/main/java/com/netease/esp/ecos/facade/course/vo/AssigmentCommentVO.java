package com.netease.esp.ecos.facade.course.vo;

import com.netease.esp.ecos.csr.model.ShareComment;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class AssigmentCommentVO implements Serializable{
    /**
     * {
     token:””,
     userId：作者id
     assignmentId:作业id
     courseId:教程id
     imgUrl：图片URL
     description :描述
     userAvatarUrl：作者头像url
     praiseNum:点赞数
     commentNum:评论总数
     comments:
     {
     JSONObject
     {
     avatarUrl：评论者头像
     content ：评论内容
     commentType：评论类型
     commentTypeId：评论类型id
     commentId：评论id
     fromId：评论者id
     fromNickName： 评论者名称
     parentId ：父评论id
     parentNIickName: 父评论者昵称
     commitTimeStamp：评论时间时间戳
     }评论
     }前3条评论和最新一条评论

     }

     */
    private static final long serialVersionUID = 1L;
    private long userId = 1;
    private long assigmentId = 1;
    private long courseId = 1;
    private String imgUrl ="";
    private String description ="";
    private String userAvatarUrl = "";
    private long praiseNum = 0;
    private long commentNum = 0;
    private Timestamp publishTime = null;
    private List<ShareComment> comments = null;
    private boolean hasPraised = false;

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public long getAssigmentId() {
        return assigmentId;
    }

    public void setAssigmentId(long assigmentId) {
        this.assigmentId = assigmentId;
    }

    public long getCourseId() {
        return courseId;
    }

    public void setCourseId(long courseId) {
        this.courseId = courseId;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUserAvatarUrl() {
        return userAvatarUrl;
    }

    public void setUserAvatarUrl(String userAvatarUrl) {
        this.userAvatarUrl = userAvatarUrl;
    }

    public long getPraiseNum() {
        return praiseNum;
    }

    public void setPraiseNum(long praiseNum) {
        this.praiseNum = praiseNum;
    }

    public long getCommentNum() {
        return commentNum;
    }

    public void setCommentNum(long commentNum) {
        this.commentNum = commentNum;
    }

    public Timestamp getPublishTime() {
        return publishTime;
    }

    public void setPublishTime(Timestamp publishTime) {
        this.publishTime = publishTime;
    }

    public List<ShareComment> getComments() {
        return comments;
    }

    public void setComments(List<ShareComment> comments) {
        this.comments = comments;
    }

    public boolean isHasPraised() {
        return hasPraised;
    }

    public void setHasPraised(boolean hasPraised) {
        this.hasPraised = hasPraised;
    }

    @Override
    public String toString() {
        return "AssigmentCommentVO{" +
                "userId=" + userId +
                ", assigmentId=" + assigmentId +
                ", courseId=" + courseId +
                ", imgUrl='" + imgUrl + '\'' +
                ", description='" + description + '\'' +
                ", userAvatarUrl='" + userAvatarUrl + '\'' +
                ", praiseNum=" + praiseNum +
                ", commentNum=" + commentNum +
                ", publishTime=" + publishTime +
                ", comments=" + comments +
                ", hasPraised=" + hasPraised +
                '}';
    }
}
