package com.netease.esp.ecos.facade.course.vo;

import java.io.Serializable;
import java.sql.Timestamp;

public class AssigmentListVO implements Serializable{
    private static final long serialVersionUID = 1L;

    private long userId;
    private long assigmentId;
    private String imgUrl;
    private String description;
    private String nickname;
    private String authorAvatarUrl;
    private Timestamp publishTime;
    private boolean hasPraised;

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public long getAssigmentId() {
        return assigmentId;
    }

    public void setAssigmentId(long assigmentId) {
        this.assigmentId = assigmentId;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getAuthorAvatarUrl() {
        return authorAvatarUrl;
    }

    public void setAuthorAvatarUrl(String authorAvatarUrl) {
        this.authorAvatarUrl = authorAvatarUrl;
    }

    public Timestamp getPublishTime() {
        return publishTime;
    }

    public void setPublishTime(Timestamp publishTime) {
        this.publishTime = publishTime;
    }

    public boolean isHasPraised() {
        return hasPraised;
    }

    public void setHasPraised(boolean hasPraised) {
        this.hasPraised = hasPraised;
    }

    @Override
    public String toString() {
        return "AssigmentListVO{" +
                "userId=" + userId +
                ", assigmentId=" + assigmentId +
                ", imgUrl='" + imgUrl + '\'' +
                ", description='" + description + '\'' +
                ", nickname='" + nickname + '\'' +
                ", authorAvatarUrl='" + authorAvatarUrl + '\'' +
                ", publishTime=" + publishTime +
                ", hasPraised=" + hasPraised +
                '}';
    }
}
