package com.netease.esp.ecos.facade.csr;

import java.util.List;

import com.netease.esp.ecos.csr.model.Share;

/**
 * ShareFacade
 */
public interface ShareFacade {
	public Share createShare(Long userId, String coverUrl, String title, String content, String imgIds,Long totalImages,Long type);
	public Share getShare(Long shareId);
	public Boolean hasPraised(Long userId,Long type,Long shareId);
	public Boolean hasFollowed(Long fromUserId,Long toUserId);
	public Long getPraiseNum(Long type, Long shareId);
	public Long getCommentNum(Long type,Long shareId);
	public Share delShare(Long shareId);
	public List <Share> getShareList(Long userId,String type,String keyWord,Long pageSize,Long pages,Long tag ); 
	
}