package com.netease.esp.ecos.facade.user;

/**
 * Token Facade
 */
public interface TokenFacade {
	String getToken(long userId);
	boolean validate(long userId, String token);
}
