package com.netease.esp.ecos.facade.course.vo;

import com.alibaba.dubbo.common.json.JSONArray;
import com.alibaba.dubbo.common.json.JSONObject;
import com.netease.esp.ecos.course.dto.CourseDto;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class CourseVO implements Serializable{

    private static final long serialVersionUID = 1L;

    private long courseId = 1;
    private long userId  = 1;
    private String coverUrl ="";
    private String title ="";
    private String type = "";

    private String author ="";
    private String authorAvatarUrl ="";

    private long praiseNum =1;
    private String imgUrls ="";
    private String descriptions ="";

    private List<CourseAssigmentVO> assigmentList = null;
    private long commentNum =0;
    private Timestamp courseIssueTimeStamp =null;
    private boolean hasPraised = false;


    public long getCourseId() {
        return courseId;
    }

    public void setCourseId(long courseId) {
        this.courseId = courseId;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getCoverUrl() {
        return coverUrl;
    }

    public void setCoverUrl(String coverUrl) {
        this.coverUrl = coverUrl;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getAuthorAvatarUrl() {
        return authorAvatarUrl;
    }

    public void setAuthorAvatarUrl(String authorAvatarUrl) {
        this.authorAvatarUrl = authorAvatarUrl;
    }

    public long getPraiseNum() {
        return praiseNum;
    }

    public void setPraiseNum(long praiseNum) {
        this.praiseNum = praiseNum;
    }

    public String getImgUrls() {
        return imgUrls;
    }

    public void setImgUrls(String imgUrls) {
        this.imgUrls = imgUrls;
    }

    public String getDescriptions() {
        return descriptions;
    }

    public void setDescriptions(String descriptions) {
        this.descriptions = descriptions;
    }

    public List<CourseAssigmentVO> getAssigmentList() {
        return assigmentList;
    }

    public void setAssigmentList(List<CourseAssigmentVO> assigmentList) {
        this.assigmentList = assigmentList;
    }

    public long getCommentNum() {
        return commentNum;
    }

    public void setCommentNum(long commentNum) {
        this.commentNum = commentNum;
    }

    public Timestamp getCourseIssueTimeStamp() {
        return courseIssueTimeStamp;
    }

    public void setCourseIssueTimeStamp(Timestamp courseIssueTimeStamp) {
        this.courseIssueTimeStamp = courseIssueTimeStamp;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


    public boolean isHasPraised() {
        return hasPraised;
    }

    public void setHasPraised(boolean hasPraised) {
        this.hasPraised = hasPraised;
    }

    @Override
    public String toString() {
        return "CourseVO{" +
                "courseId=" + courseId +
                ", userId=" + userId +
                ", coverUrl='" + coverUrl + '\'' +
                ", title='" + title + '\'' +
                ", type='" + type + '\'' +
                ", author='" + author + '\'' +
                ", authorAvatarUrl='" + authorAvatarUrl + '\'' +
                ", praiseNum=" + praiseNum +
                ", imgUrls='" + imgUrls + '\'' +
                ", descriptions='" + descriptions + '\'' +
                ", assigmentList=" + assigmentList +
                ", commentNum=" + commentNum +
                ", courseIssueTimeStamp=" + courseIssueTimeStamp +
                ", hasPraised=" + hasPraised +
                '}';
    }
}
