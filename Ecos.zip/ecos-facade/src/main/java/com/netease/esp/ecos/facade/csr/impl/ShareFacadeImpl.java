package com.netease.esp.ecos.facade.csr.impl;

import java.util.List;

import javax.annotation.Resource;
import org.springframework.stereotype.Service;
import com.netease.esp.ecos.csr.model.Share;
import com.netease.esp.ecos.csr.service.ShareService;
import com.netease.esp.ecos.facade.csr.ShareFacade;

/**
 * Share
 *
 */
@Service("shareFacade")
public class ShareFacadeImpl implements ShareFacade{
	@Resource
    ShareService shareService;
	@Override
	public Share createShare(Long userId, String coverUrl, String title, String content, String imgIds,Long totalImages,Long type) {
		// TODO Auto-generated method stub
		return shareService.CreateShare(userId, coverUrl, title, content, imgIds, totalImages,type);
	}
	@Override
	public Share getShare(Long shareId) {
		// TODO Auto-generated method stub
		return shareService.getShareDetail(shareId);
	}
	@Override
	public Boolean hasPraised(Long userId, Long type, Long shareId) {
		// TODO Auto-generated method stub
		return shareService.hasPraised(userId, type, shareId);
	}
	@Override
	public Boolean hasFollowed(Long fromUserId, Long toUserId) {
		// TODO Auto-generated method stub
		return shareService.hasFollowed(fromUserId, toUserId);
	}
	@Override
	public Long getPraiseNum(Long type, Long shareId) {
		// TODO Auto-generated method stub
		return shareService.getPraiseNum(type, shareId);
	}
	@Override
	public Long getCommentNum(Long type, Long shareId) {
		// TODO Auto-generated method stub
		return shareService.getCommentNum(type, shareId);
	}
	@Override
	public Share delShare(Long shareId) {
		// TODO Auto-generated method stub
		return shareService.delShare(shareId);
	}
	@Override
	public List<Share> getShareList(Long userId, String type, String keyWord, Long pageSize, Long pages,Long tag) {
		// TODO Auto-generated method stub
		return shareService.getShareList(userId, type, keyWord, pageSize, pages,tag);
		
	}
}
