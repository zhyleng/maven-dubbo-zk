package com.netease.esp.ecos.facade.csr;

import java.util.List;
import com.netease.esp.ecos.csr.model.Comment;
import com.netease.esp.ecos.csr.model.ShareComment;

/**
 * CommentFacade
 */
public interface CommentFacade {
	public Comment creatComment(Long commentType,Long commentTypeId, String content, Long parentId,Long userId);
	public Comment getCommentContent(Long commentId);
	public Comment deleteComment(Long commentId);
	public String getAvatarUrlByUserId(Long userId);
	public String getNicknameByUserId(Long userId);
	public List<ShareComment> getComments(Long type,Long shareId,Long pageSize,Long pages); 
}