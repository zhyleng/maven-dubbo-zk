package com.netease.esp.ecos.facade.user.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.netease.esp.ecos.facade.user.FollowFacade;
import com.netease.esp.ecos.facade.user.vo.FollowUserVO;
import com.netease.esp.ecos.user.model.Follow;
import com.netease.esp.ecos.user.model.dto.FollowDTO;
import com.netease.esp.ecos.user.model.dto.UserDTO;
import com.netease.esp.ecos.user.service.FollowService;

@Service("followFacade")
public class FollowFacadeImpl implements FollowFacade{
	@Resource
	private FollowService followService;

	@Override
	public boolean follow(long fromUserId, long toUserId) {
		// TODO Auto-generated method stub
		Follow follow = new Follow(fromUserId, toUserId);
		return followService.follow(follow);
	}

	@Override
	public boolean cancelFollow(long fromUserId, long toUserId) {
		// TODO Auto-generated method stub
		Follow follow = new Follow(fromUserId, toUserId);
		return followService.cancelFollow(follow);
	}

	@Override
	public FollowUserVO getFansByUserId(long userId, int pages, int pageSize) {
		// TODO Auto-generated method stub
		List<FollowDTO> fans = followService.getFansByUserId(userId, pages, pageSize);
		if(fans == null) {
			return new FollowUserVO(0, false, null);
		}

		int size = fans.size();
		boolean hasMore = false;
		if(pageSize == size) {
			hasMore = true;
		}
		List<UserDTO> userDtos = new ArrayList<UserDTO>();
		for(FollowDTO followDto : fans) {
			userDtos.add(followDto.getFromUserDto());
		}
		return new FollowUserVO(size, hasMore, userDtos);
	}

	@Override
	public FollowUserVO getFollowOtherByUserId(long userId, int pages, int pageSize) {
		// TODO Auto-generated method stub
		List<FollowDTO> followOther = followService.getFollowOtherByUserId(userId, pages, pageSize);
		if(followOther == null) {
			return new FollowUserVO(0, false, null);
		}

		int size = followOther.size();
		boolean hasMore = false;
		if(pageSize == size) {
			hasMore = true;
		}
		List<UserDTO> userDtos = new ArrayList<UserDTO>();
		for(FollowDTO followDto : followOther) {
			userDtos.add(followDto.getToUserDto());
		}
		return new FollowUserVO(size, hasMore, userDtos);
	}

}
