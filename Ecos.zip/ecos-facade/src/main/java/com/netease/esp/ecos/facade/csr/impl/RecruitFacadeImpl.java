package com.netease.esp.ecos.facade.csr.impl;

import java.util.List;

import javax.annotation.Resource;
import org.springframework.stereotype.Service;

import com.netease.esp.ecos.csr.model.Recruit;
import com.netease.esp.ecos.csr.model.RecruitDis;
import com.netease.esp.ecos.csr.model.Share;
import com.netease.esp.ecos.csr.model.UserForRecruit;
import com.netease.esp.ecos.csr.service.RecruitService;
import com.netease.esp.ecos.csr.service.ShareService;
import com.netease.esp.ecos.facade.csr.RecruitFacade;
import com.netease.esp.ecos.facade.csr.ShareFacade;

/**
 * Share
 *
 */
@Service("recruitFacade")
public class RecruitFacadeImpl implements RecruitFacade{
	@Resource
    RecruitService recruitService;
	@Override
	public Recruit createRecruit(Long userId, Double price, String description, Long shareId, String priceUnit,
			String coverUrl, String title, Long recruitType) {
		// TODO Auto-generated method stub
		return recruitService.createRecruit(userId, price, description, shareId, priceUnit, coverUrl, title, recruitType);
	}
	@Override
	public RecruitDis getDetailRecruit(Long recruitId,Long userId) {
		// TODO Auto-generated method stub
		return recruitService.getDetailRecruit(recruitId,userId);
	}
	@Override
	public UserForRecruit getUserForRecruit(Long userId) {
		// TODO Auto-generated method stub
		return recruitService.getUserForRecruit(userId);
	}
	@Override
	public List<RecruitDis> getDetailList(Long userId, Boolean isMyself, Long recruitType, Long cityCode, String sortRule,
			Long pageSize, Long pages) {
		// TODO Auto-generated method stub
		return recruitService.getDetailList(userId, isMyself, recruitType, cityCode, sortRule, pageSize, pages);
	}
}
