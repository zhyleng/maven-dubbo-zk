package com.netease.esp.ecos.facade.course;

import com.netease.esp.ecos.course.dto.CourseDto;
import com.netease.esp.ecos.facade.course.vo.CourseVO;
import org.springframework.stereotype.Service;


import java.util.List;

public interface CourseFacade {
    public CourseDto createCourse(CourseDto courseDto);
    public CourseDto deleteCourse(long id);
    public CourseVO getCourse(long id ,long userId);
    public List<CourseVO> getCourseListByRecommendation(long userId,int offset,int size);
    public List<CourseVO> getCourseListByTime(long userId,String filterType,String keyWord,int offset,int size);
    public List<CourseVO> getCourseListByPraise(long userId,String filterType,String keyWord,int offset,int size);
    public List<CourseVO> getCourseListByCollect(long userId,String filterType,String keyWord,int offset,int size);
    public List<CourseVO> getCourseListByMyself(long userId,int offset,int size);

}
