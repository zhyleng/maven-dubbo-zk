package com.netease.esp.ecos.facade.user.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.netease.esp.ecos.facade.user.TokenFacade;
import com.netease.esp.ecos.user.service.TokenService;

@Service("tokenFacade")
public class TokenFacadeImpl implements TokenFacade{
	@Resource
	private TokenService tokenService;

	@Override
	public String getToken(long userId) {
		// TODO Auto-generated method stub
		return tokenService.getToken(userId);
	}

	@Override
	public boolean validate(long userId, String token) {
		// TODO Auto-generated method stub
		return tokenService.validate(userId, token);
	}

}
