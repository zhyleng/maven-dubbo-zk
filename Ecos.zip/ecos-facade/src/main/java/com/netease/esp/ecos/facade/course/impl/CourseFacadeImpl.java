package com.netease.esp.ecos.facade.course.impl;

import com.netease.esp.ecos.course.dto.AssigmentDto;
import com.netease.esp.ecos.course.dto.CourseDto;
import com.netease.esp.ecos.course.service.AssigmentService;
import com.netease.esp.ecos.course.service.CourseService;
import com.netease.esp.ecos.course.service.PraiseService;
import com.netease.esp.ecos.csr.service.CommentService;
import com.netease.esp.ecos.facade.course.CourseFacade;
import com.netease.esp.ecos.facade.course.vo.CourseAssigmentVO;
import com.netease.esp.ecos.facade.course.vo.CourseVO;
import com.netease.esp.ecos.user.model.dto.UserDTO;
import com.netease.esp.ecos.user.service.UserService;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Service("courseFacade")
public class CourseFacadeImpl implements CourseFacade {
    @Resource
    CourseService courseService;
    @Resource
    UserService userService;
    @Resource
    PraiseService praiseService;
    @Resource
    AssigmentService assigmentService;
    @Resource
    CommentService commentService;

    Logger logger = Logger.getLogger(this.getClass());

    @Override
    public CourseDto createCourse(CourseDto course) {
        return courseService.createCourse(course);
    }

    @Override
    public CourseDto deleteCourse(long id) {
        return courseService.deleteCourse(id);
    }

    @Override
    public CourseVO getCourse(long id, long userId) {
        try{
            CourseVO courseVO = new CourseVO();
            CourseDto courseDto = courseService.getCourse(id);

            courseVO.setCourseId(courseDto.getId());
            courseVO.setUserId(courseDto.getUserId());
            courseVO.setCoverUrl(courseDto.getCoverUrl());
            courseVO.setTitle(courseDto.getTitle());

            UserDTO userDTO = userService.getUserDTO(courseDto.getUserId());

            courseVO.setAuthor(userDTO.getNickname());
            courseVO.setAuthorAvatarUrl(userDTO.getAvatarUrl());
            courseVO.setPraiseNum(praiseService.getPraiseCountByCourseId(0,courseDto.getId()));
            courseVO.setImgUrls(courseDto.getImgUrls());
            courseVO.setDescriptions(courseDto.getDescriptions());
            courseVO.setType(TypeTransformInt(courseDto.getType()));
            if(praiseService.getPraiseByContent(userId,0,courseDto.getId()) == 1) {
                courseVO.setHasPraised(true);
            }else {
                courseVO.setHasPraised(false);
            }

            List<CourseAssigmentVO> assigmentVOList = new ArrayList<>();

            List<AssigmentDto> assigmentDtoList = assigmentService.getAssigmentListNoPage(courseDto.getId());
            for(AssigmentDto assigmentDto: assigmentDtoList){
                CourseAssigmentVO courseAssigmentVOTemp=new CourseAssigmentVO();

                courseAssigmentVOTemp.setAssigmentId(assigmentDto.getId());
                UserDTO assigmentUser = userService.getUserDTO(userId);
                courseAssigmentVOTemp.setUserId(assigmentUser.getId());
                courseAssigmentVOTemp.setNickname(assigmentUser.getNickname());
                courseAssigmentVOTemp.setDescription(assigmentDto.getDescription());
                courseAssigmentVOTemp.setImageUrl(assigmentDto.getImgUrl());
                courseAssigmentVOTemp.setAuthorAvatarUrl(assigmentUser.getAvatarUrl());
                courseAssigmentVOTemp.setIssueTimeStamp(assigmentDto.getPublishTime());
                assigmentVOList.add(courseAssigmentVOTemp);
            }

            courseVO.setAssigmentList(assigmentVOList);



            courseVO.setCommentNum(commentService.getCommentNum(Long.parseLong("0"),courseDto.getId()));
            courseVO.setCourseIssueTimeStamp(courseDto.getPublishTime());

            logger.info("getCourse successfully!");

            return courseVO;

        }catch (Exception e){
            logger.error(e.getMessage());
            logger.error("get course error!");
            return  null;
        }

    }


    @Override
    public List<CourseVO> getCourseListByRecommendation(long userId,int offset, int size) {
        try{
            List<CourseVO> courseVOList = new ArrayList<CourseVO>();
            List<CourseDto> courseDtoList = courseService.getCourseListByRecommendation(offset, size);

            for(CourseDto courseDto : courseDtoList){
                CourseVO courseVO = new CourseVO();

                courseVO.setCourseId(courseDto.getId());
                courseVO.setTitle(courseDto.getTitle());
                courseVO.setCoverUrl(courseDto.getCoverUrl());
                courseVO.setUserId(courseDto.getUserId());
                courseVO.setPraiseNum(praiseService.getPraiseCountByCourseId(0, courseDto.getId()));
                courseVO.setImgUrls(courseDto.getImgUrls());
                courseVO.setDescriptions(courseDto.getDescriptions());
                courseVO.setCourseIssueTimeStamp(courseDto.getPublishTime());
                courseVO.setType(TypeTransformInt(courseDto.getType()));
                UserDTO userDTO = userService.getUserDTO(courseDto.getUserId());
                courseVO.setAuthor(userDTO.getNickname());
                courseVO.setAuthorAvatarUrl(userDTO.getAvatarUrl());

                if(praiseService.getPraiseByContent(userId,0,courseDto.getId())==1) {
                    courseVO.setHasPraised(true);
                }
                else {
                    courseVO.setHasPraised(false);
                }

                courseVOList.add(courseVO);
            }

            logger.info("getCourse successfully!");

            return courseVOList;


        }catch (Exception e){
            logger.error(e.getMessage());
            logger.error(" getCourseListByRecommendation error!");
            return  null;
        }


    }

    @Override
    public List<CourseVO> getCourseListByTime(long userId,String filterType,String keyWord,int offset, int size) {
        try{
            List<CourseVO> courseVOList = new ArrayList<CourseVO>();
            List<CourseDto> courseDtoList = courseService.getCourseListByTime(filterType,keyWord,offset, size);

            for(CourseDto courseDto : courseDtoList){
                CourseVO courseVO = new CourseVO();

                courseVO.setCourseId(courseDto.getId());
                courseVO.setTitle(courseDto.getTitle());
                courseVO.setCoverUrl(courseDto.getCoverUrl());
                courseVO.setUserId(courseDto.getUserId());
                courseVO.setPraiseNum(praiseService.getPraiseCountByCourseId(0,courseDto.getId()));
                courseVO.setImgUrls(courseDto.getImgUrls());
                courseVO.setDescriptions(courseDto.getDescriptions());
                courseVO.setCourseIssueTimeStamp(courseDto.getPublishTime());
                courseVO.setType(TypeTransformInt(courseDto.getType()));

                UserDTO userDTO = userService.getUserDTO(courseDto.getUserId());
                courseVO.setAuthor(userDTO.getNickname());
                courseVO.setAuthorAvatarUrl(userDTO.getAvatarUrl());

                if(praiseService.getPraiseByContent(userId,0,courseDto.getId())==1) {
                    courseVO.setHasPraised(true);
                }
                else {
                    courseVO.setHasPraised(false);
                }

                courseVOList.add(courseVO);
            }

            logger.info("getCourse successfully!");

            return courseVOList;


        }catch (Exception e){
            logger.error(e.getMessage());
            logger.error(" getCourseListByRecommendation error!");
            return  null;
        }
    }

    @Override
    public List<CourseVO> getCourseListByPraise(long userId,String filterType,String keyWord,int offset, int size) {
        try{
            List<CourseVO> courseVOList = new ArrayList<CourseVO>();
            List<CourseDto> courseDtoList = courseService.getCourseListByPraise(filterType,keyWord,offset, size);

            for(CourseDto courseDto : courseDtoList){
                CourseVO courseVO = new CourseVO();

                courseVO.setCourseId(courseDto.getId());
                courseVO.setTitle(courseDto.getTitle());
                courseVO.setCoverUrl(courseDto.getCoverUrl());
                courseVO.setUserId(courseDto.getUserId());
                courseVO.setPraiseNum(praiseService.getPraiseCountByCourseId(0,courseDto.getId()));
                courseVO.setImgUrls(courseDto.getImgUrls());
                courseVO.setDescriptions(courseDto.getDescriptions());
                courseVO.setCourseIssueTimeStamp(courseDto.getPublishTime());
                courseVO.setType(TypeTransformInt(courseDto.getType()));

                UserDTO userDTO = userService.getUserDTO(courseDto.getUserId());
                courseVO.setAuthor(userDTO.getNickname());
                courseVO.setAuthorAvatarUrl(userDTO.getAvatarUrl());

                if(praiseService.getPraiseByContent(userId,0,courseDto.getId())==1) {
                    courseVO.setHasPraised(true);
                }
                else {
                    courseVO.setHasPraised(false);
                }

                courseVOList.add(courseVO);
            }

            logger.info("getCourse successfully!");

            return courseVOList;


        }catch (Exception e){
            logger.error(e.getMessage());
            logger.error(" getCourseListByRecommendation error!");
            return  null;
        }
    }

    @Override
    public List<CourseVO> getCourseListByCollect(long userId,String filterType,String keyWord,int offset, int size) {
        try{
            List<CourseVO> courseVOList = new ArrayList<CourseVO>();
            List<CourseDto> courseDtoList = courseService.getCourseListByCollect(filterType,keyWord,offset, size);

            for(CourseDto courseDto : courseDtoList){
                CourseVO courseVO = new CourseVO();

                courseVO.setCourseId(courseDto.getId());
                courseVO.setTitle(courseDto.getTitle());
                courseVO.setCoverUrl(courseDto.getCoverUrl());
                courseVO.setUserId(courseDto.getUserId());
                courseVO.setPraiseNum(praiseService.getPraiseCountByCourseId(0,courseDto.getId()));
                courseVO.setImgUrls(courseDto.getImgUrls());
                courseVO.setDescriptions(courseDto.getDescriptions());
                courseVO.setCourseIssueTimeStamp(courseDto.getPublishTime());
                courseVO.setType(TypeTransformInt(courseDto.getType()));

                UserDTO userDTO = userService.getUserDTO(courseDto.getUserId());
                courseVO.setAuthor(userDTO.getNickname());
                courseVO.setAuthorAvatarUrl(userDTO.getAvatarUrl());


                if((praiseService.getPraiseByContent(userId,0,courseDto.getId())==1)) {
                    courseVO.setHasPraised(true);
                }
                else {
                    courseVO.setHasPraised(false);
                }

                courseVOList.add(courseVO);
            }

            logger.info("getCourse successfully!");

            return courseVOList;


        }catch (Exception e){
            logger.error(e.getMessage());
            logger.error(" getCourseListByRecommendation error!");
            return  null;
        }
    }

    @Override
    public List<CourseVO> getCourseListByMyself(long userId, int offset, int size) {
        try{
            List<CourseVO> courseVOList = new ArrayList<CourseVO>();
            List<CourseDto> courseDtoList = courseService.getCourseListByMyself(userId, offset, size);

            for(CourseDto courseDto : courseDtoList){
                CourseVO courseVO = new CourseVO();

                courseVO.setCourseId(courseDto.getId());
                courseVO.setTitle(courseDto.getTitle());
                courseVO.setCoverUrl(courseDto.getCoverUrl());
                courseVO.setUserId(courseDto.getUserId());
                courseVO.setPraiseNum(praiseService.getPraiseCountByCourseId(0,courseDto.getId()));
                courseVO.setImgUrls(courseDto.getImgUrls());
                courseVO.setDescriptions(courseDto.getDescriptions());
                courseVO.setCourseIssueTimeStamp(courseDto.getPublishTime());
                courseVO.setType(TypeTransformInt(courseDto.getType()));

                UserDTO userDTO = userService.getUserDTO(courseDto.getUserId());
                courseVO.setAuthor(userDTO.getNickname());
                courseVO.setAuthorAvatarUrl(userDTO.getAvatarUrl());

                if(praiseService.getPraiseByContent(userId,0,courseDto.getId())==1) {
                    courseVO.setHasPraised(true);
                }
                else {
                    courseVO.setHasPraised(false);
                }

                courseVOList.add(courseVO);
            }

            logger.info("getCourse successfully!");

            return courseVOList;


        }catch (Exception e){
            logger.error(e.getMessage());
            logger.error(" getCourseListByRecommendation error!");
            return  null;
        }
    }

    public String TypeTransformInt(String input){
        if(input.equals("妆娘")) {
            return "1";
        }
        if(input.equals("摄影")) {
            return "2";
        }
        if(input.equals("后期")) {
            return "3";
        }
        if(input.equals("服装")) {
            return "4";
        }
        if(input.equals("道具")) {
            return "5";
        }
        if(input.equals("假发")) {
            return "6";
        }
        if(input.equals("心得")) {
            return "7";
        }
        if(input.equals("其他")) {
            return "8";
        }
        return "1";
    }
}
