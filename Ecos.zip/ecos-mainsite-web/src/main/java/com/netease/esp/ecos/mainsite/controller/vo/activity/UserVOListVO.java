package com.netease.esp.ecos.mainsite.controller.vo.activity;

import java.util.List;

public class UserVOListVO {
	private String token;
	private List<UserVO> users;
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public List<UserVO> getUsers() {
		return users;
	}
	public void setUsers(List<UserVO> userVOList) {
		this.users = userVOList;
	}
	

}
