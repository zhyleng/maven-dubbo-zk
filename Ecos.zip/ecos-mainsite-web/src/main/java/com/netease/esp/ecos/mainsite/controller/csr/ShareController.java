package com.netease.esp.ecos.mainsite.controller.csr;


import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.apache.taglibs.standard.lang.jstl.test.beans.PublicInterface2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableLoadTimeWeaving;
import org.springframework.http.StreamingHttpOutputMessage;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.netease.esp.ecos.csr.model.Share;
import com.netease.esp.ecos.facade.csr.CommentFacade;
import com.netease.esp.ecos.facade.csr.ShareFacade;
import com.netease.esp.ecos.mainsite.csr.vo.CreateCommentVo;
import com.netease.esp.ecos.mainsite.csr.vo.CreateShareVo;
import com.netease.esp.ecos.mainsite.csr.vo.DetailShareVo;
import com.netease.esp.ecos.mainsite.csr.vo.ShareListVo;
import com.netease.esp.ecos.mainsite.global.Response;
import com.netease.esp.ecos.mainsite.global.ResultCode;
import com.netease.esp.ecos.mainsite.interceptor.anno.CheckAuthorized;

@Controller

@RequestMapping(value = "/m/share")
public class ShareController {
	Logger logger = Logger.getLogger(this.getClass());
	@Autowired
	ShareFacade shareFacade;
	@Autowired
	CommentFacade commentFacade;
	@RequestMapping(value = "/create")
	@ResponseBody
	@CheckAuthorized
	public Response createShare(@RequestParam(value="userId", required=true)Long userId,
								@RequestParam(value="token", required=false)String token,
								@RequestParam(value="shareJson", required=true)String shareJson){
		Response response = new Response();
		CreateShareVo createShareVo = new CreateShareVo();
		Share share = new Share();
		/**   解析Json   */
		JSONObject jsonObject = JSONObject.parseObject(shareJson);
		String title = jsonObject.getString("title");
		String coverUrl = jsonObject.getString("coverUrl");
		String imgurlString = jsonObject.getString("imgUrls");
		String description =  jsonObject.getString("description");
		Long totalImages = jsonObject.getLong("totalImages");
		Long type = jsonObject.getLong("type");
		/**   创建分享   */
		share = shareFacade.createShare(userId, coverUrl, title, description, imgurlString,totalImages,type);
		if(share.getShareId() == null){
			response.setCode(ResultCode.GLOBAL_SERVER_ERROR);
			response.setData(null);
			response.setMsg("create failed");
			return response;
		}
		/**   填充VO   */
		createShareVo.setToken(token);
		createShareVo.setShareId(share.getShareId());
		createShareVo.setUserId(userId);
		createShareVo.setCoverUrl(coverUrl);
		createShareVo.setAuthorAvatarUrl(commentFacade.getAvatarUrlByUserId(userId));
		createShareVo.setNickname(commentFacade.getNicknameByUserId(userId));
		createShareVo.setIssueTimeStamp(share.getTime());
		createShareVo.setTitle(title);
		createShareVo.setDescription(description);
		createShareVo.setImgUrl(imgurlString);
		/**   填充Response   */
		response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
		response.setData(createShareVo);
		response.setMsg("create successful");
		return response;
	}
	
	@RequestMapping(value = "/list")
	@ResponseBody
	@CheckAuthorized
	public Response getDetailList(@RequestParam(value="userId", required=true)Long userId,
			@RequestParam(value="token", required=false)String token,
			@RequestParam(value="type", required=true)String type,
			@RequestParam(value="keyWord", required=true)String keyWord,
			@RequestParam(value="pageSize", required=true)Long pageSize,
			@RequestParam(value="pages", required=true)Long pages,
			@RequestParam(value="tag", required=true)Long tag){
		
		Response response = new Response();
		ShareListVo shareListVo = new ShareListVo();
		/** 验证参数     */
		if(pages<=0){
			response.setCode(ResultCode.GLOBAL_SERVER_ERROR);
			response.setData(null);
			response.setMsg("pages <= 0");
		}
		List <DetailShareVo> detailShareVoList =  new ArrayList<DetailShareVo>();
		List <Share> shareList = new ArrayList<Share>();
		Long commentType = new Long(1);
		/**  获得指定share*/
		if(tag ==null){
			tag = (long) 63;
		}
		shareList = shareFacade.getShareList(userId, type, keyWord, pageSize, pages,tag);
		/** 根据share list 封装 shareListVo*/
		if(shareList != null){
			for (Share share : shareList) {
				DetailShareVo detailShareVo = new DetailShareVo();
				detailShareVo.setToken(token);
				detailShareVo.setShareId(share.getShareId());
				detailShareVo.setCoverUrl(share.getCoverUrl());
				detailShareVo.setAuthorAvatarUrl(commentFacade.getAvatarUrlByUserId(share.getUserId()));
				detailShareVo.setNickname(commentFacade.getNicknameByUserId(share.getUserId()));
				detailShareVo.setAuthorId(share.getUserId());
				detailShareVo.setHasFollowed(shareFacade.hasFollowed(userId, share.getUserId()));
				detailShareVo.setHasPraised(shareFacade.hasPraised(userId, commentType,share.getShareId()));
				detailShareVo.setIssueTimeStamp(share.getTime());
				detailShareVo.setCommentNum(shareFacade.getCommentNum(commentType, share.getShareId()));
				detailShareVo.setPraiseNum(shareFacade.getPraiseNum(commentType, share.getShareId()));
				detailShareVo.setTitle(share.getTitle());
				detailShareVo.setDescription(share.getContent());
				detailShareVo.setImgUrls(share.getImgIds());
				/**获取评论列表  分页为99 则返回最新4条*/
				List commentList = commentFacade.getComments(commentType, share.getShareId(),new Long(99),new Long(99));
				detailShareVo.setComments(commentList);
				detailShareVoList.add(detailShareVo);
			}
		}
		/** 封装 */
		shareListVo.setDetailShareVo(detailShareVoList);
		shareListVo.setToken(token);
		/** Response */
		response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
		response.setData(shareListVo);
		response.setMsg("get detail list successful");
		return response;
	}
	@RequestMapping(value = "/detail")
	@ResponseBody
	@CheckAuthorized
	public Response getDetail(@RequestParam(value="userId", required=true)Long userId,
							  @RequestParam(value="token", required=false)String token,
							  @RequestParam(value="shareId", required=true)Long shareId){
		Response response = new Response();
		Share share = new Share();
		/** 获得share  */
		share = shareFacade.getShare(shareId);
		Long type = new Long(1);
		Boolean hasPraised = shareFacade.hasPraised(userId, type, shareId);
		List commentList = commentFacade.getComments(type, shareId,new Long(99),new Long(99));
		if(hasPraised == null){
			hasPraised = false;
		}
		Long authorId = share.getUserId();
		/**	填充VO	*/
		DetailShareVo detailShareVo = new DetailShareVo();
		detailShareVo.setToken(token);
		detailShareVo.setShareId(shareId);
		detailShareVo.setCoverUrl(share.getCoverUrl());
		detailShareVo.setAuthorAvatarUrl(commentFacade.getAvatarUrlByUserId(authorId));
		detailShareVo.setNickname(commentFacade.getNicknameByUserId(authorId));
		detailShareVo.setAuthorId(authorId);
		detailShareVo.setHasFollowed(shareFacade.hasFollowed(userId, authorId));
		detailShareVo.setHasPraised(hasPraised);
		detailShareVo.setIssueTimeStamp(share.getTime());
		detailShareVo.setCommentNum(shareFacade.getCommentNum(type, shareId));
		detailShareVo.setPraiseNum(shareFacade.getPraiseNum(type, shareId));
		detailShareVo.setTitle(share.getTitle());
		detailShareVo.setDescription(share.getContent());
		detailShareVo.setImgUrls(share.getImgIds());
		detailShareVo.setComments(commentList);
		/**	填充Response	*/
		response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
		response.setData(detailShareVo);
		response.setMsg("get detail successful");
		return response;
	}
	@RequestMapping(value = "/delete")
	@ResponseBody
	@CheckAuthorized
	public Response delShare(@RequestParam(value="userId", required=true)Long userId,
							 @RequestParam(value="token", required=false)String token,
							 @RequestParam(value="shareId", required=true)Long shareId){
		Response response = new Response();
		Share share = new Share();
		share = shareFacade.delShare(shareId);
		response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
		response.setData(share);
		response.setMsg("delete successful");
		return response;
	}
}
