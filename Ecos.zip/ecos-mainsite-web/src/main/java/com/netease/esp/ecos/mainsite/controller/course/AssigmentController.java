package com.netease.esp.ecos.mainsite.controller.course;



import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.netease.esp.ecos.course.dto.AssigmentDto;
import com.netease.esp.ecos.course.model.Course;
import com.netease.esp.ecos.facade.course.AssigmentFacade;
import com.netease.esp.ecos.facade.course.CourseFacade;
import com.netease.esp.ecos.facade.course.vo.AssigmentCommentVO;
import com.netease.esp.ecos.facade.course.vo.AssigmentListVO;
import com.netease.esp.ecos.mainsite.global.Response;
import com.netease.esp.ecos.mainsite.global.ResultCode;
import com.netease.esp.ecos.mainsite.interceptor.anno.CheckAuthorized;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/m/course")
public class AssigmentController {
    Logger logger = Logger.getLogger(this.getClass());

    @Resource
    AssigmentFacade assigmentFacade;

    @RequestMapping(value = "/assignment/create")
    @ResponseBody
    @CheckAuthorized
    public Response createAssigment(@RequestParam(value = "userId", required = true) String userId,
                                    @RequestParam(value = "courseId", required = true) String courseId,
                                    @RequestParam(value = "imgUrl", required = true) String imgUrl,
                                    @RequestParam(value = "description",required = true) String description){
        Response response = new Response();
       try {
           AssigmentDto assigmentDto = new AssigmentDto();
           assigmentDto.setImgUrl(imgUrl);
           assigmentDto.setDescription(description);
           assigmentDto.setCourseId(Long.parseLong(courseId));
           assigmentDto.setUserId(Long.parseLong(userId));

           AssigmentDto result = assigmentFacade.createAssigment(assigmentDto);

           response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
           response.setData(result);
           response.setMsg("assigment create successful");
           logger.info("assigment create successful");
           return response;

       }catch (ClassCastException e) {
           response.setCode(ResultCode.GLOBAL_PARAM_ERROR);
           response.setMsg("创建教程作业参数错误！");
           logger.error("assigment create error");
           logger.error(e.getMessage());
           return response;
       }catch (NullPointerException e){
           response.setCode(ResultCode.GLOBAL_SERVER_ERROR);
           response.setMsg("服务器端错误");
           logger.error("create error");
           logger.error(e.getMessage());
           return response;
       } catch (Exception e){
           e.printStackTrace();
           response.setCode(ResultCode.GLOBAL_PARAM_ERROR);
           response.setMsg("assigment create error");
           logger.error("assigment create error");
           return response;
       }




    }
    @RequestMapping(value = "/assignment/list")
    @ResponseBody
    @CheckAuthorized
    public Response getAssigmentList(@RequestParam(value = "userId", required = true) String userId,
                                     @RequestParam(value = "courseId", required = true) String courseId,
                                     @RequestParam(value = "pageSize", required = true) String pageSize,
                                     @RequestParam(value = "pages",required = true) String pages){

        Response response = new Response();
        try {
            int offset = Integer.parseInt(pages)*Integer.parseInt(pageSize);
            int size = Integer.parseInt(pageSize);

            //这里得拼接一下vo
            List<AssigmentListVO> assigmentListVOList = new ArrayList<AssigmentListVO>();
            assigmentListVOList = assigmentFacade.getAssigmentList(Long.parseLong(userId),Long.parseLong(courseId), offset,size);

            JSONObject resultData = new JSONObject();
            resultData.put("courseId",courseId);
            resultData.put("assignments",assigmentListVOList);
            response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
            response.setData(resultData);
            response.setMsg("get assigment list successful");
            logger.info("get assigment list successful");
            return response;

        }catch (ClassCastException e) {
            response.setCode(ResultCode.GLOBAL_PARAM_ERROR);
            response.setMsg("参数错误！");
            logger.error("get assigment list error");
            logger.error(e.getMessage());
            return response;
        }catch (NullPointerException e){
            response.setCode(ResultCode.GLOBAL_SERVER_ERROR);
            response.setMsg("服务器端错误");
            logger.error("get assigment list error");
            logger.error(e.getMessage());
            return response;
        } catch (Exception e){
            e.printStackTrace();
            response.setCode(ResultCode.GLOBAL_PARAM_ERROR);
            response.setMsg("get assigment list error");
            logger.error("get assigment liste error");
            return response;
        }


    }
    @RequestMapping(value = "/assignment/detail")
    @ResponseBody
    @CheckAuthorized
    public Response getAssigmentDetail(@RequestParam(value = "userId", required = true) String userId,
                                       @RequestParam(value = "assignmentId", required = true) String assignmentId){

        Response response = new Response();
        try {
            AssigmentCommentVO assigmentCommentVO = new AssigmentCommentVO();

            assigmentCommentVO = assigmentFacade.getAssigmentDetail(Long.parseLong(userId),Long.parseLong(assignmentId));

            response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
            response.setData(assigmentCommentVO);
            response.setMsg("get assigment detail successful");
            logger.info("get assigment detail successful");
            return response;

        }catch (ClassCastException e) {
            response.setCode(ResultCode.GLOBAL_PARAM_ERROR);
            response.setMsg("参数错误！");
            logger.error("get coures detail error");
            logger.error(e.getMessage());
            return response;
        }catch (NullPointerException e){
            response.setCode(ResultCode.GLOBAL_SERVER_ERROR);
            response.setMsg("服务器端错误");
            logger.error("create error");
            logger.error(e.getMessage());
            return response;
        }catch (Exception e){

            response.setCode(ResultCode.GLOBAL_PARAM_ERROR);
            response.setMsg("get assigment detail error");
            logger.error("get assigment detail error");
            logger.error(e.getMessage());
            return response;
        }


    }
    @RequestMapping(value = "/assignment/delete")
    @ResponseBody
    @CheckAuthorized
    public Response assigmentDelete(@RequestParam(value = "userId", required = true) String userId,
                                    @RequestParam(value = "assignmentId", required = true) String assignmentId){
        Response response = new Response();
        try {
            AssigmentDto assigmentDto = assigmentFacade.deleteAssigment(Long.parseLong(assignmentId));

            response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
            response.setData(assigmentDto);
            response.setMsg("delete assigment detail successful");
            logger.info("delete assigment detail successful");
            return response;

        }catch (ClassCastException e) {
            response.setCode(ResultCode.GLOBAL_PARAM_ERROR);
            response.setMsg("参数错误！");
            logger.error("delete coures detail error");
            logger.error(e.getMessage());
            return response;
        }catch (NullPointerException e){
            response.setCode(ResultCode.GLOBAL_SERVER_ERROR);
            response.setMsg("服务器端错误");
            logger.error("delete error");
            logger.error(e.getMessage());
            return response;
        }catch (Exception e){
            response.setCode(ResultCode.GLOBAL_PARAM_ERROR);
            response.setMsg("delete assigment detail error");
            logger.error("delete assigment detail error");
            logger.error(e.getMessage());
            return response;
        }
    }

}
