package com.netease.esp.ecos.mainsite.global;

public class Response {
	private int code;
	private Object data;
	private String msg;
	
	public Response() {}
	
	public Response(int code, Object data, String msg) {
		super();
		this.code = code;
		this.data = data;
		this.msg = msg;
	}
	
	@Override
	public String toString() {
		return "code: " + this.code + "\tdata:" + this.data + "\tmsg:" + this.msg; 
	}

	public void setCode(int code){
		this.code = code;
	}
	public int getCode(){
		return this.code;
	}
	public void setData(Object data){
		this.data = data;
	}
	public Object getData(){
		return this.data;
	}
	public void setMsg(String msg){
		this.msg = msg;
	}
	public String getMsg(){
		return this.msg;
	}
}

