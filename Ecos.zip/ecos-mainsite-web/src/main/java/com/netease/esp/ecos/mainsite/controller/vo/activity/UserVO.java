package com.netease.esp.ecos.mainsite.controller.vo.activity;

public class UserVO {
	private int userId;
	private String IM_id;
	private String characterSignature;
	private String nickName;
	private String avatarUrl;
	private String roleType;
	private boolean hasFollowed;
	private boolean beFollowed;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getIM_id() {
		return IM_id;
	}
	public void setIM_id(String iM_id) {
		IM_id = iM_id;
	}
	public String getCharacterSignature() {
		return characterSignature;
	}
	public void setCharacterSignature(String characterSignature) {
		this.characterSignature = characterSignature;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickname(String nickname) {
		this.nickName = nickname;
	}
	public String getAvatarUrl() {
		return avatarUrl;
	}
	public void setAvatarUrl(String avatarUrl) {
		this.avatarUrl = avatarUrl;
	}
	public String getRoleType() {
		return roleType;
	}
	public void setRoleType(String roleType) {
		this.roleType = roleType;
	}
	public boolean isHasFollowed() {
		return hasFollowed;
	}
	public void setHasFollowed(boolean hasFollowed) {
		this.hasFollowed = hasFollowed;
	}
	public boolean isBeFollowed() {
		return beFollowed;
	}
	public void setBeFollowed(boolean beFollowed) {
		this.beFollowed = beFollowed;
	}
	
}
