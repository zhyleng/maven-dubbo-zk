package com.netease.esp.ecos.mainsite.global.session;

public interface HttpSession {
	String getId();
	void setId(String id);
	void setAttribute(String key, Object value);
	Object getAttribute(String key);
	Object removeAttribute(String key);
}
