package com.netease.esp.ecos.mainsite.csr.vo;

import java.sql.Timestamp;
import java.util.List;
import com.netease.esp.ecos.csr.model.ShareComment;

public class DetailListShareVo {
	private Long shareId;
	private String coverUrl;
	private String authorAvatarUrl;
	private String nickname;
	private Long authorId;
	private Boolean hasFollowed;
	private Boolean hasPraised;
	private String title;
	private Timestamp issueTimeStamp;
	private Long commentNum;
	private Long praiseNum;
	private Long totalImages;
	private List<CreateCommentVo> comments; 
	
	public void setShareId(Long shareId){
		this.shareId = shareId;
	}
	public Long getShareId(){
		return this.shareId;
	}
	public void setAuthorId(Long authorId){
		this.authorId = authorId;
	}
	public Long getAuthorId(){
		return this.authorId;
	}
	public void setCoverUrl(String coverUrl){
		this.coverUrl = coverUrl;
	}
	public String getCoverUrl(){
		return this.coverUrl;
	}
	public void setAuthorAvatarUrl(String authorAvatarUrl){
		this.authorAvatarUrl = authorAvatarUrl;
	}
	public String getAuthorAvatarUrl(){
		return this.authorAvatarUrl;
	}
	public void setNickname(String nickname){
		this.nickname =nickname;
	}
	public String getNickname(){
		return this.nickname;
	}
	public void setIssueTimeStamp(Timestamp issueTimeStamp){
		this.issueTimeStamp = issueTimeStamp;
	}
	public Timestamp getIssueTimeStamp(){
		return this.issueTimeStamp;
	}
	public void setTitle(String title){
		this.title =title;
	}
	public String getTitle(){
		return this.title;
	}
	public void setCommentNum(Long commentNum){
		this.commentNum = commentNum;
	}
	public Long getCommentNum(){
		return this.commentNum;
	}	
	public void setPraiseNum(Long praiseNum){
		this.praiseNum = praiseNum;
	}
	public Long getPraiseNum(){
		return this.praiseNum;
	}	
	public void setHasFollowed(Boolean hasFollowed){
		this.hasFollowed = hasFollowed;
	}
	public Boolean getHasFollowed(){
		return this.hasFollowed;
	}
	public void setHasPraised(Boolean hasPraised){
		this.hasPraised = hasPraised;
	}
	public Boolean getHasPraised(){
		return this.hasPraised;
	}
	public void setComments(List<CreateCommentVo> comments){
		this.comments = comments;
	}
	public List<CreateCommentVo> getComments(){
		return this.comments;
	}
	public void setTotalImages(Long totalImages){
		totalImages = this.totalImages;
	}
	public Long getTotalImages(){
		return this.totalImages;
	}
}
