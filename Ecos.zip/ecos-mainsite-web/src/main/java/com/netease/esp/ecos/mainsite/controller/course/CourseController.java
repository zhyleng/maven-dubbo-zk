package com.netease.esp.ecos.mainsite.controller.course;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.netease.esp.ecos.course.dto.CourseDto;
import com.netease.esp.ecos.course.model.Praise;
import com.netease.esp.ecos.facade.course.CourseFacade;
import com.netease.esp.ecos.facade.course.PraiseFacade;
import com.netease.esp.ecos.facade.course.vo.CourseVO;
import com.netease.esp.ecos.mainsite.global.Response;
import com.netease.esp.ecos.mainsite.global.ResultCode;
import com.netease.esp.ecos.mainsite.interceptor.anno.CheckAuthorized;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/m/course")
public class CourseController {
    Logger logger = Logger.getLogger(this.getClass());

    @Resource
    CourseFacade courseFacade;
    @Resource
    PraiseFacade praiseFacade;

    @RequestMapping(value = "/create")
    @ResponseBody
    @CheckAuthorized
    public Response createCourse(@RequestParam(value = "userId", required = true) String id, @RequestParam(value = "courseJson", required = true) String courseJsonObject) {
        Response response = new Response();
        try {
            CourseDto courseDto = new CourseDto();
            JSONObject courseJson = JSON.parseObject(courseJsonObject);
            courseDto.setUserId(Long.parseLong(id));
            courseDto.setType(transFormType(courseJson.getString("type")));
            courseDto.setTitle(courseJson.getString("title"));
            courseDto.setCoverUrl(courseJson.getString("coverUrl"));
            courseDto.setImgUrls(courseJson.getString("imgUrls"));
            courseDto.setDescriptions(courseJson.getString("descriptions"));

            CourseDto resultCourseDto = new CourseDto();
            resultCourseDto = courseFacade.createCourse(courseDto);

            response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
            response.setData(resultCourseDto);
            response.setMsg("create successful");

            logger.info("create successful");
            return response;
        } catch (ClassCastException e) {
            response.setCode(ResultCode.GLOBAL_PARAM_ERROR);
            response.setMsg("创建教程参数错误");
            logger.error("create error");
            logger.error(e.getMessage());
            return response;
        }catch (NullPointerException e){
            response.setCode(ResultCode.GLOBAL_SERVER_ERROR);
            response.setMsg("服务器端错误");
            logger.error("create error");
            logger.error(e.getMessage());
            return response;
        }catch (Exception e){
            response.setCode(ResultCode.GLOBAL_SERVER_ERROR);
            response.setMsg("服务器端错误");
            logger.error("create error");
            logger.error(e.getMessage());
            return response;
        }

}

    @RequestMapping(value = "/list")
    @ResponseBody
    @CheckAuthorized
    public Response getCourseList(@RequestParam(value = "userId", required = true) String id,
                                  @RequestParam(value = "type", required = true) String type,
                                  @RequestParam(value = "filterType", required = false) String filterType,
                                  @RequestParam(value = "keyWord"   ,required = false) String keyWord,
                                  @RequestParam(value = "sortRule",required = false) String sortRule,
                                  @RequestParam(value = "pageSize", required = true) String pageSize,
                                  @RequestParam(value = "pages", required = true) String pages) {
        Response response = new Response();

        try {
            int offset = Integer.parseInt(pages)*Integer.parseInt(pageSize);
            int size = Integer.parseInt(pageSize);
            List<CourseVO> courseVOList = new ArrayList<CourseVO>();
            keyWord = "%"+keyWord+"%";

            if (type.equals("recommended")) {
                courseVOList = courseFacade.getCourseListByRecommendation(Long.parseLong(id),offset, size);
            }
            if (type.equals("myself")) {
                courseVOList = courseFacade.getCourseListByMyself(Long.parseLong(id), offset, size);
            }
            if (type.equals("filter") && sortRule.equals("time")) {
                courseVOList = courseFacade.getCourseListByTime(Long.parseLong(id),transFormType(filterType),keyWord,offset, size);
            }
            if (type.equals("filter") && sortRule.equals("praised")) {
                courseVOList = courseFacade.getCourseListByPraise(Long.parseLong(id),transFormType(filterType),keyWord,offset, size);
            }
            if (type.equals("filter") && sortRule.equals("followed")) {
                courseVOList = courseFacade.getCourseListByCollect(Long.parseLong(id),transFormType(filterType), keyWord, offset, size);
            }


            response.setCode(ResultCode.GLOBAL_SUCCESSFUL);

            JSONObject resultJson = new JSONObject();
            resultJson.put("courses",courseVOList);
            response.setData(resultJson);
            response.setMsg("get course successful");

            logger.info("get course successful");
            return response;

        } catch (ClassCastException e) {
            response.setCode(ResultCode.GLOBAL_PARAM_ERROR);
            response.setMsg("查询列表参数错误！");
            logger.error("create error");
            logger.error(e.getMessage());
            return response;
        }catch (NullPointerException e){
            response.setCode(ResultCode.GLOBAL_SERVER_ERROR);
            response.setMsg("服务器端错误");
            logger.error("create error");
            logger.error(e.getMessage());
            return response;
        }catch (Exception e) {
            response.setCode(ResultCode.GLOBAL_PARAM_ERROR);
            response.setMsg("查询列表参数错误！");
            logger.error("查询列表错误");
            logger.error(e.getMessage());
            return response;
        }


    }

    @RequestMapping(value = "/detail")
    @ResponseBody
    @CheckAuthorized
    //@CheckAuthorized
    public Response getCourseDetail(@RequestParam(value = "userId", required = true) String id,
                                    @RequestParam(value = "courseId", required = true) String courseId) {

        Response response = new Response();
        try {
            CourseVO courseVO = new CourseVO();
            courseVO = courseFacade.getCourse(Long.parseLong(courseId), Long.parseLong(id));

            response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
            response.setData(courseVO);
            response.setMsg("create successful");

            logger.info("create successful");
            return response;

        }catch (ClassCastException e) {
            response.setCode(ResultCode.GLOBAL_PARAM_ERROR);
            response.setMsg("获取教程详情参数错误！");
            logger.error("get coures detail error");
            logger.error(e.getMessage());
            return response;
        }catch (NullPointerException e){
            response.setCode(ResultCode.GLOBAL_SERVER_ERROR);
            response.setMsg("服务器端错误");
            logger.error("create error");
            logger.error(e.getMessage());
            return response;
        } catch (Exception e) {
            response.setCode(ResultCode.GLOBAL_PARAM_ERROR);
            response.setMsg("获取教程详情参数错误");
            logger.error("create error");
            logger.error(e.getMessage());
            return response;
        }


    }

    @RequestMapping(value = "/delete")
    @ResponseBody
    @CheckAuthorized
    public Response courseDelete(@RequestParam(value = "userId", required = true) String id,
                           @RequestParam(value = "courseId", required = true) String courseId) {
        Response response = new Response();
        try {
            CourseDto courseDto = new CourseDto();
            courseDto = courseFacade.deleteCourse(Long.parseLong(courseId));

            response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
            response.setData(courseDto);
            response.setMsg("create successful");

            logger.info("create successful");
            return response;
        }catch (ClassCastException e) {
            response.setCode(ResultCode.GLOBAL_PARAM_ERROR);
            response.setMsg("删除教程参数错误！");
            logger.error("get coures detail error");
            logger.error(e.getMessage());
            return response;
        }catch (NullPointerException e){
            response.setCode(ResultCode.GLOBAL_SERVER_ERROR);
            response.setMsg("服务器端错误");
            logger.error("create error");
            logger.error(e.getMessage());
            return response;
        }  catch (Exception e) {

            response.setCode(ResultCode.GLOBAL_PARAM_ERROR);
            response.setMsg("删除教程参数错误");
            logger.error("create error");
            logger.error(e.getMessage());
            return response;
        }


    }



    public String transFormType(String inputString){
        String reuslt = "";
        int i = Integer.parseInt(inputString);
        switch (i){
            case 1:
                reuslt = "妆娘";
                break;
            case 2:
                reuslt = "摄影";
                break;
            case 3:
                reuslt = "后期";
                break;
            case 4:
                reuslt  = "服装";
                break;
            case 5:
                reuslt = "道具";
                break;
            case 6:
                reuslt = "假发";
                break;
            case 7:
                reuslt = "心得";
                break;
            case 8:
                reuslt = "其他";
                break;
        }
        return reuslt;
    }

    public Response adminCreateCourse(){
 
        //createCourse(long)
        return null;
    }


}
