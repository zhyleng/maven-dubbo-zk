package com.netease.esp.ecos.mainsite.csr.vo;

import java.util.List;

public class ShareListVo {
	private String token;
	private List<DetailShareVo>  detailShareVo;
	
	public void setToken(String token){
		this.token = token;
	}
	public String getToken(){
		return this.token;
	}
	public void setDetailShareVo(List<DetailShareVo>   detailShareVo){
		this.detailShareVo = detailShareVo;
	}
	public List<DetailShareVo>  getDetailShareVo(){
		return this.detailShareVo;
	}
}
