package com.netease.esp.ecos.mainsite.csr.vo;

public class DeleteCommentVo {
	private String token;
	private long commentId;
	private long commentType;
	private long commentTypeId;
	
	public String getToken() {
		return this.token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public long getCommentId() {
		return this.commentId;
	}
	public void setCommentId(long commentId) {
		this.commentId = commentId;
	}
	public long getCommentType() {
		return this.commentType;
	}
	public void setCommentType(long commentType) {
		this.commentType = commentType;
	}
	public long getCommentTypeId(){
		return this.commentTypeId;
	}
	public void setCommentTypeId(long commentTypeId){
		this.commentTypeId = commentTypeId;
	}
}
