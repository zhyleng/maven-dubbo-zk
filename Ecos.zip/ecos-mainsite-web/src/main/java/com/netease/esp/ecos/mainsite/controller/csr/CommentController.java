package com.netease.esp.ecos.mainsite.controller.csr;

import java.util.List;

import org.apache.log4j.Logger;
import org.jboss.netty.util.EstimatableObjectWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.netease.esp.ecos.csr.model.Comment;
import com.netease.esp.ecos.facade.csr.CommentFacade;
import com.netease.esp.ecos.mainsite.csr.vo.CommentListVo;
import com.netease.esp.ecos.mainsite.csr.vo.CreateCommentVo;
import com.netease.esp.ecos.mainsite.csr.vo.DeleteCommentVo;
import com.netease.esp.ecos.mainsite.global.Response;
import com.netease.esp.ecos.mainsite.global.ResultCode;
import com.netease.esp.ecos.mainsite.interceptor.anno.CheckAuthorized;

@Controller
@RequestMapping(value = "/m/comment")
public class CommentController {
	Logger logger = Logger.getLogger(this.getClass());
	@Autowired
	CommentFacade commentFacade;
	
	@RequestMapping(value = "/create")
	@ResponseBody
	@CheckAuthorized
	public Response createComment(@RequestParam(value="userId", required=true)Long userId,
								  @RequestParam(value="token", required=false)String token, 
								  @RequestParam(value="commentType", required=true)Long commentType, 
								  @RequestParam(value="commentTypeId", required=true)Long commentTypeId,
								  @RequestParam(value="content", required=true)String content,
								  @RequestParam(value="parentId", required=false)Long parentId){
		Response response = new Response();							
		Comment comment;                            
		CreateCommentVo createCommentVo = new CreateCommentVo();  
		/**   验证请求参数    */
		if(commentType!= 0 && commentType !=1 && commentType !=2 && commentType !=3 && commentType !=4){
			/**   0:教程 1:分享 2:活动 3:招募 4:作业   *///
			response.setCode(ResultCode.CSR_COMMENT_TYPE);
			response.setMsg("commentType error");
			return response;   
		}
		if(content == null){
			response.setCode(ResultCode.CSR_COMMENT_CONTENT);
			response.setMsg("content null");
			return response;   
		}
		comment = commentFacade.creatComment(commentType, commentTypeId, content, parentId, userId);
		if(comment == null){
			response.setCode(ResultCode.CSR_COMMENT_CREATE);
			response.setMsg("database can't create comment");
			return response;
		}
		/**   填充VO   */
		createCommentVo.setCommentId(comment.getCommentId());
		createCommentVo.setCommentType(comment.getCommentType());
		createCommentVo.setCommentTypeId(comment.getCommentTypeId());
		createCommentVo.setContent(comment.getContent());
		createCommentVo.setParentId(comment.getParentId());
		createCommentVo.setCommentTimeStampTime(comment.getTime());
		createCommentVo.setToken(token);
		createCommentVo.setAvatarUrl(commentFacade.getAvatarUrlByUserId(userId));
		createCommentVo.setFromId(userId);
		createCommentVo.setFromNickname(commentFacade.getNicknameByUserId(userId));
		if(parentId == null){
			createCommentVo.setParentNIickName(null);
		}else{
			createCommentVo.setParentNIickName(commentFacade.getNicknameByUserId(parentId));
		}
		/**   填充Respone   */
		response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
		response.setData(createCommentVo);
		response.setMsg("create successful");
		return response;
	}
	
	@RequestMapping(value = "/list")
	@ResponseBody
	@CheckAuthorized
	public Object getList(@RequestParam(value="userId", required=true)Long userId,
						  @RequestParam(value="token", required=false)String token,
						  @RequestParam(value="commentType", required=true)Long commentType,
						  @RequestParam(value="commentTypeId", required=true)Long commentTypeId,
						  @RequestParam(value="pageSize", required=true)Long pageSize,
						  @RequestParam(value="pages", required=true)Long pages){
		Response response = new Response();
		CommentListVo commentList = new CommentListVo();
		/**验证分页参数*/
		if(pages<=0){
			response.setCode(ResultCode.GLOBAL_PARAM_ERROR);
			response.setData(null);
			response.setMsg("pages <=0 ");
			return response;
		}
		/**获取评论列表*/
		List comments = commentFacade.getComments(commentType, commentTypeId,pageSize, pages);
		if(comments != null){
			commentList.setComments(comments);
			commentList.setCommentType(commentTypeId);
			commentList.setToken(token);
			commentList.setCommentTypeId(commentTypeId);
		}else{
			commentList = null;
		}
		/**填充VO*/
		response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
		response.setData(commentList);
		response.setMsg("create successful");
		return response;
	}
	
	@RequestMapping(value = "/detail")
	@ResponseBody
	@CheckAuthorized
	public Object getDetail(@RequestParam(value="userId", required=true)Long userId,
							@RequestParam(value="token", required=false)String token,
							@RequestParam(value="commentId", required=true)Long commentId){
		Response response = new Response();							
		CreateCommentVo createCommentVo = new CreateCommentVo(); 
		Long parentId = null;
		Comment comment;                           				   
		/** 验证参数 */
		if(commentId < 0){
			response.setCode(ResultCode.CSR_COMMENT_ID);
			response.setMsg("commentId illegal");
			return response; 	
		}
		/** 获取评论详情 */
		comment = commentFacade.getCommentContent(commentId);
		if(comment == null){
			response.setCode(ResultCode.CSR_COMMENT_GET);
			response.setMsg("database can't get comment");
			return response;
		}
		/** 填充VO */
		createCommentVo.setCommentId(comment.getCommentId());
		createCommentVo.setCommentType(comment.getCommentType());
		createCommentVo.setCommentTypeId(comment.getCommentTypeId());
		createCommentVo.setContent(comment.getContent());
		createCommentVo.setCommentTimeStampTime(comment.getTime());
		createCommentVo.setToken(token);
		createCommentVo.setAvatarUrl(commentFacade.getAvatarUrlByUserId(userId));
		createCommentVo.setFromId(userId);
		createCommentVo.setFromNickname(commentFacade.getNicknameByUserId(userId));
		parentId = comment.getParentId();
		if(parentId != null){
			createCommentVo.setParentId(parentId);
			createCommentVo.setParentNIickName(commentFacade.getNicknameByUserId(parentId));
		}else{
			createCommentVo.setParentId(null);
			createCommentVo.setParentNIickName(commentFacade.getNicknameByUserId(null));
		}
		/** Response */
		response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
		response.setData(createCommentVo);
		response.setMsg("get comment detail successfule");
		return response;
	}
	
	@RequestMapping(value = "/delete")
	@ResponseBody
	@CheckAuthorized
	public Object delete(@RequestParam(value="userId", required=true)Long userId,
					     @RequestParam(value="token", required=false)String token,
			             @RequestParam(value="commentId", required=true)Long commentId){
		Response response = new Response();							
		Comment comment;                          				    
	 	DeleteCommentVo deleteCommentVo = new DeleteCommentVo();    
	 	/** 获取删除评论 */
	 	comment = commentFacade.deleteComment(commentId);
	 	if(comment != null){
		 	deleteCommentVo.setToken(token);
		 	deleteCommentVo.setCommentId(comment.getCommentId());
		 	deleteCommentVo.setCommentType(comment.getCommentType());
		 	deleteCommentVo.setCommentTypeId(comment.getCommentTypeId());
	 	}else{
	 		deleteCommentVo = null;
	 	}
	 	/** 填充VO */
		response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
		response.setData(deleteCommentVo);
		response.setMsg("delete comment successful");
		return response;
	}
}
