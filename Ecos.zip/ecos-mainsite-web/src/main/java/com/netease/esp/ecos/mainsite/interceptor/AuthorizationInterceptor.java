package com.netease.esp.ecos.mainsite.interceptor;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Method;
import java.util.Enumeration;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.netease.esp.ecos.facade.user.TokenFacade;
import com.netease.esp.ecos.mainsite.global.Response;
import com.netease.esp.ecos.mainsite.global.ResultCode;
import com.netease.esp.ecos.mainsite.interceptor.anno.CheckAuthorized;

public class AuthorizationInterceptor extends HandlerInterceptorAdapter {
	private static final String USER_ID = "userId";
	
	@Resource
	private TokenFacade tokenFacade;
	private Logger logger = Logger.getLogger(this.getClass());

	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		// handler其实是一个封装了controller 对应的一个处理方法
		boolean result = true;
		/** 调试 */
		StringBuffer sb = new StringBuffer("");
		Enumeration<String> params = request.getParameterNames();
		while(params.hasMoreElements()) {
			String name = params.nextElement();
			sb.append(name + "=" + request.getParameter(name) + "&");
		}
		logger.debug(sb.toString());
		

		HandlerMethod handlerMethod = (HandlerMethod) handler;
		Method method = handlerMethod.getMethod();

		CheckAuthorized checkAuthorized = method.getAnnotation(CheckAuthorized.class);

		/** 验证Token*/
		if (checkAuthorized != null) {
			logger.info("************进入token验证拦截器**********");
			result = checkLogin(request,response);			//Token验证
			/**验证失败,直接返回结果,提示客户端 验证失败*/
			if(!result) {
				String userId = request.getParameter(USER_ID);
				JSONObject data = new JSONObject();
				data.put(USER_ID, userId);

				logger.info("用户  " + userId + " 验证登入失败");
				PrintWriter writer = response.getWriter();
				writer.write(JSON.toJSONString(new Response(ResultCode.GLOBAL_TOKEN_ERROR, data, "Token invalidate")));
				writer.flush();
				writer.close();
				return false;
			}
			logger.debug("************验证成功**********");
			
		}
		return result;
	}

	/**
	 * session中保存user_id的目的是 跟JSESSIONID绑定
	 */
	boolean checkLogin(HttpServletRequest request, HttpServletResponse response) throws IOException {
		Long userId = null;
		String token = null;
		try {
			userId = Long.valueOf(request.getParameter(USER_ID));
		} catch (Exception e) {}

		if(userId == null) {
			return false;
		}

		Cookie[] cookies = request.getCookies();
		if(cookies == null) {
			return false;
		}
		for(Cookie cookie : cookies) {
			if("TOKEN".equals(cookie.getName())) {
				token = cookie.getValue();
			}
		}
		logger.debug("token:" + token);
		return tokenFacade.validate(userId, token);
	}

}
