package com.netease.esp.ecos.mainsite.csr.vo;

import java.util.List;
public class CommentListVo{

	private static final Long serialVersionUID = 1L;
	private String token;
    private Long commentType;
    private Long commentTypeId;
    private List<CreateCommentVo> comments;
	/**
	 * @return the token
	 */
	public String getToken() {
		return token;
	}
	/**
	 * @param token the token to set
	 */
	public void setToken(String token) {
		this.token = token;
	}
	/**
	 * @return the commentType
	 */
	public Long getCommentType() {
		return commentType;
	}
	/**
	 * @param commentType the commentType to set
	 */
	public void setCommentType(Long commentType) {
		this.commentType = commentType;
	}
	/**
	 * @return the commentTypeId
	 */
	public Long getCommentTypeId() {
		return commentTypeId;
	}
	/**
	 * @param commentTypeId the commentTypeId to set
	 */
	public void setCommentTypeId(Long commentTypeId) {
		this.commentTypeId = commentTypeId;
	}
	/**
	 * @return the comments
	 */
	public List<CreateCommentVo> getComments() {
		return comments;
	}
	/**
	 * @param comments the comments to set
	 */
	public void setComments(List<CreateCommentVo> comments) {
		this.comments = comments;
	} 
}
