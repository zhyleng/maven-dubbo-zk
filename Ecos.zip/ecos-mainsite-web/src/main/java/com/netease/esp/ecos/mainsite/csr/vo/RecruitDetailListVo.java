package com.netease.esp.ecos.mainsite.csr.vo;

import java.util.List;

public class RecruitDetailListVo {
	private String token;
	private List<RecruitDetailVo> recruitList;
	/**
	 * @return the token
	 */
	public String getToken() {
		return token;
	}
	/**
	 * @param token the token to set
	 */
	public void setToken(String token) {
		this.token = token;
	}
	/**
	 * @return the recruitList
	 */
	public List<RecruitDetailVo> getRecruitList() {
		return recruitList;
	}
	/**
	 * @param recruitList the recruitList to set
	 */
	public void setRecruitList(List<RecruitDetailVo> recruitList) {
		this.recruitList = recruitList;
	}
	
	
}
