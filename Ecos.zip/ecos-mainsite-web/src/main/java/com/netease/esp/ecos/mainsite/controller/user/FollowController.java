package com.netease.esp.ecos.mainsite.controller.user;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.netease.esp.ecos.facade.user.FollowFacade;
import com.netease.esp.ecos.facade.user.vo.FollowUserVO;
import com.netease.esp.ecos.mainsite.global.Response;
import com.netease.esp.ecos.mainsite.global.ResultCode;
import com.netease.esp.ecos.mainsite.interceptor.anno.CheckAuthorized;

@Controller
@RequestMapping(value={"/m/user"}, produces={"application/json;charset=UTF-8"})
public class FollowController {
	private Logger logger = Logger.getLogger(this.getClass());
	@Resource
	private FollowFacade followFacade;

	/**
	 * 关注或取消关注
	 */
	@RequestMapping(value="/follow")
	@ResponseBody
	@CheckAuthorized
	public Response follow(@RequestParam(value="userId", required=false)Long userId,
			@RequestParam(value="toUserId", required=false)Long toUserId, 
			@RequestParam(value="type", required=false)String type) {
		Response result = null;
		if(type == null) {
			return new Response(ResultCode.GLOBAL_PARAM_ERROR, null, "type is error! type is " + type);
		}
		switch (type) {
		case "follow":
			if (userId.equals(toUserId)) {
				result = new Response(ResultCode.GLOBAL_PARAM_ERROR, null, "userId and toUserId is same");
				break;
			}
			if(followFacade.follow(userId, toUserId)) {
				JSONObject obj = new JSONObject();
				obj.put("toUserId", toUserId);
				result = new Response(ResultCode.GLOBAL_SUCCESSFUL, obj, "successful");
			} else {
				result = new Response(ResultCode.USER_FOLLOW_HAS_FOLLOWED, null, "has followed");
			}
			break;
		case "cancel":
			if(followFacade.cancelFollow(userId, toUserId)) {
				JSONObject obj = new JSONObject();
				obj.put("toUserId", toUserId);
				result = new Response(ResultCode.GLOBAL_SUCCESSFUL, obj, "successful");
			} else {
				result = new Response(ResultCode.USER_FOLLOW_CANCEL_HAS_NOT_FOLLOWED, null, "has not followed");
			}
			break;
		default:
			result = new Response(201, null, "type is error! type is " + type + ", not is follow or cancel.");
			break;
		}

		logger.debug(" Response ResultCode: " + result.getCode());
		logger.debug(" Response Content:\n" + JSON.toJSONString(result));
		return result;
	}

	/**
	 * 获取关注人列表、粉丝列表
	 */
	@RequestMapping(value="/follow/list", method=RequestMethod.GET)
	@ResponseBody
	public Response listUsers(@RequestParam(value="userId", required=false)Long userId,
			@RequestParam(value="pages", required=false)Integer pages,
			@RequestParam(value="pageSize", required=false)Integer pageSize,
			@RequestParam(value="type", required=false) String type) {
		Response result = null;
		
		if(type == null) {
			return new Response(ResultCode.GLOBAL_PARAM_ERROR, null, "type is null! type is " + type);
		}
		
		if(pageSize == null || pages == null) {
			pages = 1;
			pageSize = 100;
		}
		
		switch (type) {
		case "follow":
			FollowUserVO vo = followFacade.getFollowOtherByUserId(userId, pages, pageSize);
			result = new Response(ResultCode.GLOBAL_SUCCESSFUL, vo, "successful");
			break;
		case "fans":
			FollowUserVO vo2 = followFacade.getFansByUserId(userId, pages, pageSize);
			result = new Response(ResultCode.GLOBAL_SUCCESSFUL, vo2, "successful");
			break;
		default:
			return new Response(ResultCode.GLOBAL_PARAM_ERROR, null, "type is null! type is " + type);
		}

		logger.debug(" Response ResultCode: " + result.getCode());
		logger.debug(" Response Content:\n" + JSON.toJSONString(result));
		return result;
	}
}
