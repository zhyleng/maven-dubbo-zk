package com.netease.esp.ecos.mainsite.global.session;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class StandardHttpSession implements Serializable, HttpSession {
	private static final long serialVersionUID = 1L;
	private String id = null;
	private Map<String, Object> map = null;
	transient private HttpServletRequest request = null;
	transient private HttpServletResponse response = null;
	
	public StandardHttpSession() {}
	
	public StandardHttpSession(HttpServletRequest request, HttpServletResponse response) {
		this.setRequest(request);
		this.setResponse(response);
		this.id = UUID.randomUUID().toString().toUpperCase().replaceAll("-", "");
		Cookie cookie = new Cookie("SESSIONID", this.id);
		response.addCookie(cookie);
		map = new HashMap<>();
	}

	/** 获取SESSIONID */
	public static String getSESSIONID(HttpServletRequest request) {
		Cookie[] cookies = request.getCookies();
		if(cookies == null) {
			return null;
		}
		for(Cookie cookie : cookies) {
			if("SESSIONID".equals(cookie.getName())) {
				return cookie.getValue();
			}
		}
		return null;
	}
	
	public void setAttribute(String key, Object value) {
		map.put(key, value);
	}
	
	public Object getAttribute(String key) {
		return map.get(key);
	}
	
	public Object removeAttribute(String key) {
		return map.remove(key);
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public HttpServletRequest getRequest() {
		return request;
	}

	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}

	public HttpServletResponse getResponse() {
		return response;
	}

	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}
}
