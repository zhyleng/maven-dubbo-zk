package com.netease.esp.ecos.mainsite.csr.vo;

import java.sql.Timestamp;

import com.alibaba.dubbo.common.json.JSONArray;

public class CreateShareVo {
	private String token;
	private Long shareId;
	private Long userId;
	private String coverUrl;
	private String authorAvatarUrl;
	private String nickname;
	private Timestamp issueTimeStamp;
	private String title;
	private String description;
	//imgUrl JsonArray
	private String imgUrl;
	
	public void setToken(String token){
		this.token = token;
	}
	public String getToken(){
		return this.token;
	}
	public void setShareId(Long shareId){
		this.shareId = shareId;
	}
	public Long getShareId(){
		return this.shareId;
	}
	public void setUserId(Long userId){
		this.userId = userId;
	}
	public Long getUserId(){
		return this.userId;
	}
	public void setCoverUrl(String coverUrl){
		this.coverUrl = coverUrl;
	}
	public String getCoverUrl(){
		return this.coverUrl;
	}
	public void setAuthorAvatarUrl(String authorAvatarUrl){
		this.authorAvatarUrl = authorAvatarUrl;
	}
	public String getAuthorAvatarUrl(){
		return this.authorAvatarUrl;
	}
	public void setNickname(String nickname){
		this.nickname =nickname;
	}
	public String getNickname(){
		return this.nickname;
	}
	public void setIssueTimeStamp(Timestamp issueTimeStamp){
		this.issueTimeStamp = issueTimeStamp;
	}
	public Timestamp getIssueTimeStamp(){
		return this.issueTimeStamp;
	}
	public void setTitle(String title){
		this.title =title;
	}
	public String getTitle(){
		return this.title;
	}
	public void setDescription(String description){
		this.description = description;
	}
	public String getDescription() {
		return this.description;
	}
	public void setImgUrl(String imgUrl){
		this.imgUrl = imgUrl;
	}
	public String getImgUrl() {
		return this.imgUrl;
	}
}
