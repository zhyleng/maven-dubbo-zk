package com.netease.esp.ecos.mainsite.csr.vo;

import java.sql.Timestamp;
import java.util.List;

import com.netease.esp.ecos.csr.model.Share;

public class RecruitDetailVo {
	private String token;
	private Long recruitId;
	private Long recruitType;
	private Integer cityCode;
	private String title;
	private String description;
	private Double price;
	private String priceUnit;
	private Long userId;
	private String imId;
	private String avatarUrl;
	private String nickname;
	private Long gender;
	private String coverUrl;
	private Timestamp issueTimeStamp;
	private Long distance;
	private List<DetailShareVo> shares;
	/**
	 * @return the token
	 */
	public String getToken() {
		return token;
	}
	/**
	 * @param token the token to set
	 */
	public void setToken(String token) {
		this.token = token;
	}
	/**
	 * @return the recruitId
	 */
	public Long getRecruitId() {
		return recruitId;
	}
	/**
	 * @param recruitId the recruitId to set
	 */
	public void setRecruitId(Long recruitId) {
		this.recruitId = recruitId;
	}
	/**
	 * @return the recruitType
	 */
	public Long getRecruitType() {
		return recruitType;
	}
	/**
	 * @param recruitType the recruitType to set
	 */
	public void setRecruitType(Long recruitType) {
		this.recruitType = recruitType;
	}
	/**
	 * @return the cityCode
	 */
	public Integer getCityCode() {
		return cityCode;
	}
	/**
	 * @param cityCode the cityCode to set
	 */
	public void setCityCode(Integer cityCode) {
		this.cityCode = cityCode;
	}
	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the price
	 */
	public Double getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(Double price) {
		this.price = price;
	}
	/**
	 * @return the priceUnit
	 */
	public String getPriceUnit() {
		return priceUnit;
	}
	/**
	 * @param priceUnit the priceUnit to set
	 */
	public void setPriceUnit(String priceUnit) {
		this.priceUnit = priceUnit;
	}
	/**
	 * @return the userId
	 */
	public Long getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	/**
	 * @return the imId
	 */
	public String getImId() {
		return imId;
	}
	/**
	 * @param imId the imId to set
	 */
	public void setImId(String imId) {
		this.imId = imId;
	}
	/**
	 * @return the avatarUrl
	 */
	public String getAvatarUrl() {
		return avatarUrl;
	}
	/**
	 * @param avatarUrl the avatarUrl to set
	 */
	public void setAvatarUrl(String avatarUrl) {
		this.avatarUrl = avatarUrl;
	}
	/**
	 * @return the nickname
	 */
	public String getNickname() {
		return nickname;
	}
	/**
	 * @param nickname the nickname to set
	 */
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	/**
	 * @return the gender
	 */
	public Long getGender() {
		return gender;
	}
	/**
	 * @param gender the gender to set
	 */
	public void setGender(Long gender) {
		this.gender = gender;
	}
	/**
	 * @return the coverUrl
	 */
	public String getCoverUrl() {
		return coverUrl;
	}
	/**
	 * @param coverUrl the coverUrl to set
	 */
	public void setCoverUrl(String coverUrl) {
		this.coverUrl = coverUrl;
	}
	/**
	 * @return the issueTimeStamp
	 */
	public Timestamp getIssueTimeStamp() {
		return issueTimeStamp;
	}
	/**
	 * @param issueTimeStamp the issueTimeStamp to set
	 */
	public void setIssueTimeStamp(Timestamp issueTimeStamp) {
		this.issueTimeStamp = issueTimeStamp;
	}
	
	/**
	 * @return the distance
	 */
	public Long getDistance() {
		return distance;
	}
	/**
	 * @param distance the distance to set
	 */
	public void setDistance(Long distance) {
		this.distance = distance;
	}
	
	/**
	 * @return the shares
	 */
	public List<DetailShareVo> getShares() {
		return shares;
	}
	/**
	 * @param shares the shares to set
	 */
	public void setShares(List<DetailShareVo> shares) {
		this.shares = shares;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "RecruitDetailVo [token=" + token + ", recruitId=" + recruitId + ", recruitType=" + recruitType
				+ ", cityCode=" + cityCode + ", title=" + title + ", description=" + description + ", price=" + price
				+ ", priceUnit=" + priceUnit + ", userId=" + userId + ", imId=" + imId + ", avatarUrl=" + avatarUrl
				+ ", nickname=" + nickname + ", gender=" + gender + ", coverUrl=" + coverUrl + ", issueTimeStamp="
				+ issueTimeStamp + ", distance=" + distance + "]";
	}

}
