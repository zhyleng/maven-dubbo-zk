package com.netease.esp.ecos.mainsite.controller.vo.activity;

import java.util.List;

public class CitiesVO {

	private List<CityVO> cities;

	public List<CityVO> getCities() {
		return cities;
	}

	public void setCities(List<CityVO> cities) {
		this.cities = cities;
	}
	
}
