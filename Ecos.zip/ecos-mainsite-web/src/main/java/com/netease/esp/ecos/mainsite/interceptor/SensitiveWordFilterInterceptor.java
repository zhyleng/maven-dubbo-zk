package com.netease.esp.ecos.mainsite.interceptor;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.netease.esp.ecos.mainsite.interceptor.anno.FilterSensitiveWord;

public class SensitiveWordFilterInterceptor extends HandlerInterceptorAdapter {
	
	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		super.afterCompletion(request, response, handler, ex);
	}

	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		// handler其实是一个封装了controller 对应的一个处理方法
		boolean result = true;
		HandlerMethod handlerMethod = (HandlerMethod) handler;
		Method method = handlerMethod.getMethod();

		FilterSensitiveWord filterSensitiveWord = method.getAnnotation(FilterSensitiveWord.class);
		System.out.println("filterSensitiveWord: " + filterSensitiveWord);

		/** 敏感词过滤 */
		if (filterSensitiveWord != null) {
//			request = new HttpSensitiveWordFilterRequest(request);
		}
		return result;
	}
	
	static class KeyWordFilter {  

		private static Pattern pattern = null;  

		static {
			initPattern();
		}
		
		public static void initPattern(){  
			StringBuffer patternBuf = new StringBuffer("");  
			try {  
				InputStream in = KeyWordFilter.class.getClassLoader().getResourceAsStream("config/word.properties");  
				Properties pro = new Properties();  
				pro.load(in);  
				Enumeration<?> enu = pro.propertyNames();   
				while(enu.hasMoreElements()){  
					patternBuf.append((String)enu.nextElement()+"|");  
				}  
				patternBuf.deleteCharAt(patternBuf.length()-1);  
				pattern = Pattern.compile(new String(patternBuf.toString().getBytes("ISO-8859-1"), "UTF-8"),Pattern.CASE_INSENSITIVE); //编译一个正则表达式，同时生成Pattern  
			} catch (IOException ioEx){  
				ioEx.printStackTrace();  
			}  
		}  
		
		public static String doFilter(String str){  
			try {  
//				System.out.println("init pattern:" + pattern.pattern());
				Matcher m = pattern.matcher(str); //匹配到得用去掉  
				str = m.replaceAll("桔子");  
			}catch (Exception e){  
				e.printStackTrace();  
			}  
			return str;  
		}  
		
	} 
	
	public static class HttpSensitiveWordFilterRequest extends javax.servlet.http.HttpServletRequestWrapper {
		private HttpServletRequest request = null;
		public HttpSensitiveWordFilterRequest(HttpServletRequest request) {
			super(request);
			this.request = request;
			// TODO Auto-generated constructor stub
		}

		//重写获取
		@Override
		public String getParameter(String name) {
//			LoggerUtil.logger.info("filterSensitiveWord name:" + name);
			String parameter = request.getParameter(name);
			if(parameter != null) {
				parameter = cleanXSS(parameter);
			}
			return parameter;
		}
		
		
		public static String cleanXSS(String value){
			value = value.replaceAll("<+\\s*\\w+[\\s:][^/>]*/?>", "*");
			value = KeyWordFilter.doFilter(value);
			return value;
		}
	}
}
