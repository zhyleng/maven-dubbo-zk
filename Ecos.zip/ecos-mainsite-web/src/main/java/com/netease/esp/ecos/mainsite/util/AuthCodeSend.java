package com.netease.esp.ecos.mainsite.util;

import java.util.Random;

import com.netease.esp.ecos.util.sms.SmsTemplat;
import com.netease.esp.ecos.util.sms.TemplateSMS;

public class AuthCodeSend {

    public static void main(String[] args) {
        System.out.println((new Random().nextInt(900000) + 100000));
    }

    public static int send(String phone, Integer sendCode) {
        int authCode = -1;
        if(sendCode == null) {
            authCode = new Random().nextInt(900000) + 100000;									//随机生成6位验证码
        } else {
            authCode = sendCode;
        }
        //发送验证码实现
//		HttpClient client = new HttpClient();
//		PostMethod post = new PostMethod("http://utf8.sms.webchinese.cn"); 
//		post.setRequestHeader("Content-Type","application/x-www-form-urlencoded;charset=utf-8");//在头文件中设置转码
//		NameValuePair[] data ={ new NameValuePair("Uid", WANGJIAN_UID),new NameValuePair("Key", WANGJIAN_KEY_MD5),
//				new NameValuePair("smsMob",phone),new NameValuePair("smsText",authCode + " 验证码, 十分钟内有效。")};
//		post.setRequestBody(data);
//		try {
//			client.executeMethod(post);
//		} catch (HttpException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//		int statusCode = post.getStatusCode();													//请求结果状态码
//		int result = -1;																		//短信验证发送返回结果
//		try {
//			result = Integer.parseInt(new String(post.getResponseBodyAsString().getBytes("UTF-8")));
//		} catch (UnsupportedEncodingException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		} catch (Exception e) {
//			System.out.println("Number Format Error!");
//		}
//		post.releaseConnection();
//
//		if(result <= 0 || statusCode != 200) {
//			System.out.println("result:" + result);
//			System.out.println("获取验证码，网建返回结果:" + result);
//			authCode = -1;																		//若请求不成功则返回-1
//		}
        StringBuffer stringBuffer = new StringBuffer();
        Integer authCodeOb = new Integer(authCode);
        stringBuffer.append(authCodeOb.toString());
        stringBuffer.append(",10");
        SmsTemplat.sendSMS(phone, stringBuffer.toString());
        return authCode;
    }
}
