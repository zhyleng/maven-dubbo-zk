package com.netease.esp.ecos.mainsite.csr.vo;

import java.sql.Timestamp;

import org.springframework.web.bind.ServletRequestBindingException;

public class RecruitShareVo {
	private Long shareId;
	private String coverUrl;
	private Boolean hasPraised;
	private String title;
	private Timestamp issueTimeStamp;
	private Long commentNum;
	private Long praiseNum;
	private Long totalImages;
	/**
	 * @return the shareId
	 */
	public Long getShareId() {
		return shareId;
	}
	/**
	 * @param shareId the shareId to set
	 */
	public void setShareId(Long shareId) {
		this.shareId = shareId;
	}
	/**
	 * @return the coverUrl
	 */
	public String getCoverUrl() {
		return coverUrl;
	}
	/**
	 * @param coverUrl the coverUrl to set
	 */
	public void setCoverUrl(String coverUrl) {
		this.coverUrl = coverUrl;
	}
	/**
	 * @return the hasPraised
	 */
	public Boolean getHasPraised() {
		return hasPraised;
	}
	/**
	 * @param hasPraised the hasPraised to set
	 */
	public void setHasPraised(Boolean hasPraised) {
		this.hasPraised = hasPraised;
	}
	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return the issueTimeStamp
	 */
	public Timestamp getIssueTimeStamp() {
		return issueTimeStamp;
	}
	/**
	 * @param issueTimeStamp the issueTimeStamp to set
	 */
	public void setIssueTimeStamp(Timestamp issueTimeStamp) {
		this.issueTimeStamp = issueTimeStamp;
	}
	/**
	 * @return the commentNum
	 */
	public Long getCommentNum() {
		return commentNum;
	}
	/**
	 * @param commentNum the commentNum to set
	 */
	public void setCommentNum(Long commentNum) {
		this.commentNum = commentNum;
	}
	/**
	 * @return the praiseNum
	 */
	public Long getPraiseNum() {
		return praiseNum;
	}
	/**
	 * @param praiseNum the praiseNum to set
	 */
	public void setPraiseNum(Long praiseNum) {
		this.praiseNum = praiseNum;
	}
	/**
	 * @return the totalImages
	 */
	public Long getTotalImages() {
		return totalImages;
	}
	/**
	 * @param totalImages the totalImages to set
	 */
	public void setTotalImages(Long totalImages) {
		this.totalImages = totalImages;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "RecruitShareVo [shareId=" + shareId + ", coverUrl=" + coverUrl + ", hasPraised=" + hasPraised
				+ ", title=" + title + ", issueTimeStamp=" + issueTimeStamp + ", commentNum=" + commentNum
				+ ", praiseNum=" + praiseNum + ", totalImages=" + totalImages + "]";
	}
}
