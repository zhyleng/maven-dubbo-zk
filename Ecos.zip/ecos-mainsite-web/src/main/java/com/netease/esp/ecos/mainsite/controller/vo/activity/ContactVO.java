package com.netease.esp.ecos.mainsite.controller.vo.activity;

public class ContactVO {
	private int contactType;
	private String contactValue;
	public ContactVO(){
		
	}
	public ContactVO(int contactType, String contactValue) {
		this.contactValue = contactValue;
		this.contactType = contactType;
	}
	public int getContactType() {
		return contactType;
	}
	public void setContactType(int contactType) {
		this.contactType = contactType;
	}
	public String getContactValue() {
		return contactValue;
	}
	public void setContactValue(String contactValue) {
		this.contactValue = contactValue;
	}
	
}
