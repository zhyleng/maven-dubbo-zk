package com.netease.esp.ecos.mainsite.controller.csr;


import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.alibaba.fastjson.JSONObject;
import com.netease.esp.ecos.csr.model.Recruit;
import com.netease.esp.ecos.csr.model.RecruitDis;
import com.netease.esp.ecos.csr.model.UserForRecruit;
import com.netease.esp.ecos.facade.csr.CommentFacade;
import com.netease.esp.ecos.facade.csr.RecruitFacade;
import com.netease.esp.ecos.mainsite.csr.vo.CreateRecruitVo;
import com.netease.esp.ecos.mainsite.csr.vo.RecruitDetailListVo;
import com.netease.esp.ecos.mainsite.csr.vo.RecruitDetailVo;
import com.netease.esp.ecos.mainsite.global.Response;
import com.netease.esp.ecos.mainsite.global.ResultCode;
import com.netease.esp.ecos.mainsite.interceptor.anno.CheckAuthorized;

@Controller
@RequestMapping(value = "/m/recruit")
public class RecruitController {
	Logger logger = Logger.getLogger(this.getClass());
	@Autowired
	RecruitFacade recruitFacade;
	@Autowired
	CommentFacade commentFacade;
	
	@RequestMapping(value = "/create")
	@ResponseBody
	@CheckAuthorized
	public Response createRecruit(@RequestParam(value="userId", required=true)Long userId,
		                          @RequestParam(value="token", required=false)String token,
		                          @RequestParam(value="recruitJson", required=true)String recruitJson){
		Response response = new Response();
		CreateRecruitVo createRecruitVo = new CreateRecruitVo();
		Recruit recruit = null;
		/**   解析Json   */
		JSONObject jsonObject = JSONObject.parseObject(recruitJson);
		String description = jsonObject.getString("description");
		Long shareId = jsonObject.getLong("shareId");
		String priceUnit = jsonObject.getString("priceUnit");
		String coverUrl = jsonObject.getString("coverUrl");
		String title = jsonObject.getString("title");
		Long recruitType = jsonObject.getLong("recruitType");
		Double price = jsonObject.getDouble("price");
		/**   创建recruit   */
	    recruit = recruitFacade.createRecruit(userId, price, description, shareId, priceUnit, coverUrl, title, recruitType);
	    /**   填充VO   */
	    if(recruit == null){
	    	response.setCode(ResultCode.GLOBAL_SERVER_ERROR);
			response.setData(null);
			response.setMsg("create failed");
			return response;
	    }
		createRecruitVo.setToken(token);
		createRecruitVo.setRecruitId(recruit.getRecruitId());
		createRecruitVo.setIssueTimeStamp(recruit.getIssueTimeStamp());
		createRecruitVo.setDescription(description);
		createRecruitVo.setPrice(price);
		createRecruitVo.setPriceUnit(priceUnit);
		createRecruitVo.setCoverUrl(coverUrl);
		createRecruitVo.setTitle(title);
		createRecruitVo.setRecruitType(recruitType);
	    /**   填充Response   */
		response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
		response.setData(createRecruitVo);
		response.setMsg("create recruit successful");
		return response;
	}
	@RequestMapping(value = "/list")
	@ResponseBody
	@CheckAuthorized
	public Response getDetailList(@RequestParam(value="userId", required=true)Long userId,
								  @RequestParam(value="token", required=false)String token,
								  @RequestParam(value="isMyself", required=true)Boolean isMyself,
								  @RequestParam(value="recruitType", required=true)Long recruitType,
								  @RequestParam(value="cityCode", required=false)Long cityCode,
								  @RequestParam(value="sortRule", required=true)String sortRule,
								  @RequestParam(value="pageSize", required=true)Long pageSize,
								  @RequestParam(value="pages", required=true)Long pages){
		Response response = new Response();
		RecruitDetailListVo recruitDetailListVo = new RecruitDetailListVo();
		List<RecruitDetailVo> recruits = new ArrayList<RecruitDetailVo>();
		/** 获取符合条件的招募列表*/
		List<RecruitDis> recruitsrecruitlist = recruitFacade.getDetailList(userId, isMyself, recruitType, cityCode, sortRule, pageSize, pages); 
		if(recruitsrecruitlist != null)
		{
			for (RecruitDis r : recruitsrecruitlist) {
				RecruitDetailVo tmp = new RecruitDetailVo();
				UserForRecruit userForRecruit = new UserForRecruit();
				/** 获取发布招募人的信息*/
				userForRecruit = recruitFacade.getUserForRecruit(r.getUserId());
				if(userForRecruit != null){
					tmp.setRecruitId(r.getRecruitId());
					tmp.setRecruitType(r.getRecruitType());
					tmp.setCityCode(userForRecruit.getCityCode());
					tmp.setTitle(r.getTitle());
					tmp.setUserId(r.getUserId());
					tmp.setImId(userForRecruit.getImId());
					tmp.setAvatarUrl(commentFacade.getAvatarUrlByUserId(r.getUserId()));
					tmp.setNickname(userForRecruit.getNickname());
					tmp.setGender(userForRecruit.getGender());
					tmp.setCoverUrl(r.getCoverUrl());
					tmp.setIssueTimeStamp(r.getIssueTimeStamp());
					tmp.setDistance(r.getDistance());  
					tmp.setPrice(r.getPrice());
					tmp.setPriceUnit(r.getPriceUnit());
					recruits.add(tmp);
				}
			}
		}
		/**  填充vo */
		recruitDetailListVo.setToken(token);
		recruitDetailListVo.setRecruitList(recruits);
		/**  填充Response */
		response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
		response.setData(recruitDetailListVo);
		response.setMsg("get detail list successful");
		return response;
	}
	@RequestMapping(value = "/detail")
	@ResponseBody
	@CheckAuthorized
	public Response getDetail(@RequestParam(value="userId", required=true)Long userId,
			                  @RequestParam(value="token", required=false)String token,
			                  @RequestParam(value="recruitId", required=true)Long recruitId){
		Response response = new Response();
		RecruitDis recruit = new RecruitDis();
		UserForRecruit userForRecruit = new UserForRecruit();
		RecruitDetailVo recruitDetailVo = new RecruitDetailVo();
		/**  获取招募详情 */
		recruit = recruitFacade.getDetailRecruit(recruitId,userId);
		/**  获取发布者详情 */
		userForRecruit = recruitFacade.getUserForRecruit(recruit.getUserId());
		/**  获取头像 */
		String avatarUrl = commentFacade.getAvatarUrlByUserId(recruit.getUserId());
		/**  填充VO */
		recruitDetailVo.setToken(token);
		recruitDetailVo.setRecruitId(recruitId);
		recruitDetailVo.setRecruitType(recruit.getRecruitType());
		recruitDetailVo.setCityCode(userForRecruit.getCityCode());
		recruitDetailVo.setTitle(recruit.getTitle());
		recruitDetailVo.setDescription(recruit.getDescription());
		recruitDetailVo.setPrice(recruit.getPrice());
		recruitDetailVo.setPriceUnit(recruit.getPriceUnit());
		recruitDetailVo.setUserId(userId);
		recruitDetailVo.setImId(userForRecruit.getImId());
		recruitDetailVo.setAvatarUrl(avatarUrl);
		recruitDetailVo.setNickname(userForRecruit.getNickname());
		recruitDetailVo.setGender(userForRecruit.getGender());
		recruitDetailVo.setCoverUrl(recruit.getCoverUrl());
		recruitDetailVo.setIssueTimeStamp(recruit.getIssueTimeStamp());
		recruitDetailVo.setDistance(recruit.getDistance());
		/**  填充Response */
		response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
		response.setData(recruitDetailVo);
		response.setMsg("get recruit detail successful");
		return response;
	}
	
/*	@RequestMapping(value = "/delete")
	@ResponseBody
	public Response delShare(Long userId,String token,Long shareId){
		Response response = new Response();
		return response;
	}*/
}
