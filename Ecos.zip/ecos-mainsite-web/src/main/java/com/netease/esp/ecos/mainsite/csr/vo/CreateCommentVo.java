package com.netease.esp.ecos.mainsite.csr.vo;

import java.sql.Timestamp;

import com.netease.esp.ecos.csr.model.Comment;
public class CreateCommentVo{

	private static final Long serialVersionUID = 1L;
	private String token;
	private Long commentId;
    private Long commentType;
    private Long commentTypeId;
    private Timestamp commentTimeStamp;
    private String content;
	private String avatarUrl;
	private Long fromId;
	private String fromNickname;
    private Long parentId;
	private String parentNickName;
	
	public String getToken() {
		return this.token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getAvatarUrl() {
		return this.avatarUrl;
	}
	public void setAvatarUrl(String avatarUrl) {
		this.avatarUrl = avatarUrl;
	}
	public Long getFromId() {
		return this.fromId;
	}
	public void setFromId(Long fromId) {
		this.fromId = fromId;
	}
	public String getFromNickname() {
		return this.fromNickname;
	}
	public void setFromNickname(String fromNickname) {
		this.fromNickname = fromNickname;
	}
	public String getParentNickName() {
		return this.parentNickName;
	}
	public void setParentNIickName(String parentNickName) {
		this.parentNickName = parentNickName;
	}
	public Long getCommentId() {
		return this.commentId;
	}
	public void setCommentId(Long commentId) {
		this.commentId = commentId;
	}
	public Long getCommentType() {
		return this.commentType;
	}
	public void setCommentType(Long commentType) {
		this.commentType = commentType;
	}
	public Long getCommentTypeId(){
		return this.commentTypeId;
	}
	public void setCommentTypeId(Long commentTypeId){
		this.commentTypeId = commentTypeId;
	}
    public String getContent(){
    	return this.content;
    }
    public void setContent(String content){
    	this.content = content;
    }
    public Timestamp getCommentTimeStamp(){
    	return this.commentTimeStamp;
    }
    public void setCommentTimeStampTime(Timestamp time){
    	this.commentTimeStamp = time;
    }
	public Long getParentId() {
		return this.parentId;
	}
	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}
}
