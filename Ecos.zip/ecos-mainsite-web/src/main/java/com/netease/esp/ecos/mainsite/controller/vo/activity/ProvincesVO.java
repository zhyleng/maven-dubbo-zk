package com.netease.esp.ecos.mainsite.controller.vo.activity;

import java.util.List;

public class ProvincesVO {

	private List<ProvinceVO> provinces;

	public List<ProvinceVO> getProvinces() {
		return provinces;
	}

	public void setProvinces(List<ProvinceVO> provinces) {
		this.provinces = provinces;
	}
	
}
