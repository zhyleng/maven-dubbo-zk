package com.netease.esp.ecos.mainsite.controller.course;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.netease.esp.ecos.course.model.Banner;
import com.netease.esp.ecos.facade.course.BannerFacade;
import com.netease.esp.ecos.mainsite.global.Response;
import com.netease.esp.ecos.mainsite.global.ResultCode;
import com.netease.esp.ecos.mainsite.interceptor.anno.CheckAuthorized;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/m/course")
public class BannerController {
    Logger logger = Logger.getLogger(this.getClass());
    @Autowired //它可以对类成员变量、方法及构造函数进行标注，完成自动装配的工作
            BannerFacade bannerFacade;

    @RequestMapping(value = "/banner")
    @ResponseBody
    public Response getBanner() {
        Response response = new Response();
        try {
            List<Banner> bannerList = bannerFacade.getBannerList();
            List<String> urlString = new ArrayList<>();
            for (Banner banner : bannerList) {
                urlString.add(banner.getBannerUrl());
                System.out.println(banner.toString());
            }


            String jsonString = JSON.toJSONString(urlString);

            System.out.println(jsonString);
            logger.warn("成功!");

            JSONObject result = new JSONObject();
            result.put("urls",urlString);

            response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
            response.setData(result);
            response.setMsg("successfully！");
            return response;

        } catch (Exception e) {
            e.printStackTrace();
            response.setCode(ResultCode.GLOBAL_PARAM_ERROR);
            response.setData("parameter error");
            response.setMsg("error");
            logger.error("发生错误！");
            return response;

        }
    }

}
