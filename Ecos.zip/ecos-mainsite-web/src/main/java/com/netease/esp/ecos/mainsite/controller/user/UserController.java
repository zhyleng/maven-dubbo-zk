package com.netease.esp.ecos.mainsite.controller.user;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.netease.esp.ecos.facade.user.TokenFacade;
import com.netease.esp.ecos.facade.user.UserFacade;
import com.netease.esp.ecos.mainsite.global.Response;
import com.netease.esp.ecos.mainsite.global.ResultCode;
import com.netease.esp.ecos.mainsite.global.session.HttpSession;
import com.netease.esp.ecos.mainsite.global.session.StandardHttpSession;
import com.netease.esp.ecos.mainsite.interceptor.anno.CheckAuthorized;
import com.netease.esp.ecos.mainsite.util.AuthCodeSend;
import com.netease.esp.ecos.redis.RedisTool;
import com.netease.esp.ecos.user.model.dto.UserDTO;
import com.netease.esp.ecos.user.service.TokenService;

@Controller
@RequestMapping(value={"/m/user"}, produces={"application/json;charset=UTF-8"})
public class UserController {
	private Logger logger = Logger.getLogger(this.getClass());
	@Resource
	private UserFacade userFacade;
	@Resource
	private TokenFacade tokenFacade;

	/**
	 * 验证码操作
	 * 	type get:获取
	 * 	type check:验证
	 */
	@RequestMapping(value="/authcode")
	@ResponseBody
	public Response authCode(@RequestParam(value="type")String type, 
			@RequestParam(value="phone", required=false)String phone,
			@RequestParam(value="code", required=false)String code,
			HttpServletRequest request, HttpServletResponse response) {
		Response result = null;
		/** 从Redis拿 session */
		RedisTool<String, HttpSession> redisTool= new RedisTool<String, HttpSession>();
		HttpSession session = null;
		String SESSIONID = StandardHttpSession.getSESSIONID(request);
		if(SESSIONID != null) {
			session = redisTool.get(SESSIONID);
		}
		/** 从Redis拿 session */
		switch (type) {
		case "get":
			if(session == null) {
				session = new StandardHttpSession(request, response);
			}

			Integer sendCode = null;
			if(session.getAttribute(phone) != null) {
				try {
					sendCode = Integer.parseInt((String) session.getAttribute(phone));
				} catch (Exception e) {
					sendCode = null;
				}
//				result = new Response(ResultCode.GLOBAL_PARAM_ERROR, null,"Have sent an authCode to user");
//				break;
			}

			int authCode = AuthCodeSend.send(phone, sendCode);
			if (authCode == -1) {												//说明获取验证码失败
				result = new Response(ResultCode.USER_AUTHCODE_GET_ERROR, null, "get authcode error! maybe yunxin failed!");
			} else {
				session.setAttribute(phone, authCode+"");						//将验证码存在session中
				JSONObject data = new JSONObject();
				data.put("code", authCode);
				result = new Response(ResultCode.GLOBAL_SUCCESSFUL, data, "successful");
			}
			if(session != null) {
				redisTool.set(session.getId(), session, 10*60);			//session 过期时间为10min
			}
			break;
		case "check":
			if(session != null) {														// 验证验证码
				Object auth = session.getAttribute(phone); 					//通过手机号拿到服务器存的验证码
				logger.debug("验证手机验证码：" + "\r\n 手机号：" + phone + "\t服务器验证码：" + auth);
				if(auth != null && auth.equals(code)) {
					session.removeAttribute(phone);
					result = new Response(ResultCode.GLOBAL_SUCCESSFUL, null, "successful!");
					redisTool.delete(session.getId());
				} else {
					result = new Response(ResultCode.USER_AUTHCODE_CHECK_ERROR, null, "auth code error!");
				}
			} else {
				result = new Response(ResultCode.USER_AUTHCODE_CHECK_EXPIRE, null, "auth code expire!");
			}
			break;
		default:
			result = new Response(201, null, "type is error! type is " + type + ", not is get or check.");
			break;
		}

		logger.debug(" Response ResultCode: " + result.getCode());
		logger.debug(" Response Content:\n" + JSON.toJSONString(result));
		return result;
	}

	/**
	 *  用户注册
	 */
	@RequestMapping(value="/register", method=RequestMethod.POST)
	@ResponseBody
	public Response register(@RequestParam(value="phone")String phone, 
			@RequestParam(value="name", required=false)String name,
			@RequestParam(value="avatarUrl", required=false)String avatarUrl,
			@RequestParam(value="pwd", required=false)String pwd,
			HttpServletRequest request, HttpServletResponse response) {
		Response result = null;

		UserDTO userDto = new UserDTO();
		userDto.setPhone(phone);
		userDto.setNickname(name);
		userDto.setPwd(pwd);
		userDto.setAvatarUrl(avatarUrl);
		userDto = userFacade.register(userDto);

		if(userDto == null) {
			return new Response(ResultCode.GLOBAL_SERVER_ERROR, null, "server exception! maybe database error or android param error.");
		} 

		if(userDto.getHasRegister()) {
			return new Response(ResultCode.USER_REGISTER_ACCOUNT_EXISTS, null, "the phone has registered.");
		}

		String updateToken = tokenFacade.getToken(userDto.getUserId());
		Cookie cookie = new Cookie(TokenService.TOKEN, updateToken);
		response.addCookie(cookie);

		userDto.setHasRegister(null);
		result = new Response(ResultCode.GLOBAL_SUCCESSFUL, userDto, "successful");

		logger.debug(" Response ResultCode: " + result.getCode());
		logger.debug(" Response Content:\n" + JSON.toJSONString(result));
		return result;
	}

	/**
	 *  用户登录
	 */
	@RequestMapping(value="/login", method=RequestMethod.POST)
	@ResponseBody
	public Response login(@RequestParam(value="phone")String phone, 
			@RequestParam(value="pwd", required=false)String pwd,
			HttpServletRequest request, HttpServletResponse response) {
		Response result = null;

		UserDTO userDto = new UserDTO();
		userDto.setPhone(phone);
		userDto.setPwd(pwd);
		userDto = userFacade.login(userDto);

		/** 密码错误 */
		if(userDto == null) {
			return new Response(ResultCode.USER_LOGIN_PWD_ERROR, null, "phone error or password error!");
		} 

		/** 手机未注册 */
		if(!userDto.getHasRegister()) {
			return new Response(ResultCode.USER_LOGIN_ACCOUNT_NOT_REGISTER, null, "the phone has not registered.");
		}

		/** 登录成功  传token*/
		String updateToken = tokenFacade.getToken(userDto.getUserId());
		Cookie cookie = new Cookie(TokenService.TOKEN, updateToken);
		response.addCookie(cookie);

		userDto.setHasRegister(null);
		userDto.setToken(null);
		result = new Response(ResultCode.GLOBAL_SUCCESSFUL, userDto, "successful");

		logger.debug(" Response ResultCode: " + result.getCode());
		logger.debug(" Response Content:\n" + JSON.toJSONString(result));
		return result;
	}

	/**
	 *  获取用户信息
	 */
	@RequestMapping(value="/info")
	@CheckAuthorized
	@ResponseBody
	public Response getUserInfo(@RequestParam(value="userId", required=false)Long id,
			@RequestParam(value="toUserId", required=false)Long toUserId,
			@RequestParam(value="type", required=false)String type,
			HttpServletRequest request) {
		Response result = null;
		
		if(type == null) {
//			return new Response(ResultCode.GLOBAL_PARAM_ERROR, null, "missed param type!");
			type = "self";
		}
		
		UserDTO userDto = null;
		switch (type) {
		case "self":
			userDto = userFacade.getUserDTO(id);
			break;
		case "other":
			userDto = userFacade.getOtherUserDTO(id, toUserId);
			break;
		default:
			return new Response(ResultCode.GLOBAL_PARAM_ERROR, null, "error param type=" + type);
		}

		/** 该用户不存在  */
		if(userDto == null) {
			return new Response(ResultCode.USER_INFO_NOT_EXISTS, null, "the user id is not exists in database!");
		} 

		/** 成功 */
		result = new Response(ResultCode.GLOBAL_SUCCESSFUL, userDto, "successful");

		logger.debug(" Response ResultCode: " + result.getCode());
		logger.debug(" Response Content:\n" + JSON.toJSONString(result));
		return result;
	}

	/**
	 *  修改密码
	 */
	@RequestMapping(value="/pwd/modify")
	@ResponseBody
	@CheckAuthorized
	public Response modifyPwd(@RequestParam(value="userId")long userId, 
			@RequestParam(value="oldPwd", required=false)String oldPwd,
			@RequestParam(value="newPwd", required=false)String newPwd,
			HttpServletRequest request) {
		Response result = null;

		boolean success = userFacade.modifyPwd(userId, oldPwd, newPwd);

		/** 旧密码错误  */
		if(!success) {
			return new Response(ResultCode.USER_PWD_MODIFY_OLD_PWD_ERROR, null, "the old password error!");
		} 

		/** 成功 */
		result = new Response(ResultCode.GLOBAL_SUCCESSFUL, null, "successful");

		logger.debug(" Response ResultCode: " + result.getCode());
		logger.debug(" Response Content:\n" + JSON.toJSONString(result));
		return result;
	}

	/**
	 *  忘记密码
	 */
	@RequestMapping(value="/pwd/reset")
	@ResponseBody
	public Response resetPwd(@RequestParam(value="phone")String phone, 
			@RequestParam(value="pwd", required=false)String pwd,
			HttpServletRequest request) {
		Response result = null;

		boolean success = userFacade.resetPwd(phone, pwd);		
		/** 手机号未注册  */
		if(!success) {
			return new Response(ResultCode.USER_PWD_RESET_PHONE_NOT_EXISTS, null, "the phone has not registered!");
		} 

		/** 成功 */
		result = new Response(ResultCode.GLOBAL_SUCCESSFUL, null, "successful");

		logger.debug(" Response ResultCode: " + result.getCode());
		logger.debug(" Response Content:\n" + JSON.toJSONString(result));
		return result;
	}

	/**
	 *  更新用户信息
	 */
	@CheckAuthorized
	@RequestMapping(value="/update")
	@ResponseBody
	public Response updateUserInfo(@RequestParam(value="userId")long userId, 
			@RequestParam(value="userInfo", required=false)String userInfo,
			HttpServletRequest request) {
		Response result = null;

		UserDTO userDto = null;
		try {
			userDto = JSON.parseObject(userInfo, UserDTO.class);
		} catch(Exception e) {
			return new Response(ResultCode.USER_UPDATE_JSON_PARSE_ERROR, null, "user info json parse error ! userInfo: " + userInfo);
		}
		userDto.setId(userId);


		userDto = userFacade.updateUser(userDto);

		/** 成功 */
		result = new Response(ResultCode.GLOBAL_SUCCESSFUL, userDto, "successful");

		logger.debug(" Response ResultCode: " + result.getCode());
		logger.debug(" Response Content:\n" + JSON.toJSONString(result));
		return result;
	}

	/**
	 *  用户定位
	 */
	@RequestMapping(value="/location")
	@ResponseBody
	public Response location(@RequestParam(value="userId")long userId, 
			@RequestParam(value="longitude")Double longitude, 
			@RequestParam(value="latitude")Double latitude, 
			HttpServletRequest request) {
		Response result = null;

		if(longitude != null && latitude != null) {
			UserDTO userDto = new UserDTO();
			userDto.setId(userId);
			userDto.setLatitude(latitude);
			userDto.setLongitude(longitude);
			userFacade.updateUser(userDto);
		}
		JSONObject obj = new JSONObject();
		obj.put("cityCode", 1);
		obj.put("cityName", "杭州");
		obj.put("provinceCode", 1);

		/** 成功 */
		result = new Response(ResultCode.GLOBAL_SUCCESSFUL, obj, "successful");

		logger.debug(" Response ResultCode: " + result.getCode());
		logger.debug(" Response Content:\n" + JSON.toJSONString(result));
		return result;
	}

}
