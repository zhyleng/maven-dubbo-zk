package com.netease.esp.ecos.mainsite.interceptor;

import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Locale;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

/***
 * 除去Https之外的API接口都要验证完整性
 * @author Alenjaki
 */
public class SignatureInterceptor extends HandlerInterceptorAdapter {
	private Logger logger = Logger.getLogger(this.getClass());
	private static final String AUTHORIZATION = "Authorization";
	private static final String DATE = "Date";
	private static final String HTTPS = "Https";

	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		boolean result = true;
		
		if(HTTPS.equalsIgnoreCase(request.getScheme())) {
			/** 对于Https请求的接口 不做完整性 */
			logger.info("接口请求类型：" + HTTPS);
			return true;
		}
		
		logger.info(request.getContextPath() + request.getServletPath() + "***********完整性验证**************");
		
		/** 验证完整性 */
		long start = System.currentTimeMillis();
		result = checkSignature(request); 
		long end = System.currentTimeMillis();
		logger.info("完整性验证耗时:" + (end - start) + "ms"); 

		if(!result) {
			logger.info("************验证完整性失败**********");
			/** 未通过完整性验证的 操作 (可以对拉黑IP等等)*/
			PrintWriter writer = response.getWriter();
//			writer.write(JSON.toJSONString(new ResponseDO(ResultCode.GLOBAL_SIGNATURE_CHECK_ERROR, null)));
			writer.flush();
			writer.close();
		}

		return result;
	}

	/**
	 * 验证签名
	 * 		签名生成规则:"HiChuJian:" + Utils.md5(请求实体 + "&" + 客户端确定的日期 + "&" + uri(servlet路径) + "&gnibop";
	 */
	private boolean checkSignature(HttpServletRequest request) {
		boolean result = false;
		String authorization = request.getHeader(AUTHORIZATION);
		String date = request.getHeader(DATE);
		String uri = request.getContextPath() + request.getServletPath();
		if(uri != null) {
			uri = uri.replaceAll("//", "/");
		}
		String data = null;
		StringBuffer sb = new StringBuffer("");
		Enumeration<String> params = request.getParameterNames();
		while(params.hasMoreElements()) {
			String name = params.nextElement();
			sb.append(name + "=" + request.getParameter(name) + "&");
		}
		
		if(sb.length() == 0) {//没有参数
			return true;
		}
		
		data = sb.deleteCharAt(sb.length() - 1).toString();
		System.out.println(request.getMethod() + " data:" + data);
		/** 服务器生成sign*/
		String sign = "HiChuJian:" + md5(data + "&" + date + "&" + uri + "&" + "gnibop");
		System.out.println("服务器计算出字串：" + data + "&" + date + "&" + uri + "&" + "gnibop");
		
		SimpleDateFormat formater = new SimpleDateFormat(
				"EEE, d MMM yyyy HH:mm:ss 'GMT'", Locale.US);
		formater.setTimeZone(TimeZone.getTimeZone("GMT"));
		System.out.println("Server GMT:" + formater.format(new Date()));
		System.out.println("sign: " + sign);
		if(sign.equals(authorization)) {
			logger.info("************验证完整性成功**********");
			result = true;
		}
		return result ;
	}

	/**
	 * 对字符串进行 MD5 加密
	 * @param str
	 *            待加密字符串
	 * @return 加密后字符串
	 */
	public static String md5(String str) {
		char hexDigits[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
				'A', 'B', 'C', 'D', 'E', 'F' };
		MessageDigest md5 = null;
		try {
			md5 = MessageDigest.getInstance("MD5");
			md5.update(str.getBytes("UTF-8"));
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
		byte[] encodedValue = md5.digest();
		int j = encodedValue.length;
		char finalValue[] = new char[j * 2];
		int k = 0;
		for (int i = 0; i < j; i++) {
			byte encoded = encodedValue[i];
			finalValue[k++] = hexDigits[encoded >> 4 & 0xf];
			finalValue[k++] = hexDigits[encoded & 0xf];
		}

		return new String(finalValue);
	}

}
