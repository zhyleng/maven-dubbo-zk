package com.netease.esp.ecos.mainsite.controller.activity;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.netease.esp.ecos.activity.model.Activity;
import com.netease.esp.ecos.activity.model.ActivityDTO;
import com.netease.esp.ecos.activity.model.City;
import com.netease.esp.ecos.activity.model.Province;
import com.netease.esp.ecos.activity.model.SignUp;
import com.netease.esp.ecos.facade.activity.ActivityFacade;
import com.netease.esp.ecos.facade.user.UserFacade;
import com.netease.esp.ecos.mainsite.controller.vo.activity.ActivityVO;
import com.netease.esp.ecos.mainsite.controller.vo.activity.ActivityVOListVO;
import com.netease.esp.ecos.mainsite.controller.vo.activity.CityVO;
import com.netease.esp.ecos.mainsite.controller.vo.activity.ContactVO;
import com.netease.esp.ecos.mainsite.controller.vo.activity.ProvinceVO;
import com.netease.esp.ecos.mainsite.controller.vo.activity.ProvincesVO;
import com.netease.esp.ecos.mainsite.controller.vo.activity.ResponseActivityVO;
import com.netease.esp.ecos.mainsite.controller.vo.activity.UserVO;
import com.netease.esp.ecos.mainsite.controller.vo.activity.UserVOListVO;
import com.netease.esp.ecos.mainsite.controller.vo.activity.CitiesVO;
import com.netease.esp.ecos.mainsite.global.Response;
import com.netease.esp.ecos.mainsite.global.ResultCode;
import com.netease.esp.ecos.mainsite.interceptor.anno.CheckAuthorized;
import com.netease.esp.ecos.user.model.dto.UserDTO;

@Controller
@RequestMapping(value={"/m/activity"}, produces={"application/json;charset=UTF-8"})
public class ActivityController {
	private Logger logger = Logger.getLogger(this.getClass());
	@Autowired
	ActivityFacade activityFacade;
	@Autowired
	UserFacade userFacade;
	 
	@RequestMapping(value = "/test")
	public String getActivity(@RequestParam(value="id", required=true) Long id, Model model) {
		try {
			Activity activity = activityFacade.getActivity(id, 1);
			System.out.println(activity.toString());
			model.addAttribute("activity", activity);
			logger.warn("成功!");
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("发生错误！");
		}
		return "activity";
	}
	
	@RequestMapping(value = "/create")
	@ResponseBody
	@CheckAuthorized
	public Response setActivity(
			@RequestParam(value="userId", required=true) Long id,
			@RequestParam(value="token", required=false) String token,
			@RequestParam(value="activityJson", required=true) String activityJson) {
		ActivityVO activityVO = JSONObject.parseObject(activityJson, ActivityVO.class);
		ActivityDTO activityDTO = new ActivityDTO();
		activityDTO.setTitle(activityVO.getTitle());
		activityDTO.setUserId(id.intValue());
		activityDTO.setDescription(activityVO.getDescription());
		activityDTO.setStartTime(activityVO.getStartDateStamp());
		activityDTO.setEndTime(activityVO.getEndDateStamp());
		activityDTO.setDayStartTime(activityVO.getDayStartTime());
		activityDTO.setDayEndTime(activityVO.getDayEndTime());
		activityDTO.setFee(activityVO.getFee());
		activityDTO.setType(activityVO.getActivityType());
		for (ContactVO contactVO : activityVO.getContacts()) {
			if (contactVO.getContactType() == 0) {
				activityDTO.setQq(contactVO.getContactValue());
			} else if (contactVO.getContactType() == 1) {
				activityDTO.setQqGroup(contactVO.getContactValue());
			} else if (contactVO.getContactType() == 2) {
				activityDTO.setWeibo(contactVO.getContactValue());
			} else if (contactVO.getContactType() == 3) {
				activityDTO.setPhone(contactVO.getContactValue());
			}
		}
		activityDTO.setProvinceId(activityVO.getProvinceCode());
		activityDTO.setCityCode(activityVO.getCityCode());
		activityDTO.setDetailAddress(activityVO.getAddress());
		activityDTO.setOwerUrl(activityVO.getLogoUrl());
		Response response = new Response();	
		
		try {
			activityDTO = activityFacade.setActivity(activityDTO);
			ResponseActivityVO responseActivityVO = new ResponseActivityVO();
			responseActivityVO.setActivityId(activityDTO.getId());
			responseActivityVO.setIssueTimeStamp(activityDTO.getCreateTime());
			responseActivityVO.setToken(token);
			response.setData(responseActivityVO);
			response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
			response.setMsg("successed");
		} catch (Exception e) {
			logger.error(e.getMessage());
			response.setMsg("failed");
			response.setCode(ResultCode.GLOBAL_SERVER_ERROR);
			return response;
		}
		return response;
	}
	
	@RequestMapping(value = "/list")
	@ResponseBody
	@CheckAuthorized
	public Response getActivityList(
			@RequestParam(value="userId", required=true) Long userId, 
			@RequestParam(value="token", required=false) String token,
			@RequestParam(value="isMyself", required=false) boolean isMyself,
			@RequestParam(value="provinceId", required=false) Long provinceId,
			@RequestParam(value="activityType", required=false) Long typeId,
			@RequestParam(value="pageSize", required=false) Long pageSize,
			@RequestParam(value="pages", required=false) Long pages) {
		Response response = new Response();
		List<ActivityDTO> activityDTOList = new ArrayList<ActivityDTO>();
		List<ActivityVO> activitys = new ArrayList<ActivityVO>();
		try {
			Long startPos = pages * pageSize;
			activityDTOList = activityFacade.getActivityDTOList(provinceId, typeId, userId, pageSize, startPos, isMyself);
			
			for (ActivityDTO activityDTO : activityDTOList) {
				ActivityVO activityVO = new ActivityVO();
				activityVO.setActivityType(activityDTO.getType());
				activityVO.setAddress(activityDTO.getDetailAddress());
				activityVO.setActivityId(activityDTO.getId());
				activityVO.setLogoUrl(activityDTO.getLogoUrl());
				activityVO.setTitle(activityDTO.getTitle());
				activityVO.setStartDateStamp(activityDTO.getStartTime());
				activityVO.setEndDateStamp(activityDTO.getEndTime());
				activityVO.setDayStartTime(activityDTO.getDayStartTime());
				activityVO.setDayEndTime(activityDTO.getDayEndTime());
				if (activityDTO.getCityName() != null)
					activityVO.setCityName(activityDTO.getCityName());
				activityVO.setCityCode(activityDTO.getCityCode());
				activityVO.setProvinceCode(activityDTO.getProvinceId());
				activityVO.setIssueTimeStamp(activityDTO.getCreateTime());
				activityVO.setHasStarted(activityDTO.isStarted());
				activityVO.setHasFinished(activityDTO.isFinished());
				activitys.add(activityVO);
			}
			response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
			ActivityVOListVO activityVOListVO = new ActivityVOListVO();
			activityVOListVO.setActivitys(activitys);
			activityVOListVO.setToken(token);
			response.setData(activityVOListVO);
			response.setMsg("successed");
		} catch (Exception e) {
			response.setCode(ResultCode.GLOBAL_SERVER_ERROR);
			response.setMsg("failed");
			logger.error(e.getMessage());
		}
		return response;
	}
	
	@RequestMapping(value = "/detail")
	@ResponseBody
	@CheckAuthorized
	public Response getActivity(
			@RequestParam(value="userId", required=true) Long userId,
			@RequestParam(value="token", required=false) String token,
			@RequestParam(value="activityId", required=true) Long activityId) {
		Response response = new Response();
		try {
			ActivityDTO activityDTO = new ActivityDTO();
			ActivityVO activityVO = new ActivityVO();
			activityDTO = activityFacade.getActivity(activityId, userId);
			activityVO.setToken(token);
			activityVO.setActivityId(activityDTO.getId());
			activityVO.setActivityType(activityDTO.getType());
			activityVO.setTitle(activityDTO.getTitle());
			activityVO.setLogoUrl(activityDTO.getLogoUrl());
			activityVO.setStartDateStamp(activityDTO.getStartTime());
			activityVO.setEndDateStamp(activityDTO.getEndTime());
			activityVO.setDayStartTime(activityDTO.getDayStartTime());
			activityVO.setDayEndTime(activityDTO.getDayEndTime());
			activityVO.setHasStarted(activityDTO.isStarted());
			activityVO.setHasFinished(activityDTO.isFinished());
			activityVO.setDescription(activityDTO.getDescription());
			activityVO.setFee(activityDTO.getFee());
			activityVO.setIssueTimeStamp(activityDTO.getCreateTime());
			activityVO.setAvatarUrl(activityDTO.getOwerUrl());
			activityVO.setNickName(activityDTO.getOwerNickName());
			activityVO.setProvinceCode(activityDTO.getProvinceId());
			activityVO.setCityCode(activityDTO.getCityCode());
			activityVO.setCityName(activityDTO.getCityName());
			activityVO.setAddress(activityDTO.getDetailAddress());
			activityVO.setUserId(activityDTO.getUserId());
			List<ContactVO> contactVOList = new ArrayList<ContactVO>();
			for (int i = 0; i <= 3; ++i) {
				ContactVO contactVO = new ContactVO();
				contactVO.setContactType(i);
				if (i == 0) {
					contactVO.setContactValue(activityDTO.getQq());
				} else if (i == 1) {
					contactVO.setContactValue(activityDTO.getQqGroup());
				} else if (i == 2) {
					contactVO.setContactValue(activityDTO.getWeibo());
				} else {
					contactVO.setContactValue(activityDTO.getPhone());
				}
				contactVOList.add(contactVO);
			}
			activityVO.setContacts(contactVOList);
			List<UserVO> userVOList = null;
			if (activityDTO.getSignUpUserIdList() != null) {
				userVOList = new ArrayList<UserVO>();
				for (int i = 0; i < activityDTO.getSignUpUserIdList().size(); ++i) {
					UserVO userVO = new UserVO();
					userVO.setAvatarUrl(activityDTO.getSignUpUserPhotoUrlList().get(i));
					userVO.setNickname(activityDTO.getSignUpUserNameList().get(i));
					userVO.setUserId(activityDTO.getSignUpUserIdList().get(i).intValue());
					userVOList.add(userVO);
				}
			}
			if (userVOList != null) {
				activityVO.setSignUpUsers(userVOList);
			}
			activityVO.setHasSignuped(activityDTO.isSignUp());
			response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
			response.setData(activityVO);
			response.setMsg("successed");
		} catch (Exception e) {
			response.setCode(ResultCode.GLOBAL_SERVER_ERROR);
			response.setMsg("failed");
			logger.error(e.getMessage());
		}
		return response;
	}
	
	@RequestMapping(value = "/delete")
	@ResponseBody
	@CheckAuthorized
	public Response delActivity(
			@RequestParam(value="userId", required=true) Long userId,
			@RequestParam(value="token", required=false) String token,
			@RequestParam(value="activityId", required=true) Long activityId) {
		Response response = new Response();
		try {
			ActivityDTO activityDTO = activityFacade.getActivity(activityId, userId);
			if (activityDTO.getStatus() == 0) {
				response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
				ActivityVO activityVO = new ActivityVO();
				activityVO.setActivityId(activityId.intValue());
				activityVO.setToken(token);
				response.setData(activityVO);
				response.setMsg("successed");
			} else {
				response.setCode(ResultCode.GLOBAL_SERVER_ERROR);
				ActivityVO activityVO = new ActivityVO();
				activityVO.setActivityId(activityId.intValue());
				activityVO.setToken(token);
				response.setData(activityVO);
				response.setMsg("activity exit, but can't be deleted");
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			response.setCode(ResultCode.GLOBAL_SERVER_ERROR);
			response.setMsg("failed");
		}
		return response;
	}
	
	@RequestMapping(value = "/signup")
	@ResponseBody
	@CheckAuthorized
	public Response signUpActivity(
			@RequestParam(value="userId", required=true) Long userId,
			@RequestParam(value="token", required=false) String token,
			@RequestParam(value="activityId", required=true) Long activityId,
			@RequestParam(value="type", required=true) String type){
		Response response = new Response();
		try {
			ActivityVO activityVO = new ActivityVO();
			if (type.compareTo("signup") == 0) {
				SignUp signUp = activityFacade.signUp(activityId, userId);
				if (signUp == null) {
					response.setCode(ResultCode.GLOBAL_SERVER_ERROR);
					response.setMsg("failed");
				} else if (signUp.getStatus() == 2) {
					response.setCode(ResultCode.GLOBAL_PARAM_ERROR);
					response.setMsg("user has signned up this activity");
				} else if (signUp.getStatus() == 1) {
					response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
					activityVO.setActivityId(activityId.intValue());
					activityVO.setHasSignuped(true);
					response.setData(activityVO);
					response.setMsg("successed");
				} else {
					response.setCode(ResultCode.GLOBAL_SERVER_ERROR);
					response.setMsg("failed");
				}
			} else if (type.compareTo("cancel") == 0) {
				SignUp signUp = activityFacade.cancelSignUp(activityId, userId);
				if (signUp == null) {
					response.setCode(ResultCode.GLOBAL_SERVER_ERROR);
					response.setMsg("haven't signup or can't signup");
				} else {
					response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
					activityVO.setActivityId(activityId.intValue());
					activityVO.setHasSignuped(false);
					response.setData(activityVO);
					response.setMsg("successed");
				}
			} else {
				response.setCode(ResultCode.GLOBAL_PARAM_ERROR);
				response.setMsg("param type is wrong");
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			response.setCode(ResultCode.GLOBAL_SERVER_ERROR);
			response.setMsg("failed");
		}
		return response;
	}
	
	@RequestMapping(value = "/signup/list")
	@ResponseBody
	@CheckAuthorized
	public Response getSignUpList(
			@RequestParam(value="userId", required=true) Long userId,
			@RequestParam(value="token", required=false) String token,
			@RequestParam(value="activityId", required=true) Long activityId,
			@RequestParam(value="pageSize", required=true) Long pageSize,
			@RequestParam(value="pages", required=true) Long pages){
		Response response = new Response();
		List<UserVO> users = new ArrayList<UserVO>();
		try {
			Long startPos = pages * pageSize;
			List<UserDTO> userDTOList = activityFacade.getUserList(activityId, startPos, pageSize);
			for (UserDTO userDTO : userDTOList) {
				UserVO userVO = new UserVO();
				userVO.setUserId(userDTO.getId().intValue());
				userVO.setIM_id(userDTO.getImId());
				userVO.setCharacterSignature(userDTO.getCharacterSignature());
				userVO.setNickname(userDTO.getNickname());
				userVO.setAvatarUrl(userDTO.getAvatarUrl());
				userVO.setRoleType(userDTO.getRoles());
				users.add(userVO);
			}
			response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
			UserVOListVO userVOListVO = new UserVOListVO();
			userVOListVO.setUsers(users);
			userVOListVO.setToken(token);
			response.setData(userVOListVO);
			response.setMsg("successed");
		} catch (Exception e) {
			logger.error(e.getMessage());
			response.setCode(ResultCode.GLOBAL_SERVER_ERROR);
			response.setMsg("failed");
		}
		return response;
		
	}
	
	@RequestMapping(value = "/city/list")
	@ResponseBody
	@CheckAuthorized
	public Response getCityList() {
		Response response = new Response();
		try {
			List<City> cityList = activityFacade.getCityList();
			List<CityVO> cities = new ArrayList<CityVO>();
			if (cityList != null && cityList.size() > 0) {
				for (City city : cityList) {
					CityVO cityVO = new CityVO();
					cityVO.setCityId(city.getId());
					cityVO.setCityName(city.getCityName());
					cityVO.setProvinceId(city.getProvinceId());
					cities.add(cityVO);
				}
			}
			CitiesVO citiesVO = new CitiesVO();
			citiesVO.setCities(cities);
			response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
			response.setData(citiesVO);
			response.setMsg("successed");
		} catch (Exception e) {
			logger.error(e.getMessage());
			response.setCode(ResultCode.GLOBAL_SERVER_ERROR);
			response.setMsg("failed");
		}
		return response;
	}
	
	@RequestMapping(value = "/province/list")
	@ResponseBody
	@CheckAuthorized
	public Response getProvinceList() {
		Response response = new Response();
		try {
			List<Province> provinceList = activityFacade.getProvinceList();
			List<ProvinceVO> provinces = new ArrayList<ProvinceVO>();
			if (provinceList != null && provinceList.size() > 0) {
				for (Province province : provinceList) {
					ProvinceVO provinceVO = new ProvinceVO();
					provinceVO.setProvinceId(province.getId());
					provinceVO.setProvinceName(province.getProvinceName());
					provinces.add(provinceVO);
				}
			}
			ProvincesVO provincesVO = new ProvincesVO();
			provincesVO.setProvinces(provinces);
			response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
			response.setData(provincesVO);
			response.setMsg("successed");
		} catch (Exception e) {
			logger.error(e.getMessage());
			response.setCode(ResultCode.GLOBAL_SERVER_ERROR);
			response.setMsg("failed");
		}
		return response;
	}
	
	@RequestMapping(value = "/testCity")
	public String getCityName(@RequestParam(value="id", required=true) Long id, Model model) {
		try {
			String cityName = activityFacade.getCityName(id.intValue());
			System.out.println(cityName);
			model.addAttribute("cityName", cityName);
			logger.warn("成功!");
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("发生错误！");
		}
		return "city";
	}
}
