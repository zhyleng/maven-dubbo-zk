package com.netease.esp.ecos.mainsite.controller.vo.activity;

import java.sql.Timestamp;

public class ResponseActivityVO {
	private String token;
	private Integer activityId;
	private Timestamp issueTimeStamp;
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public Integer getActivityId() {
		return activityId;
	}
	public void setActivityId(Integer activityId) {
		this.activityId = activityId;
	}
	public Timestamp getIssueTimeStamp() {
		return issueTimeStamp;
	}
	public void setIssueTimeStamp(Timestamp issueTimeStamp) {
		this.issueTimeStamp = issueTimeStamp;
	}
	
}
