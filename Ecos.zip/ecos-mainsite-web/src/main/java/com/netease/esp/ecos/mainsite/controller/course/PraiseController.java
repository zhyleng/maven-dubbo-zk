package com.netease.esp.ecos.mainsite.controller.course;

import com.alibaba.fastjson.JSONObject;
import com.netease.esp.ecos.course.model.Praise;
import com.netease.esp.ecos.facade.course.CourseFacade;
import com.netease.esp.ecos.facade.course.PraiseFacade;
import com.netease.esp.ecos.mainsite.global.Response;
import com.netease.esp.ecos.mainsite.global.ResultCode;
import com.netease.esp.ecos.mainsite.interceptor.anno.CheckAuthorized;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;

@Controller
@RequestMapping("/m/praise")
public class PraiseController {

    Logger logger = Logger.getLogger(this.getClass());

    @Resource
    CourseFacade courseFacade;
    @Resource
    PraiseFacade praiseFacade;


    @RequestMapping(value = "/create")
    @ResponseBody
    @CheckAuthorized
    public Response praiseCourse(@RequestParam(value = "userId", required = true) String userId,
                                 @RequestParam(value = "type", required = true) String type,
                                 @RequestParam(value = "refId", required = true) String refId,
                                 @RequestParam(value = "praiseType", required = true) String praiseType) {
        Response response = new Response();
        try {
            JSONObject jsonObject = new JSONObject();
            if (type.equals("praise")) {
                if (praiseFacade.judgePraiseOrNot(Long.parseLong(userId), Integer.parseInt(praiseType), Long.parseLong(refId))) {
                    response.setCode(ResultCode.COURSE_PRAISE_COURSE_OK);
                    response.setData(null);
                    response.setMsg("已经点赞过");
                    logger.info("已经点赞过哦！");
                    return response;
                } else {
                    Praise praise = praiseFacade.createPraise(Long.parseLong(userId), Integer.parseInt(praiseType), Long.parseLong(refId));
                    jsonObject.put("toCourseId", praise.getRefId());

                    response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
                    response.setData(jsonObject);
                    response.setMsg("点赞成功！");
                    return response;
                }
            }
            if (type.equals("cancel")) {
                if (praiseFacade.judgePraiseOrNot(Long.parseLong(userId), Integer.parseInt(praiseType), Long.parseLong(refId)) ) {

                    Praise praise = praiseFacade.cancelPraise(Long.parseLong(userId), Integer.parseInt(praiseType), Long.parseLong(refId));
                    jsonObject.put("toCourseId", praise.getRefId());

                    response.setCode(ResultCode.GLOBAL_SUCCESSFUL);
                    response.setData(jsonObject);
                    response.setMsg("取消成功！");
                    logger.info("取消成功！");
                    return response;
                }
                else{
                    response.setCode(ResultCode.COURSE_PRAISE_NO);
                    response.setData(null);
                    response.setMsg("你还没点赞过哦！");
                    logger.info("还未点赞过哦！");
                    return response;
                }
            }else {
                response.setCode(ResultCode.GLOBAL_PARAM_ERROR);
                response.setMsg("点赞参数错误");
                logger.error("点赞出错");
                return response;
            }
        }catch (ClassCastException e) {
            response.setCode(ResultCode.GLOBAL_PARAM_ERROR);
            response.setMsg("参数错误！");
            logger.error("create praise error");
            logger.error(e.getMessage());
            return response;
        }catch (NullPointerException e){
            response.setCode(ResultCode.GLOBAL_SERVER_ERROR);
            response.setMsg("服务器端错误");
            logger.error("delete praise error");
            logger.error(e.getMessage());
            return response;
        } catch (Exception e) {
            response.setCode(ResultCode.GLOBAL_PARAM_ERROR);
            response.setMsg("点赞参数错误");
            logger.error("点赞出错");
            logger.error(e.getMessage());
            return response;

        }
    }


    @RequestMapping(value = "/state")
    @ResponseBody
    @CheckAuthorized
    public Response getState(@RequestParam(value = "userId", required = true) String userId,
                             @RequestParam(value = "refId", required = true) String refId,
                             @RequestParam(value = "praiseType", required = true) String praiseType) {
        Response response = new Response();
        try {
            JSONObject jsonObject = new JSONObject();

            if (praiseFacade.judgePraiseOrNot(Long.parseLong(userId), Integer.parseInt(praiseType), Long.parseLong(refId))) {
                response.setCode(ResultCode.COURSE_PRAISE_COURSE_OK);
                response.setData(null);
                response.setMsg("已经点赞过");
                logger.info("已经点赞过哦！");
                return response;
            } else {
                response.setCode(ResultCode.COURSE_PRAISE_NO);
                response.setData(null);
                response.setMsg("你还没点赞过哦！");
                logger.info("还未点赞过哦！");
                return response;
            }

        }catch (ClassCastException e) {
            response.setCode(ResultCode.GLOBAL_PARAM_ERROR);
            response.setMsg("参数错误！");
            logger.error("delete praise error");
            logger.error(e.getMessage());
            return response;
        }catch (NullPointerException e){
            response.setCode(ResultCode.GLOBAL_SERVER_ERROR);
            response.setMsg("服务器端错误");
            logger.error("delete praise error");
            logger.error(e.getMessage());
            return response;
        } catch (Exception e) {
            response.setCode(ResultCode.GLOBAL_PARAM_ERROR);
            response.setMsg("查询点赞状态参数出错");
            logger.error("点赞查询出错");
            logger.error(e.getMessage());
            return response;

        }
    }
}
