package com.netease.esp.ecos.mainsite.controller.vo.activity;

import java.util.List;

public class ActivityVOListVO {

	private String token;
	private List<ActivityVO> activitys;
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public List<ActivityVO> getActivitys() {
		return activitys;
	}
	public void setActivitys(List<ActivityVO> activityVOList) {
		this.activitys = activityVOList;
	}
	
}
