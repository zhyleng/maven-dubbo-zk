package com.netease.esp.ecos.mainsite.global;

public class ResultCode {
	public static final int GLOBAL_SUCCESSFUL = 0;
	/** 80xx 代表全局错误码 */
	public static final int GLOBAL_TOKEN_ERROR = 8001;	//token错误
	public static final int GLOBAL_PARAM_ERROR = 8002;	//参数错误
	public static final int GLOBAL_SERVER_ERROR = 8003;	//异常
	
	/** 81xx 用户模块错误码  */
	public static final int USER_AUTHCODE_GET_ERROR = 8101;
	public static final int USER_AUTHCODE_CHECK_ERROR = 8102;
	public static final int USER_AUTHCODE_CHECK_EXPIRE = 8103;
	
	public static final int USER_REGISTER_ACCOUNT_EXISTS = 8105;
	
	public static final int USER_LOGIN_ACCOUNT_NOT_REGISTER = 8110;
	public static final int USER_LOGIN_PWD_ERROR = 8111;
	
	public static final int USER_INFO_NOT_EXISTS = 8115;
	
	public static final int USER_PWD_MODIFY_OLD_PWD_ERROR = 8120;
	
	public static final int USER_PWD_RESET_PHONE_NOT_EXISTS = 8125;
	
	public static final int USER_UPDATE_JSON_PARSE_ERROR = 8130;
	
	public static final int USER_FOLLOW_HAS_FOLLOWED = 8135;
	public static final int USER_FOLLOW_CANCEL_HAS_NOT_FOLLOWED = 8136;
	
	
	/** 82xx 教程模块错误码  */
	public static final int COURSE_CREATE_ERROR = 8201;
    public static final int COURSE_DELETE_ERROR = 8202;
    public static final int COURSE_DETAIL_ERROR = 8203;
    public static final int COURSE_LIST_ERROR = 8204;
    public static final int COURSE_ASSIGMENT_CREATE_ERROR = 8205;
    public static final int COURSE_ASSIGMENT_DELETE_ERROR = 8206;
    public static final int COURSE_ASSIGMENT_DETAIL_ERROR = 8207;
    public static final int COURSE_ASSIGMENT_LIST_ERROR = 8208;
    public static final int COURSE_PRAISE_OK = 8236;
    public static final int COURSE_PRAISE_NO = 8226;
    public static final int COURSE_PRAISE_COURSE_OK = 8235;
    public static final int COURSE_PRAISE_COURSE_NO = 8225;


	/** 83xx 活动模块错误码  */
	public static final int ACTIVITY_ = 8301;
	
	/** 84xx CSR模块错误码  */
	/** 参数验证                              */
	public static final int CSR_ = 8401;
	public static final int CSR_COMMENT_TYPE = 8402;      //commentType error
	public static final int CSR_COMMENT_CONTENT = 8403;   //content null
	public static final int CSR_COMMENT_PARENT_ID = 8404; //parentId illegal
	public static final int CSR_COMMENT_TYPE_ID = 8405;   //comment type id illegal
	public static final int CSR_COMMENT_ID = 8406;        //comment id illegal
	
	/** 数据库验证                           */
	public static final int CSR_COMMENT_CREATE = 8420;    //database can't create comment
	public static final int CSR_COMMENT_GET = 8421;       //database can't get comment
	
}

