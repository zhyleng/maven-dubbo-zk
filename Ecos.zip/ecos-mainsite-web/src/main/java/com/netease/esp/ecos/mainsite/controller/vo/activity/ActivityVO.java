package com.netease.esp.ecos.mainsite.controller.vo.activity;

import java.sql.Timestamp;
import java.util.List;

public class ActivityVO {
	private int userId;
	private int activityId;
	private String title;
	private int activityType;
	private String logoUrl;
	private Timestamp startDateStamp;
	private Timestamp endDateStamp;
	private String dayStartTime;
	private String dayEndTime;
	private String description;
	private double fee;
	private int provinceCode;
	private int cityCode;
	private String address;
	private List<ContactVO> contacts;
	
	private String cityName;
	private Timestamp issueTimeStamp;
	private boolean hasStarted;
	private boolean hasFinished;
	private String token;
	
	private String avatarUrl;
	private String nickName;
	private boolean hasSignuped;
	private List<UserVO> signUpUsers;
	
	public String getAvatarUrl() {
		return avatarUrl;
	}
	public void setAvatarUrl(String avatarUrl) {
		this.avatarUrl = avatarUrl;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getLogoUrl() {
		return logoUrl;
	}
	public void setLogoUrl(String logoUrl) {
		this.logoUrl = logoUrl;
	}
	public Timestamp getStartDateStamp() {
		return startDateStamp;
	}
	public void setStartDateStamp(Timestamp startDateStamp) {
		this.startDateStamp = startDateStamp;
	}
	public Timestamp getEndDateStamp() {
		return endDateStamp;
	}
	public void setEndDateStamp(Timestamp endDateStamp) {
		this.endDateStamp = endDateStamp;
	}
	public String getDayStartTime() {
		return dayStartTime;
	}
	public void setDayStartTime(String dayStartTime) {
		this.dayStartTime = dayStartTime;
	}
	public String getDayEndTime() {
		return dayEndTime;
	}
	public void setDayEndTime(String dayEndTime) {
		this.dayEndTime = dayEndTime;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getFee() {
		return fee;
	}
	public void setFee(double fee) {
		this.fee = fee;
	}
	public int getProvinceCode() {
		return provinceCode;
	}
	public void setProvinceCode(int provinceCode) {
		this.provinceCode = provinceCode;
	}
	public int getCityCode() {
		return cityCode;
	}
	public void setCityCode(int cityCode) {
		this.cityCode = cityCode;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public List<ContactVO> getContacts() {
		return contacts;
	}
	public void setContacts(List<ContactVO> contacts) {
		this.contacts = contacts;
	}
	public int getActivityType() {
		return activityType;
	}
	public void setActivityType(int activityType) {
		this.activityType = activityType;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public int getActivityId() {
		return activityId;
	}
	public void setActivityId(int activityId) {
		this.activityId = activityId;
	}
	public Timestamp getIssueTimeStamp() {
		return issueTimeStamp;
	}
	public void setIssueTimeStamp(Timestamp issueTimeStamp) {
		this.issueTimeStamp = issueTimeStamp;
	}
	public boolean isHasStarted() {
		return hasStarted;
	}
	public void setHasStarted(boolean hasStarted) {
		this.hasStarted = hasStarted;
	}
	public boolean isHasFinished() {
		return hasFinished;
	}
	public void setHasFinished(boolean hasFinished) {
		this.hasFinished = hasFinished;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public boolean isHasSignuped() {
		return hasSignuped;
	}
	public void setHasSignuped(boolean hasSignuped) {
		this.hasSignuped = hasSignuped;
	}
	public List<UserVO> getSignUpUsers() {
		return signUpUsers;
	}
	public void setSignUpUsers(List<UserVO> signUpUsers) {
		this.signUpUsers = signUpUsers;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
}
