package com.netease.esp.ecos.course.service.impl;

import com.alibaba.dubbo.common.json.JSONArray;
import com.alibaba.fastjson.JSON;
import com.netease.esp.ecos.course.dao.CourseDao;
import com.netease.esp.ecos.course.dao.PictureDao;
import com.netease.esp.ecos.course.dto.CourseDto;
import com.netease.esp.ecos.course.model.Course;
import com.netease.esp.ecos.course.model.Picture;
import com.netease.esp.ecos.course.service.CourseService;
import com.netease.esp.ecos.util.EntityDtoConverter;
import org.apache.log4j.Logger;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Service("courseService")
@Transactional
public class CourseServiceImpl implements CourseService {
    @Resource
    CourseDao courseDao;
    @Resource
    PictureDao pictureDao;

    Logger logger = Logger.getLogger(this.getClass());

    @Override
    public CourseDto createCourse(CourseDto courseDto) {

        Course course = new Course();
        EntityDtoConverter.DtoConvertEntity(courseDto, course);
        //教程封面图
        Picture coverPicture = new Picture();
        coverPicture.setUrl(courseDto.getCoverUrl());
        pictureDao.insert(coverPicture);
        course.setCoverUrlId(coverPicture.getId());

        //教程内容图片
        List<String> imgUrls = JSON.parseArray(courseDto.getImgUrls(), String.class);
        List<String> imgUrlsId = new ArrayList<>();
        for (String url : imgUrls) {
            Picture picture = new Picture();
            picture.setUrl(url);
            pictureDao.insert(picture);
            imgUrlsId.add(String.valueOf(picture.getId()));
        }
        course.setImgUrlsId(JSON.toJSONString(imgUrlsId));

        courseDao.insert(course);
        //新插入记录id
        long courseId = course.getId();
        Course newCourse = courseDao.query(courseId);
        EntityDtoConverter.entityConvertDto(newCourse,courseDto);
        courseDto.setType(TypeTransformInt(newCourse.getType()));


        logger.info("create course successfully!");
        return courseDto;


    }

    @Override
    public CourseDto deleteCourse(long id) {

        Course course = courseDao.query(id);
        pictureDao.delete(course.getCoverUrlId());

        List<String> imgUrlsId = JSON.parseArray(course.getImgUrlsId(), String.class);
        for (String imgUrlId : imgUrlsId) {
            pictureDao.delete(Long.parseLong(imgUrlId));
        }

        CourseDto courseDto = new CourseDto();
        EntityDtoConverter.entityConvertDto(course,courseDto);

        courseDao.delete(id);
        logger.info("delete course successfully");
        return courseDto;

    }

    @Override
    public CourseDto getCourse(long id) {

        CourseDto courseDto = new CourseDto();
        Course course = courseDao.query(id);

        EntityDtoConverter.entityConvertDto(course, courseDto);
        courseDto.setCoverUrl(pictureDao.query(course.getCoverUrlId()).getUrl());
        //获得course图片列表url
        List<String> imgUrlsId = JSON.parseArray(course.getImgUrlsId(), String.class);
        List<String> imgUrls = new ArrayList<String>();
        for (String imgUrlid : imgUrlsId) {
            imgUrls.add(pictureDao.query(Long.parseLong(imgUrlid)).getUrl());
        }
        courseDto.setImgUrls(JSON.toJSONString(imgUrls));

        logger.info("get course by id successfully!");
        return courseDto;


    }

    @Override
    public List<CourseDto> getCourseListByRecommendation(int offset, int size) {

        List<CourseDto> courseDtoList = new ArrayList<CourseDto>();
        List<Course> courseList = courseDao.queryByRecommendation(offset, size);

        for (Course course : courseList) {
            CourseDto courseDto = new CourseDto();
            EntityDtoConverter.entityConvertDto(course, courseDto);
            courseDto.setCoverUrl(pictureDao.query(course.getCoverUrlId()).getUrl());
            //获得course图片列表url
            List<String> imgUrlsId = JSON.parseArray(course.getImgUrlsId(), String.class);
            List<String> imgUrls = new ArrayList<String>();
            for (String imgUrlid : imgUrlsId) {
                imgUrls.add(pictureDao.query(Long.parseLong(imgUrlid)).getUrl());
            }
            courseDto.setImgUrls(JSON.toJSONString(imgUrls));

            courseDtoList.add(courseDto);
        }

        logger.info("get course by recommendation successfully!");
        return courseDtoList;


    }

    @Override
    public List<CourseDto> getCourseListByTime(String type,String keyWord,int offset, int size) {

        List<CourseDto> courseDtoList = new ArrayList<CourseDto>();
        List<Course> courseList = courseDao.queryByTime(type,keyWord,offset, size);

        for (Course course : courseList) {
            CourseDto courseDto = new CourseDto();
            EntityDtoConverter.entityConvertDto(course, courseDto);
            courseDto.setCoverUrl(pictureDao.query(course.getCoverUrlId()).getUrl());
            //获得course图片列表url
            List<String> imgUrlsId = JSON.parseArray(course.getImgUrlsId(), String.class);
            List<String> imgUrls = new ArrayList<String>();
            for (String imgUrlid : imgUrlsId) {
                imgUrls.add(pictureDao.query(Long.parseLong(imgUrlid)).getUrl());
            }
            courseDto.setImgUrls(JSON.toJSONString(imgUrls));

            courseDtoList.add(courseDto);
        }

        logger.info("get course by time successfully!");
        return courseDtoList;


    }

    @Override
    public List<CourseDto> getCourseListByPraise(String type,String keyWord,int offset, int size) {

        List<CourseDto> courseDtoList = new ArrayList<CourseDto>();
        List<Course> courseList = courseDao.queryByPraise(type,keyWord,offset, size);

        for (Course course : courseList) {
            CourseDto courseDto = new CourseDto();
            EntityDtoConverter.entityConvertDto(course, courseDto);
            courseDto.setCoverUrl(pictureDao.query(course.getCoverUrlId()).getUrl());
            //获得course图片列表url
            List<String> imgUrlsId = JSON.parseArray(course.getImgUrlsId(), String.class);
            List<String> imgUrls = new ArrayList<String>();
            for (String imgUrlid : imgUrlsId) {
                imgUrls.add(pictureDao.query(Long.parseLong(imgUrlid)).getUrl());
            }
            courseDto.setImgUrls(JSON.toJSONString(imgUrls));

            courseDtoList.add(courseDto);
        }

        logger.info("get course by praise successfully!");
        return courseDtoList;


    }

    @Override
    public List<CourseDto> getCourseListByCollect(String type,String keyWord,int offset, int size) {

        List<CourseDto> courseDtoList = new ArrayList<CourseDto>();
        List<Course> courseList = courseDao.queryByCollect(type,keyWord,offset, size);

        for (Course course : courseList) {
            CourseDto courseDto = new CourseDto();
            EntityDtoConverter.entityConvertDto(course, courseDto);
            courseDto.setCoverUrl(pictureDao.query(course.getCoverUrlId()).getUrl());
            //获得course图片列表url
            List<String> imgUrlsId = JSON.parseArray(course.getImgUrlsId(), String.class);
            List<String> imgUrls = new ArrayList<String>();
            for (String imgUrlid : imgUrlsId) {
                imgUrls.add(pictureDao.query(Long.parseLong(imgUrlid)).getUrl());
            }
            courseDto.setImgUrls(JSON.toJSONString(imgUrls));

            courseDtoList.add(courseDto);
        }

        logger.info("get course by collect successfully!");
        return courseDtoList;


    }

    @Override
    public List<CourseDto> getCourseListByMyself(long courseId, int offset, int size) {

        List<CourseDto> courseDtoList = new ArrayList<CourseDto>();
        List<Course> courseList = courseDao.queryByMyself(courseId, offset, size);

        for (Course course : courseList) {
            CourseDto courseDto = new CourseDto();
            EntityDtoConverter.entityConvertDto(course, courseDto);
            courseDto.setCoverUrl(pictureDao.query(course.getCoverUrlId()).getUrl());
            //获得course图片列表url
            List<String> imgUrlsId = JSON.parseArray(course.getImgUrlsId(), String.class);
            List<String> imgUrls = new ArrayList<String>();
            for (String imgUrlid : imgUrlsId) {
                imgUrls.add(pictureDao.query(Long.parseLong(imgUrlid)).getUrl());
            }
            courseDto.setImgUrls(JSON.toJSONString(imgUrls));

            courseDtoList.add(courseDto);
        }

        logger.info("get course by myself successfully!");
        return courseDtoList;

    }

    @Override
    public int updateCoursePraiseNum(long courseId,int type) {
        if(type == 0){
            courseDao.addCoursePraiseNum(courseId);
            return 1;
        }
        if(type == 1){
            courseDao.subCoursePraiseNum(courseId);
            return 1;
        }
        return 0;
    }
    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    public String TypeTransformInt(String input){
        if(input.equals("妆娘")) {
            return "1";
        }
        if(input.equals("摄影")) {
            return "2";
        }
        if(input.equals("后期")) {
            return "3";
        }
        if(input.equals("服装")) {
            return "4";
        }
        if(input.equals("道具")) {
            return "5";
        }
        if(input.equals("假发")) {
            return "6";
        }
        if(input.equals("心得")) {
            return "7";
        }
        if(input.equals("其他")) {
            return "8";
        }
        return "1";
    }
}
