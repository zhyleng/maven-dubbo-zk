package com.netease.esp.ecos.course.dao;

import com.netease.esp.ecos.course.model.Banner;
import org.springframework.dao.DataAccessException;

import java.util.List;

public interface BannerDao {
    int insert(Banner banner) throws DataAccessException;
    Banner query(long id) throws DataAccessException;
    List<Banner> queryAll() throws DataAccessException;
    int update(Banner banner) throws  DataAccessException;
    int delete(long bannerId) throws DataAccessException;
}
