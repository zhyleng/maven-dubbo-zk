package com.netease.esp.ecos.course.service.impl;

import com.netease.esp.ecos.course.dao.AssigmentDao;
import com.netease.esp.ecos.course.dao.PictureDao;
import com.netease.esp.ecos.course.dto.AssigmentDto;
import com.netease.esp.ecos.course.model.Assigment;
import com.netease.esp.ecos.course.model.Picture;
import com.netease.esp.ecos.course.service.AssigmentService;
import com.netease.esp.ecos.util.EntityDtoConverter;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Service("assigmentService")
@Transactional
public class AssigmentServiceImpl implements AssigmentService {

    Logger logger = Logger.getLogger(this.getClass());

    @Resource
    AssigmentDao assigmentDao;
    @Resource
    PictureDao pictureDao;

    @Override
    public AssigmentDto createAssigment(AssigmentDto assigmentDto) {

        Assigment assigment = new Assigment();
        EntityDtoConverter.DtoConvertEntity(assigmentDto, assigment);

        Picture picture = new Picture();
        picture.setUrl(assigmentDto.getImgUrl());
        pictureDao.insert(picture);
        assigment.setImgUrlId(picture.getId());

        assigmentDao.insert(assigment);
        //拿到作业id
        long courseId = assigment.getId();
        EntityDtoConverter.entityConvertDto(assigmentDao.query(courseId),assigmentDto);

        logger.info("assigment create successfully!");

        return assigmentDto;

    }

    @Override
    public AssigmentDto deteleAssigment(long id) {

        Long imgUrlId = assigmentDao.query(id).getImgUrlId();
        pictureDao.delete(imgUrlId);

        AssigmentDto assigmentDto = new AssigmentDto();
        EntityDtoConverter.entityConvertDto(assigmentDao.query(id), assigmentDto);

        assigmentDao.delete(id);

        logger.info("delete assigment successful!");
        return assigmentDto;

    }

    @Override
    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    public AssigmentDto getAssigment(long id) {
        try {
            AssigmentDto assigmentDto = new AssigmentDto();
            Assigment assigment = assigmentDao.query(id);

            EntityDtoConverter.entityConvertDto(assigment, assigmentDto);
            assigmentDto.setImgUrl(pictureDao.query(assigment.getImgUrlId()).getUrl());

            logger.info("select assigment detial successfully!");
            return assigmentDto;
        } catch (Exception e) {
            logger.error(e.getMessage());
            logger.error("select assigment detail error!");
            return null;
        }
    }

    @Override
    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    public List<AssigmentDto> getAssigmentList(long courseId,int offset,int size) {
        try {
            List<AssigmentDto> assigmentDtoList = new ArrayList<AssigmentDto>();
            List<Assigment> assigmentList = assigmentDao.queryListByCourseId(courseId,offset,size);

            for (Assigment assigment : assigmentList) {
                AssigmentDto assigmentDto = new AssigmentDto();
                EntityDtoConverter.entityConvertDto(assigment, assigmentDto);

                //获取图片URL
                assigmentDto.setImgUrl(pictureDao.query(assigment.getImgUrlId()).getUrl());
                assigmentDtoList.add(assigmentDto);
            }

            logger.info("get course list successfully!");
            return assigmentDtoList;

        } catch (Exception e) {
            logger.error("select assigment list error!");
            logger.error(e.getMessage());
            return null;
        }
    }

    @Override
    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    public List<AssigmentDto> getAssigmentListNoPage(long courseId) {
        try {
            List<AssigmentDto> assigmentDtoList = new ArrayList<AssigmentDto>();
            List<Assigment> assigmentList = assigmentDao.queryListByCourseIdNoPage(courseId);

            for (Assigment assigment : assigmentList) {
                AssigmentDto assigmentDto = new AssigmentDto();
                EntityDtoConverter.entityConvertDto(assigment, assigmentDto);

                //获取图片URL
                assigmentDto.setImgUrl(pictureDao.query(assigment.getImgUrlId()).getUrl());
                assigmentDtoList.add(assigmentDto);
            }

            logger.info("get course list successfully!");
            return assigmentDtoList;

        } catch (Exception e) {
            logger.error("select assigment list error!");
            logger.error(e.getMessage());
            return null;
        }
    }
}
