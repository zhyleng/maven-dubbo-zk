package com.netease.esp.ecos.course.dao;

import com.netease.esp.ecos.course.model.Praise;
import org.apache.ibatis.annotations.Param;
import org.springframework.dao.DataAccessException;

public interface PraiseDao {
    int insert(Praise praise) throws DataAccessException;
    int delete(long id) throws DataAccessException;
    Praise query(long id) throws DataAccessException;
    long selectPraiseCount(@Param("type")int type, @Param("refId")long refId) throws DataAccessException;
    Praise queryByContent(@Param("userId")long userId,@Param("type")int type, @Param("refId")long refId) throws DataAccessException;
}
