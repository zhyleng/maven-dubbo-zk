package com.netease.esp.ecos.course.app;

import com.netease.esp.ecos.course.model.Banner;
import com.netease.esp.ecos.course.model.Course;
import com.netease.esp.ecos.course.model.Picture;
import com.netease.esp.ecos.course.service.BannerService;
import com.netease.esp.ecos.course.service.CourseService;
import com.netease.esp.ecos.course.service.impl.BannerServiceImpl;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

public class App {
	public static boolean close = false;
	public static void main(String[] args) {

		System.out.println("ecos-course-provider 启动 ..." + System.getProperty("url.dir"));
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(new String[] {"classpath:config/spring.xml", "classpath:config/dubbo.xml"});
		context.start();

        /**
         * getBannerList() scl

        BannerService bannerService = (BannerService)context.getBean("bannerService");
        List<Banner> bannerList = bannerService.getBannerList();
        for(Banner banner : bannerList) {
            System.out.println(banner.toString());
        }
         */

        /**
         * getCourseListByRecommendation() scl

         CourseService courseService = (CourseService)context.getBean("courseService");
         List<Course> courseList = courseService.getCourseListByRecommendation(20, 10);
         for(Course course : courseList) {
             System.out.println(course.toString());
         }
         */

        /**
         * getCourseListByRecommendation()     getCourseListByTime() getCourseListByPraise() getCourseListByCollect() scl
         * pass

         CourseService courseService = (CourseService)context.getBean("courseService");
         List<Course> courseList = courseService.getCourseListByCollect(0, 10);
         for(Course course : courseList) {
         System.out.println(course.toString());
         }

         */

        /**
         * createCourse()   scl
         * pass

         CourseService courseService = (CourseService)context.getBean("courseService");
         Course course =new Course();
        course.setType("假发");
        course.setTitle("dao insert");
        course.setUserId(3);
        course.setCoverUrl(4);
        course.setContents("content list[4,5,6]");
        //course.setImgs("content list[4,5,6]");
         System.out.println(course.toString());
        System.out.println(courseService.createCourse(course));
         */

        /**
         * deleteCourse()scl
         * pass

        CourseService courseService= (CourseService)context.getBean("courseService");
        System.out.println(courseService.deleteCourse(132));
         */

        /**
         * getPicture() createPicture() deletePicture()  getPictureByUrl()  scl
         * pass

        PictureService pictureService = (PictureService)context.getBean("pictureService");
        //System.out.println(pictureService.deletePicture(7));
        Picture picture = new Picture();
        picture.setUrl("www.163.com");
        System.out.println(pictureService.createPicture(picture));
        System.out.println(picture.getId());
        //System.out.println(pictureService.getPictureByUrl("www.163.com").toString());
         */

		System.out.println("ecos-course-provider 运行中 ...");
		Runtime r = Runtime.getRuntime();
		System.out.println("free mem:" + r.freeMemory()/(1024*1024) + "M");
		System.out.println("total mem:" + r.totalMemory()/(1024*1024) + "M");
		System.out.println("max mem:" + r.maxMemory()/(1024*1024) + "M");
		while(!close) {
		}
		context.close();
	}
}
