package com.netease.esp.ecos.course.dao;

import com.netease.esp.ecos.course.model.Assigment;
import org.apache.ibatis.annotations.Param;
import org.springframework.dao.DataAccessException;

import java.util.List;

public interface AssigmentDao {
    int insert(Assigment assigment) throws DataAccessException;
    int delete(long id) throws DataAccessException;
    Assigment query(long id) throws DataAccessException;
    List<Assigment> queryListByCourseId(@Param("courseId")long courseId,@Param("offset")int offset,@Param("size")int size)throws DataAccessException;
    List<Assigment> queryListByCourseIdNoPage(@Param("courseId")long courseId )throws DataAccessException;
}
