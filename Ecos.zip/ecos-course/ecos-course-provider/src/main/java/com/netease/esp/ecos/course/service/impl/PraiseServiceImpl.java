package com.netease.esp.ecos.course.service.impl;

import com.netease.esp.ecos.course.dao.CourseDao;
import com.netease.esp.ecos.course.dao.PraiseDao;
import com.netease.esp.ecos.course.model.Praise;
import com.netease.esp.ecos.course.service.PraiseService;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

@Service("praiseService")
@Transactional
public class PraiseServiceImpl implements PraiseService {

    @Resource
    PraiseDao praiseDao;
    @Resource
    CourseDao courseDao;

    @Override
    public Praise createPraise(Praise praise) {
        if( praiseDao.insert(praise)==1){
            if(praise.getType()== 0) {
                Praise result = praiseDao.query(praise.getId());
                int addResult = courseDao.addCoursePraiseNum(result.getRefId());
                if (addResult == 1) {
                    return praise;
                }
            }else {
                return praise;
            }
            return null;
        }else {
            return null;
        }
    }

    @Override
    public Praise deletePraise(long id) {
        Praise praise = praiseDao.query(id);
        if(praiseDao.delete(id)==1){
            return praise;
        }else {
            return null;
        }
    }

    @Override
    public Praise deletePraiseByContent(Praise praise) {
        Praise praise1 = praiseDao.queryByContent(praise.getUserId(),praise.getType(),praise.getRefId());
        if(praise1.getType() == 0) {
            Long courseId = praise1.getRefId();
            if (praiseDao.delete(praise1.getId()) == 1) {
                int subResult = courseDao.subCoursePraiseNum(courseId);
                if (subResult == 1) {
                    return praise1;
                }
                return null;
            } else {
                return null;
            }
        }else{
            if(praiseDao.delete(praise1.getId())== 1){
                return praise1;
            }
            return null;
        }

    }

    @Override
    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    public Praise getPraiseById(long id) {
        return praiseDao.query(id);
    }

    @Override
    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    public long getPraiseCountByCourseId(int type, long refId) {
        return praiseDao.selectPraiseCount(type,refId);
    }

    @Override
    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    public int getPraiseByContent(long userId, int type, long refId) {
        Praise praise1 = praiseDao.queryByContent(userId,type,refId);
        if((praise1 !=null)&&(praise1.getId()>0) ){
            return 1;
        }
        return 0;
    }
}
