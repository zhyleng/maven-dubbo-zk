package com.netease.esp.ecos.course.service.impl;

import com.netease.esp.ecos.course.dao.BannerDao;
import com.netease.esp.ecos.course.model.Banner;
import com.netease.esp.ecos.course.service.BannerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("bannerService")
public class BannerServiceImpl implements BannerService {

    @Autowired
    BannerDao bannerDao;

    @Override
    public Banner getBanner(long id) {
        return bannerDao.query(id);
    }

    @Override
    public List<Banner> getBannerList() {
        return bannerDao.queryAll();
    }
}
