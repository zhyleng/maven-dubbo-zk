package com.netease.esp.ecos.course.dao;

import com.netease.esp.ecos.course.model.Banner;
import com.netease.esp.ecos.course.model.Course;
import org.apache.ibatis.annotations.Param;
import org.springframework.dao.DataAccessException;

import java.util.List;

public interface CourseDao {
    int insert(Course course) throws DataAccessException;
    int delete(long courseId) throws DataAccessException;
    //获取教程详情
    Course query(long id) throws DataAccessException;

    //推荐功能,
    // 使用@Param("sort")注解，即可在SQL语句中,以“#{sort}”的方式引用此方法的sort参数值。
    //当然也可以在@Param中使用其他名称，如@Param("mysort")
    List<Course> queryByRecommendation(@Param("offset")int offset,@Param("size")int size) throws DataAccessException;
    //按时间排序
    List<Course> queryByTime(@Param("type")String type,@Param("keyWord")String keyWord,@Param("offset")int offset,@Param("size")int size) throws DataAccessException;
    //按点赞数排序
    List<Course> queryByPraise(@Param("type")String type,@Param("keyWord")String keyWord,@Param("offset")int offset,@Param("size")int size) throws DataAccessException;
    //按被关注数排序
    List<Course> queryByCollect(@Param("type")String type,@Param("keyWord")String keyWord,@Param("offset")int offset,@Param("size")int size) throws DataAccessException;
    //返回个人教程集--ok
    List<Course> queryByMyself(@Param("userId")long userId,@Param("offset")int offset,@Param("size")int size) throws DataAccessException;
    //点赞数量加一
    int addCoursePraiseNum(@Param("id")long id ) throws DataAccessException;
    //点赞数量加一
    int subCoursePraiseNum(@Param("id")long id ) throws DataAccessException;


}
