package com.netease.esp.ecos.course.dao;

import com.netease.esp.ecos.course.model.Picture;
import org.apache.ibatis.annotations.Param;
import org.springframework.dao.DataAccessException;

import java.util.List;


public interface PictureDao {
    int insert(Picture picture) throws DataAccessException;
    int delete(long id) throws DataAccessException;
    Picture query(long id) throws DataAccessException;
    List<Picture> queryByUrl(@Param("url")String url) throws DataAccessException;

}
