package com.netease.esp.ecos.course.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class Praise implements Serializable{
    private static final long serialVersionUID =1L;
    private long id;
    private long userId;
    private int type;
    private long refId;
    private Timestamp time;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public long getRefId() {
        return refId;
    }

    public void setRefId(long refId) {
        this.refId = refId;
    }

    public Timestamp getTime() {
        return time;
    }

    public void setTime(Timestamp time) {
        this.time = time;
    }

    @Override
    public String toString() {
        return "Praise{" +
                "id=" + id +
                ", userId=" + userId +
                ", type=" + type +
                ", refId=" + refId +
                ", time=" + time +
                '}';
    }
}
