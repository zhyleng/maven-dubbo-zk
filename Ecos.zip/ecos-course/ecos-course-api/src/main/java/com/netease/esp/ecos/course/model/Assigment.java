package com.netease.esp.ecos.course.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class Assigment implements Serializable {
    private static final long serialVersionUID = 1L;
    private long id ;
    private long userId;
    private long courseId;
    private Timestamp publishTime;
    private long imgUrlId;
    private String description;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public long getCourseId() {
        return courseId;
    }

    public void setCourseId(long courseId) {
        this.courseId = courseId;
    }

    public Timestamp getPublishTime() {
        return publishTime;
    }

    public void setPublishTime(Timestamp publishTime) {
        this.publishTime = publishTime;
    }

    public long getImgUrlId() {
        return imgUrlId;
    }

    public void setImgUrlId(long imgUrlId) {
        this.imgUrlId = imgUrlId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Assigment{" +
                "id=" + id +
                ", userId=" + userId +
                ", courseId=" + courseId +
                ", publishTime=" + publishTime +
                ", imgUrlId=" + imgUrlId +
                ", description='" + description + '\'' +
                '}';
    }
}
