package com.netease.esp.ecos.course.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class Banner implements Serializable {

    private static final long serialVersionUID = 1L;
    private long id;
    private String bannerUrl;
    private String linkUrl;
    private Timestamp createTime;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getBannerUrl() {
        return bannerUrl;
    }

    public void setBannerUrl(String bannerUrl) {
        this.bannerUrl = bannerUrl;
    }

    public String getLinkUrl() {
        return linkUrl;
    }

    public void setLinkUrl(String linkUrl) {
        this.linkUrl = linkUrl;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    @Override
    public String toString() {
        return "Banner [ id= " + id + ", bannerUrl = " + bannerUrl + " ,linkUrl = " + linkUrl + " , timestamp=" + createTime + " ]";
    }
}
