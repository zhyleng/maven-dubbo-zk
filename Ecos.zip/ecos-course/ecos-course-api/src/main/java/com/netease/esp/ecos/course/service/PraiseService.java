package com.netease.esp.ecos.course.service;

import com.netease.esp.ecos.course.model.Praise;

public interface PraiseService {
    public Praise createPraise(Praise praise) ;
    public Praise deletePraise(long id) ;
    public Praise deletePraiseByContent(Praise praise);
    public Praise getPraiseById(long id) ;
    public long getPraiseCountByCourseId(int type, long refId);
    public int getPraiseByContent(long userId,int type,long refId);
}
