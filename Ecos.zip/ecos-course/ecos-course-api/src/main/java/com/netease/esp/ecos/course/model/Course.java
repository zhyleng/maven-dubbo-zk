package com.netease.esp.ecos.course.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class Course implements Serializable {

    private static final long serialVersionUID = 1L;
    private long id;
    private String type;
    private String title;
    private long coverUrlId; //在picture中的id
    private long userId;
    private Timestamp publishTime;
    private String descriptions;
    private String imgUrlsId;
    private String praiseNum;


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }


    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }


    public long getCoverUrlId() {
        return coverUrlId;
    }

    public void setCoverUrlId(long coverUrlId) {
        this.coverUrlId = coverUrlId;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public Timestamp getPublishTime() {
        return publishTime;
    }

    public void setPublishTime(Timestamp publishTime) {
        this.publishTime = publishTime;
    }


    public String getDescriptions() {
        return descriptions;
    }

    public void setDescriptions(String descriptions) {
        this.descriptions = descriptions;
    }

    public String getImgUrlsId() {
        return imgUrlsId;
    }

    public void setImgUrlsId(String imgUrlsId) {
        this.imgUrlsId = imgUrlsId;

    }

    public String getPraiseNum() {
        return praiseNum;
    }

    public void setPraiseNum(String praiseNum) {
        this.praiseNum = praiseNum;
    }


    @Override
    public String toString() {
        return "Course{" +
                "id=" + id +
                ", type='" + type + '\'' +
                ", title='" + title + '\'' +
                ", coverUrlId=" + coverUrlId +
                ", userId=" + userId +
                ", publishTime=" + publishTime +
                ", descriptions='" + descriptions + '\'' +
                ", imgUrlsId='" + imgUrlsId + '\'' +
                ", praiseNum='" + praiseNum + '\'' +
                '}';
    }
}
