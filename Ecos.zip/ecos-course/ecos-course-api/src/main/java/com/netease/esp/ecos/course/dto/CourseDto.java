package com.netease.esp.ecos.course.dto;

import com.netease.esp.ecos.course.model.Course;
import com.netease.esp.ecos.course.model.Picture;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class CourseDto extends Course implements Serializable{
    private static final long serialVersionUID = 1L;

    private String coverUrl;
    private String imgUrls;

    public String getCoverUrl() {
        return coverUrl;
    }

    public String getImgUrls() {
        return imgUrls;
    }

    public void setImgUrls(String imgUrls) {
        this.imgUrls = imgUrls;
    }

    public void setCoverUrl(String coverUrl) {
        this.coverUrl = coverUrl;
    }


    @Override
    public String toString() {
        return "CourseDto [ id = "+ getId()+",title ="+getTitle() + ",type=" + getType()+ ",coverUrl = " + coverUrl + ",coverUrlId= " +
                getCoverUrlId() + ", userId = "+ getUserId()+ ", imgUrls="+ imgUrls+ ", imgUrlsId=" +
                getImgUrlsId()+ ", descriptions = "+ getDescriptions() + ", praiseNum = "+ getPraiseNum()+" ]";
    }


}
