package com.netease.esp.ecos.course.service;

import com.netease.esp.ecos.course.dto.CourseDto;

import java.util.List;

public interface CourseService {
    public CourseDto createCourse(CourseDto course);
    public CourseDto deleteCourse(long id);
    public CourseDto getCourse(long id);
    public List<CourseDto> getCourseListByRecommendation(int offset,int size);
    public List<CourseDto> getCourseListByTime(String filterType,String keyWord,int offset,int size);
    public List<CourseDto> getCourseListByPraise(String filterType,String keyWord,int offset,int size);
    public List<CourseDto> getCourseListByCollect(String filterType,String keyWord,int offset,int size);
    public List<CourseDto> getCourseListByMyself(long courseId,int offset,int size);
    public int updateCoursePraiseNum(long courseId,int type);

}
