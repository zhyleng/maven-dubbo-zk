package com.netease.esp.ecos.course.service;

import com.netease.esp.ecos.course.dto.AssigmentDto;
import com.netease.esp.ecos.course.model.Assigment;

import java.util.List;

public interface AssigmentService {
    AssigmentDto createAssigment(AssigmentDto assigmentDto);
    AssigmentDto deteleAssigment(long id);
    AssigmentDto getAssigment(long id);
    List<AssigmentDto> getAssigmentList(long courseId,int offset,int size);
    List<AssigmentDto> getAssigmentListNoPage(long courseId);
}
