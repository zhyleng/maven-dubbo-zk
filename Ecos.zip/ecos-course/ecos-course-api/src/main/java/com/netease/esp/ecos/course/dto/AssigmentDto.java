package com.netease.esp.ecos.course.dto;

import com.netease.esp.ecos.course.model.Assigment;

import java.io.Serializable;

public class AssigmentDto extends Assigment implements Serializable{
    private static final long serialVersionUID = 1L;
    private String imgUrl;

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    @Override
    public String toString() {
        return "AssigmentDto{" +
                "id=" + getId() +
                ", userId=" + getUserId() +
                ", courseId=" + getCourseId() +
                ", publishTime=" + getPublishTime() +
                ", imgUrlId=" + getImgUrlId() +
                ", description='" + getDescription() +
                "imgUrl='" + imgUrl + '\'' +
                '}';
    }
}
