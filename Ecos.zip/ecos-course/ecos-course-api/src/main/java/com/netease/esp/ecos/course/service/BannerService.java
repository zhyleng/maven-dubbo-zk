package com.netease.esp.ecos.course.service;

import com.netease.esp.ecos.course.model.Banner;
import java.util.List;


public interface BannerService {
	public Banner getBanner(long id);
    public List<Banner> getBannerList();
}
