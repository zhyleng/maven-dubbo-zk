config file:
    /root/home/config/url.properties
1.ecos-mainsite-web
    # File Path:TOMCAT_HOME/conf/catalina.properties add to last line
    url.dir=/root/home/config
2.ecos-provider
    VMargs -Durl.dir=/root/home/config
