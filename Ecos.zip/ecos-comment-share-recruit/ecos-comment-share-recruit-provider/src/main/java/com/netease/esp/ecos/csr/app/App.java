package com.netease.esp.ecos.csr.app;


import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.netease.esp.ecos.csr.model.Recruit;
import com.netease.esp.ecos.csr.model.RecruitDis;
import com.netease.esp.ecos.csr.model.Share;
import com.netease.esp.ecos.csr.service.CommentService;
import com.netease.esp.ecos.csr.service.RecruitService;
import com.netease.esp.ecos.csr.service.ShareService;

public class App {
	public static boolean close = false;

/*	@Test
>>>>>>> 0fdb69c1a4c538141c3f95a4f1176816bc08eb6c
	public static void getComment(CommentService commentService){
		String name = commentService.getUserNameByUserId( new Long(3));
		assert name.equals("xrv"); 
	}*/
	public static void main(String[] args) {
		System.out.println("ecos-csr-provider 启动 ...");
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(new String[] {"classpath:config/spring.xml", "classpath:config/dubbo.xml"});
		context.start();
		System.out.println("ecos-csr-provider 运行中 ...");
/*		CommentService commentService = (CommentService)context.getBean("commentService");
		commentService.creatComment(new Long(3), new Long(10), "test", null, new Long(126));*/
		
		/*CommentService commentService = (CommentService)context.getBean("commentService"); 
		commentService.getComments(new Long(1), new Long(1),new Long(99),new Long(99));*/
		/**
		 * test comment create
		 */
		//CommentService commentService = (CommentService)context.getBean("commentService");
	    //int result = commentService.creatComment(1, 1, "test",1);
	    //System.out.println("result :"+result);
	    //test delete
	    //commentService.deleteComment(2);
	    //test query content by commentId
	    //String text = commentServ	ice.getCommentContent(1);
	    //System.out.println(text);
	    //Comment comment = commentService.getCommentContent(6);
	    //System.out.println(comment);
		//commentService.deleteComment(1);
		//System.out.println(commentService.deleteComment(6));
		
		
		//CommentService commentService = (CommentService)context.getBean("commentService");
		//List<ShareComment> c = commentService.getComments(new Long(1), new Long(1), new Long(99), new Long(99));
/*		List<ShareComment> c = getComment(commentService);
		for (ShareComment s : c) {
			System.out.println(s);
		}*/
		/**
		 * test share create
		 */
/*		ShareService shareService = (ShareService)context.getBean("shareService");
		Long userId = new Long(1);
		String coverUrlId = "ee";
		String title = "hehe";
		String content = "haha";
		String imgIds = "imgssss";
		Share share = shareService.CreateShare(userId, coverUrlId, title, content, imgIds);
		System.out.println(share.getShareId());*/
		
/*		ShareService shareService = (ShareService)context.getBean("shareService");

		Long result = shareService.getCommentNum(type, refId);
		System.out.println(result);*/
		
		
	/*	CommentService commentService = (CommentService)context.getBean("commentService");
		Long type = new Long(4);
		Long refId = new Long(2);
		List result = commentService.getComments(type, refId);
		System.out.println(result);*/
		
		/*CommentService commentService = (CommentService)context.getBean("commentService");
		commentService.creatComment(1L, 2L, "h", null, 125L);*/
		//Long userId, String type, String keyWord, Long pageSize, Long pages\
/*		Long userId = new Long(1);
		String type = "all";
		String keyWord = "1";
		Long pageSize = new Long(10);
		Long pages = new Long(1);
		ShareService shareService = (ShareService)context.getBean("shareService");
		List <Share> share = shareService.getShareList(userId, type, keyWord, pageSize, pages);
		for (Share s : share) {
			System.out.println(s.getContent());
		}
		System.out.println();*/
		
/*		ShareService shareService = (ShareService)context.getBean("shareService");
		Share s = shareService.delShare(new Long(14));
		System.out.println(s);
		
	//	userId=4&token=rr&type=all&pageSize=10&pages=1
		Long userId = new Long(4);
		String type="all";
		String keyWord="dddddd";
		Long pageSize = new Long(10);
		Long pages = new Long(1);
	
		List <Share> sList = shareService.getShareList(userId, type, keyWord, pageSize, pages);
		for (Share ss : sList) {
			System.out.println(ss);
		}*/
		

/*		List<Object> descriptionUrls = new ArrayList<Object>();
		descriptionUrls.add("蓝天美");
		descriptionUrls.add("蓝天帅");
		descriptionUrls.add("蓝电diao");*/
			
		/**	test for recruit	 */
/*		RecruitService recruitService = (RecruitService)context.getBean("recruitService");
		Long userId = new Long(3);
		Double price = new Double(3);
		String description = "ri le gou le";
		Long shareId = new Long(4);
		String priceUnit = "ri";
		String coverUrl = "gou";
		String title = "ri gou";
		Long recruitType = new Long(1);
		recruitService.createRecruit(userId, price, description, shareId, priceUnit, coverUrl, title, recruitType);
		for(int i =0;i<10;i++){
			recruitService.createRecruit(userId, price, description, shareId, priceUnit, coverUrl, title, recruitType);
		}*/
/*		RecruitService recruitService = (RecruitService)context.getBean("recruitService");
		
		for (Recruit r : recruitService.getDetailList(new Long(125), false, new Long(1), new Long(12), "haha", new Long(10), new Long(1))) {
			System.out.println(r);
		}*/
/*		ShareService shareService = (ShareService)context.getBean("shareService");
		
		shareService.CreateShare(new Long(1), "hehe", "hehe", "hehe", "hehe", new Long(1), new Long(1));
		List<Share> shares = shareService.getShareList(new Long(1), "all", "", new Long(10), new Long(2), null);
		for (Share s : shares) {
			System.out.println(s);
		}*/
/*		RecruitService recruitService = (RecruitService)context.getBean("recruitService");
		List <RecruitDis> rr = recruitService.getDetailList(1L, false, 1L, 1L, "distance", 5L, 1L);
		for (RecruitDis r : rr) {
			System.out.println(r.getDistance());
		}*/
		
/*		
		ShareService shareService = (ShareService)context.getBean("shareService");
		shareService.getShareList(125L, "myself", null, 10L, 1L, 0L);*/
		
	/*	ShareService shareService = (ShareService)context.getBean("shareService");
		shareService.CreateShare(125L, "1", "2", "3", "4", 5L, 1L);*/
	/*	ShareService shareService = (ShareService)context.getBean("shareService");*/
		//shareService.CreateShare(userId, coverUrl, title, content, imgIds, totalImages, type)
		
/*		RecruitService recruitService = (RecruitService)context.getBean("recruitService");
		List <RecruitDis> rDis = recruitService.getDetailList(124L, false, 0L, null, "price", 5L, 1L);
		
		for (RecruitDis r : rDis) {
			System.out.println(r.getPrice());
		}*/
		Runtime r = Runtime.getRuntime();
		System.out.println("free mem:" + r.freeMemory()/(1024*1024) + "M");
		System.out.println("total mem:" + r.totalMemory()/(1024*1024) + "M");
		System.out.println("max mem:" + r.maxMemory()/(1024*1024) + "M");
		// 为保证服务一直开着，利用输入流的阻塞来模拟
		while(!close) {
			
		}
		context.close();
	}
}
