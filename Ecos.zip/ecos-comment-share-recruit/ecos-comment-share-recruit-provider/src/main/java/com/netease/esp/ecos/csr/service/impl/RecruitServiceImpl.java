package com.netease.esp.ecos.csr.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.bouncycastle.jce.provider.JCEMac.RIPEMD128;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.netease.esp.ecos.csr.dao.RecruitDAO;
import com.netease.esp.ecos.csr.model.Recruit;
import com.netease.esp.ecos.csr.model.RecruitDis;
import com.netease.esp.ecos.csr.model.Share;
import com.netease.esp.ecos.csr.model.UserForRecruit;
import com.netease.esp.ecos.csr.model.UserGeo;
import com.netease.esp.ecos.csr.service.RecruitService;
import com.netease.esp.ecos.util.geo.CalculateDistanceBaiduMap;

@Service("recruitService")
public class RecruitServiceImpl implements RecruitService {
	
	@Autowired
	RecruitDAO recruitDAO;
	@Override
	public Recruit createRecruit(Long userId, Double price, String description, Long shareId, String priceUnit,
			String coverUrl, String title, Long recruitType) {
		// TODO Auto-generated method stub
		Recruit recruit = new Recruit();
		recruit.setUserId(userId);
		recruit.setPrice(price);
		recruit.setDescription(description);
		recruit.setShareId(shareId);
		recruit.setPriceUnit(priceUnit);
		recruit.setCoverUrl(coverUrl);
		recruit.setTitle(title);
		recruit.setRecruitType(recruitType);
		recruit.setIssueTimeStamp(new Timestamp(System.currentTimeMillis()));
		recruit.setState(new Long(0));
		
		recruitDAO.createRecruit(recruit);
		if(recruit.getRecruitId() == null){
			return null;
		}
		return recruit;
	}
	@Override
	public RecruitDis getDetailRecruit(Long recruitId,Long userId) {
		// TODO Auto-generated method stub
		RecruitDis recruit = null;
		recruit = recruitDAO.getRecruitDetail(recruitId);
		if(recruit != null){
			UserGeo user1 = recruitDAO.getUserGeo(userId);
			UserGeo user2 = recruitDAO.getUserGeo(recruitDAO.getUserByRecruitId(recruitId));
			
		   if(user1 == null || user2==null){
			   recruit.setDistance(0L);
		   }else{
			    if(user1.getLatitude() == null || user1.getLongitude() == null ||user2.getLatitude() == null || user2.getLongitude() == null){
			    	recruit.setDistance(0L);
			    }else{
					Long dis = (long)CalculateDistanceBaiduMap.getDistance(user1.getLongitude(),user1.getLatitude(),user2.getLongitude(),user2.getLatitude());
					recruit.setDistance(dis);
			    }
		    }

		}
		return recruit;
	}
	/* (non-Javadoc)
	 * @see com.netease.esp.ecos.csr.service.RecruitService#getUserForRecruit(java.lang.Long)
	 */
	@Override
	public UserForRecruit getUserForRecruit(Long userId) {
		// TODO Auto-generated method stub
		UserForRecruit userForRecruit = new UserForRecruit();
		
		Integer cityCode = recruitDAO.getCityCodeByUser(userId);
		Long gender = recruitDAO.getGenderByUser(userId);
		String imId = recruitDAO.getImIdByUser(userId);
		String nickname = recruitDAO.getNicknameByUser(userId);
		
		userForRecruit.setCityCode(cityCode);
		userForRecruit.setGender(gender);
		userForRecruit.setImId(imId);
		userForRecruit.setNickname(nickname);
		return userForRecruit;
	}
	@Override
	public List<RecruitDis> getDetailList(Long userId, Boolean isMyself, Long recruitType, Long cityCode, String sortRule,
			Long pageSize, Long pages) {
		// TODO Auto-generated method stub
		final long user = userId;
		List <RecruitDis> resultR = null;
		Long offset = (pages-1) * pageSize ;
		//  offset, pageSize
		List <RecruitDis> result;
		if (isMyself){
			//只显示自己发布的招募
			result = recruitDAO.getMyself(userId);
		}else{
			//按条件显示所有人
			result = recruitDAO.getRightMan(cityCode, recruitType);
		}
		//按某种规则排序  sortRule
		/** 	sort(result)		*/
		if(result != null){
			//给每一个recruit添加距离
			 for (RecruitDis r : result) {
			    UserGeo user1 = recruitDAO.getUserGeo(userId);
			    UserGeo user2 = recruitDAO.getUserGeo(r.getUserId());
			    if(user1 == null || user2==null){
			    	r.setDistance(0L);
			    }else{
				    if(user1.getLatitude() == null || user1.getLongitude() == null ||user2.getLatitude() == null || user2.getLongitude() == null){
				    	r.setDistance(0L);
				    }else{
				    	Long dis = (long)CalculateDistanceBaiduMap.getDistance(user1.getLongitude(),user1.getLatitude(),user2.getLongitude(),user2.getLatitude());
				    	r.setDistance(dis);
				    }
			    }
			}
			 if(sortRule.equals("intelligent")){
				// 公里数三次方除以点赞数+1   越小越前
				 Collections.sort(result,new Comparator<RecruitDis>(){
					@Override
					public int compare(RecruitDis r1, RecruitDis r2) {
						// TODO Auto-generated method stub
						Long praise1 = recruitDAO.getPraisedByUserId(r1.getUserId());
						Long praise2 = recruitDAO.getPraisedByUserId(r2.getUserId());
						if(praise1 == null)
							praise1 = 0L;
						if(praise2 == null)
							praise2 = 0L;
						double re1 = Math.pow(r1.getDistance(),3) / (praise1 + 1);
						double re2 = Math.pow(r2.getDistance(), 3) /(praise2 + 1);
						return (re1 == re2) ? 0:( re1 > re2) ? 1:-1;
					}
					 
				 });
			 }
			 if(sortRule.equals("distance")){
				 Collections.sort(result,new Comparator<RecruitDis>() {
					@Override
					public int compare(RecruitDis r1, RecruitDis r2) {
						// TODO Auto-generated method stub
						return (r1.getDistance() == r2.getDistance()) ? 0: (r1.getDistance() > r2.getDistance()) ? 1:-1;
					}
				});
			 }
			 if(sortRule.equals("price")){
				Collections.sort(result,new Comparator<RecruitDis>() {
					@Override
					public int compare(RecruitDis r1, RecruitDis r2) {
						// TODO Auto-generated method stub
						return (r1.getPrice() == r2.getPrice()) ? 0: (r1.getPrice() > r2.getPrice()) ? 1:-1;
					}
					
				});
			 }
			 if(sortRule.equals("popular")){
				 Collections.sort(result,new Comparator<RecruitDis>(){
						@Override
						public int compare(RecruitDis r1, RecruitDis r2) {
							// TODO Auto-generated method stub
							Long praise1 = recruitDAO.getPraisedByUserId(r1.getUserId());
							Long praise2 = recruitDAO.getPraisedByUserId(r2.getUserId());
							if(praise1 == null)
								praise1 = 0L;
							if(praise2 == null)
								praise2 = 0L;
							return (praise1 == praise2) ? 0:( praise1 < praise2) ? 1:-1;
						}
						 
					 });
			 }
			//将排序结果返回  分页
			if(result != null){
				resultR = new ArrayList<RecruitDis>();
				for(long i=0;i<pageSize && (int) (offset+i) < result.size();i++){
					resultR.add(result.get((int) (offset+i)));
				}
			}
		}
		return resultR;
	}
}
