package com.netease.esp.ecos.csr.dao;


import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.dao.DataAccessException;
import com.netease.esp.ecos.csr.model.Share;

public interface ShareDAO {
	int insert(Share share) throws DataAccessException;					//创建新share
	Share getShareById(Long shareId) throws DataAccessException;	    //获得share
	Boolean hasPraised(@Param("userId")Long userId, @Param("type")Long type,  @Param("refId")Long refId);
	Boolean hasFollowed(@Param("fromUserId")Long fromUserId, @Param("toUserId")Long toUserId );
	Long getPraisedNum(@Param("type")Long type, @Param("refId")Long refId);
	int delShare(Long shareId);                                        //删除作品
	/**  getList      */
	List <Share> getShareByUserId(@Param("userId")Long userId,@Param("offset")Long offset,@Param("pageSize")Long pageSize);    //for myself
	//List <Share> getShareByUserId(@Param("userId")Long userId,@Param("offset")Long offset,@Param("pageSize")Long pageSize);    //for myself
	List <Long> getFollowByUserId(@Param("userId")Long userId,@Param("offset")Long offset,@Param("pageSize")Long pageSize);    //for follow
	List <Share> getShareByTransparent(@Param("offset")Long offset,@Param("pageSize")Long pageSize);		   //for transparent
	List <Share> getShareList(@Param("offset")Long offset,@Param("pageSize")Long pageSize); //for all
	List <Share> getShareByWordKey(@Param("keyWord")String keyWord,@Param("offset")Long offset, @Param("pageSize")Long pageSize); 	 //for wordkey
	List <Share> getShareFollowAll(Long userId);
}
