package com.netease.esp.ecos.csr.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.dao.DataAccessException;
import com.netease.esp.ecos.csr.model.Recruit;
import com.netease.esp.ecos.csr.model.RecruitDis;
import com.netease.esp.ecos.csr.model.UserGeo;

public interface RecruitDAO {
	public int createRecruit(Recruit recruit) throws DataAccessException;
	public RecruitDis getRecruitDetail(Long recruitId) throws DataAccessException;
	
	public String getImIdByUser(Long userId) throws DataAccessException;
	public Integer getCityCodeByUser(Long userId) throws DataAccessException;
	public String getNicknameByUser(Long userId) throws DataAccessException;
	public Long getGenderByUser(Long userId) throws DataAccessException;
	
	//获得符合条件的人
	public List <RecruitDis> getRightMan(@Param("cityCode") Long cityCode,@Param("recruitType")Long recruitType) throws DataAccessException;
	//获得个人招募信息
	public List <RecruitDis> getMyself(@Param("userId")Long userId)throws DataAccessException ;  
	public UserGeo getUserGeo(Long userId) throws DataAccessException;
	
	public Long getUserByRecruitId(Long recruitId)throws DataAccessException;
	
	public Long getPraisedByUserId(Long userId) throws DataAccessException;
	
}
