package com.netease.esp.ecos.csr.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import com.netease.esp.ecos.csr.dao.CommentDAO;
import com.netease.esp.ecos.csr.dao.ShareDAO;
import com.netease.esp.ecos.csr.model.Share;
import com.netease.esp.ecos.csr.service.ShareService;

@Service("shareService")
public class ShareServiceImpl implements ShareService {
	@Autowired
	ShareDAO shareDAO;
	@Autowired
	CommentDAO commentDAO;
	@Override
	public Share CreateShare(Long userId, String coverUrl, String title, String content, String imgIds,Long totalImages,Long type) {
		// TODO Auto-generated method stub
		Share share = new Share();
		Timestamp time = new Timestamp(System.currentTimeMillis());
		share.setUserId(userId);
		share.setCoverUrl(coverUrl);
		share.setTime(time);
		share.setTitle(title);
		share.setContent(content);
		share.setImgIds(imgIds);
		share.setTotalImages(totalImages);
		share.setState(new Long(0));
		share.setType(type);
		try{
			shareDAO.insert(share);
		}catch (DataAccessException e){
			return null;
		}
		return share;
	}
	@Override
	public Share getShareDetail(Long shareId) {
		// TODO Auto-generated method stub
		Share share = new Share();
		try{
			share = shareDAO.getShareById(shareId);
		}catch (DataAccessException e){
			return null;
		}
		return share;
	}
	@Override
	public Boolean hasPraised(Long userId, Long type, Long refId) {
		// TODO Auto-generated method stub
		Boolean result = null;
		try{
			result = shareDAO.hasPraised(userId, type, refId);
		}catch (DataAccessException e){
			return null;
		}
		return result;
	}
	@Override
	public Boolean hasFollowed(Long fromUserId, Long toUserId) {
		// TODO Auto-generated method stub
		Boolean result = null;
		try{
			result = shareDAO.hasFollowed(fromUserId, toUserId);
		}catch (DataAccessException e){
				return null;
		}
		return result;
	}
	/* (non-Javadoc)
	 * @see com.netease.esp.ecos.csr.service.ShareService#getCommentNum()
	 */
	@Override
	public Long getPraiseNum(Long type, Long refId) {
		// TODO Auto-generated method stub
		Long result = null;
		try{
			result = shareDAO.getPraisedNum(type, refId);
		}catch (DataAccessException e){
				return null;
		}
		return result;
	}
	@Override
	public Long getCommentNum(Long commentType, Long commentTypeId) {
		// TODO Auto-generated method stub
		Long result = null;
		try{
			
			result = commentDAO.getCommentNum(commentType, commentTypeId);
		}catch (DataAccessException e){
				return null;
		}
		return result;
	}
	@Override
	public Share delShare(Long shareId) {
		// TODO Auto-generated method stub
		Share result = null;
		try{
			shareDAO.delShare(shareId);
			result = shareDAO.getShareById(shareId);
		}catch (DataAccessException e){
				return result;
		}
		return result;
	}
	@Override
	public List<Share> getShareList(Long userId, String type, String keyWord, Long pageSize, Long pages,Long tag) {
		// TODO Auto-generated method stub
		List <Share> share = null;
		List <Share> sTemp = new ArrayList<Share>();
		List <Share> ssTemp = new ArrayList<Share>();
		List <Long> user = new ArrayList<Long>();
		
		Long offset = (pages-1) * pageSize ;
		switch(type){
			case "all":
				if(keyWord == null){
					//检索所有
					share = shareDAO.getShareList( offset, pageSize);
				}else{
					String k = "%" + keyWord + "%";
					share = shareDAO.getShareByWordKey(k,offset, pageSize);
				}
				break;
			case "recommended":
				//暂时不做
				break;
			case "transparent":  		//新人
				share = shareDAO.getShareByTransparent(offset, pageSize);
				if(share !=null){
					
				}
				break;
			case "follow":
				user = shareDAO.getFollowByUserId(userId,offset, pageSize);
				if(user !=null){
					for (Long l : user) {
						sTemp = shareDAO.getShareFollowAll(l);
						ssTemp.addAll(sTemp);
					}
					if(ssTemp != null){
						share = new ArrayList<Share>();
						for(long i=0;i<pageSize && (int) (offset+i) <ssTemp.size();i++){
							share.add(ssTemp.get((int) (offset+i)));
						}
					}
				}
				break;
			case "myself":
				share = shareDAO.getShareByUserId(userId,offset, pageSize);
				break;
		}
		List <Share> result = new ArrayList<Share>();
		//做tag筛选 比较数据库中 type 和 tag
		if(share != null){
			for (Share s : share) {
				if( s.getType() != null && tag!=null){
					if((s.getType().longValue() & tag.longValue()) != 0){
						result.add(s);
					}
				}
			}
		}
		return result;
	}


}
