package com.netease.esp.ecos.csr.service.impl;


import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import com.netease.esp.ecos.csr.dao.CommentDAO;
import com.netease.esp.ecos.csr.model.Comment;
import com.netease.esp.ecos.csr.model.ShareComment;
import com.netease.esp.ecos.csr.service.CommentService;

@Service("commentService")
public class CommentServiceImpl implements CommentService {
	private Logger logger = Logger.getLogger(this.getClass());

	@Autowired
	CommentDAO commentDAO;

	@Override
	public Comment creatComment(Long commentType ,Long commentTypeId, String content, Long parentId,Long userId) {
		// TODO Auto-generated method stub
		Comment comment = new Comment();								//构建新评论对象
		comment.setCommentType(commentType); 
		comment.setCommentTypeId(commentTypeId);
		comment.setContent(content);
		comment.setTime(new Timestamp(System.currentTimeMillis()));
		comment.setState(new Long(0));									//评论初始有效为0
		comment.setParentId(parentId);
		comment.setUserId(userId);
		try{
			commentDAO.insert(comment);									//数据库插入
		}catch (DataAccessException e){
			logger.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
		return comment;
	}

	/* 
	 * get content by commentId
	 * result null : commentId不存在
	 */
	@Override
	public Comment getCommentContent(Long commentId) {
		// TODO Auto-generated method stub
		if (commentDAO.queryContentById(commentId) == null){
			return null;
		}
		Comment comment = null;
		try{
			comment = commentDAO.queryContentById(commentId);
		}catch (DataAccessException e){
			logger.error(e.getMessage());
			return null;
		}
		return comment;
	}

	/* 
	 * delete comment by commentId
	 * 删除用更新 state实现   state 0:有效 1:删除
	 */
	@Override
	public Comment deleteComment(Long commentId) {
		// TODO Auto-generated method stub
		Comment comment = null;
		try{
			commentDAO.updateState(commentId);
			comment = commentDAO.queryContentById(commentId);
		}catch (DataAccessException e){
			return null;

		}
		return comment;
	}
	/**
	 * 获取头像URL ID
	 */
	private Long getAvatarUrlIdByUserId(Long userId) {
		// TODO Auto-generated method stub
		Long result = null;
		try{
			result =commentDAO.queryAvatarUrlId(userId);
		}catch(DataAccessException e){
			logger.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
		return result;
	}
	/**
	 * 获取头像URl
	 */
	private String getAvatarUrlByPicId(Long pictureId) {
		// TODO Auto-generated method stub
		String result = null;
		try{
			result =commentDAO.queryAvatarUrlByPicId(pictureId);
		}catch(DataAccessException e){
			return null;
		}
		return result;
	}
	@Override
	public String getAvatarUrlByUserId(Long userId) {
		// TODO Auto-generated method stub
		String result = null;
		Long urlId = getAvatarUrlIdByUserId(userId);
		result = getAvatarUrlByPicId(urlId);
		return result;
	}
	/**
	 * 获取昵称
	 */
	@Override
	public String getUserNameByUserId(Long userId) {
		// TODO Auto-generated method stub
		String result = null;
		try{
			result =commentDAO.queryUserNameByUserId(userId);
		}catch(DataAccessException e){
			return null;
		}
		return result;
	}
	/* 
	 * 返回所有评论
	 */
	@Override
	public List<ShareComment> getComments(Long commentType, Long commentTypeId,Long pageSize,Long pages) {
		// TODO Auto-generated method stub
		List <Comment>comments = null;
		List <ShareComment> result = new ArrayList<ShareComment>();
		if(pageSize == 99 && pages == 99){
			//传递最新四条
			//comments = commentDAO.queryAllComments(commentType, commentTypeId);
			comments = new ArrayList<Comment>();
			long num = commentDAO.getCommentNum(commentType, commentTypeId);
			if(num <= 4){
				comments.addAll(commentDAO.queryAllComments(commentType, commentTypeId, 0L, 4L));
			}else{
				comments.add(commentDAO.queryNewOne(commentType, commentTypeId));
				List <Comment> tmp = commentDAO.queryOldThree(commentType, commentTypeId);
				comments.addAll(tmp);
			}
		}else{
			Long offset = (pages-1) * pageSize ;
			comments = commentDAO.queryAllComments(commentType, commentTypeId,offset, pageSize);
		}
		if(comments != null){
			for (Comment c : comments) {
				ShareComment shareComment = new ShareComment();
				shareComment.setCommentId(c.getCommentId());
				shareComment.setCommentType(c.getCommentType());
				shareComment.setCommentTypeId(c.getCommentTypeId());
				shareComment.setContent(c.getContent());
				shareComment.setCommentTimeStampTime(c.getTime());
				shareComment.setParentId(c.getParentId());
				shareComment.setFromId(c.getUserId());
				shareComment.setAvatarUrl(getAvatarUrlByUserId(c.getUserId()));
				shareComment.setFromNickname(getUserNameByUserId(c.getUserId()));
				shareComment.setParentNIickName(getUserNameByUserId(c.getParentId()));
				result.add(shareComment);
			}
		}
		return result;
	}

	/* (non-Javadoc)
	 * @see com.netease.esp.ecos.csr.service.CommentService#getCommentNum(java.lang.Long, java.lang.Long)
	 */
	@Override
	public Long getCommentNum(Long commentType, Long commentTypeId) {
		// TODO Auto-generated method stub
		Long result = null;
		try{

			result = commentDAO.getCommentNum(commentType, commentTypeId);
		}catch (DataAccessException e){
			return null;
		}
		return result;
	}
}
