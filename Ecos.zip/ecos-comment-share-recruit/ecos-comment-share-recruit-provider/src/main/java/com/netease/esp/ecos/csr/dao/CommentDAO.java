package com.netease.esp.ecos.csr.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.dao.DataAccessException;
import com.netease.esp.ecos.csr.model.Comment;

public interface CommentDAO {
	int insert(Comment comment) throws DataAccessException;					//创建新评论
	Comment queryCommentList(Long commentId) throws DataAccessException;	//查找评论列表
	Comment queryContentById(Long commentId)throws DataAccessException;     //查找评论内容
	int updateState(Long commentId ) throws DataAccessException;            //更改状态，删除效果
	
	Long queryAvatarUrlId(Long userId)throws DataAccessException; 			//查找头像ID
	String queryAvatarUrlByPicId(Long pictureId)throws DataAccessException; //查找头像Url
	String queryUserNameByUserId(Long userId)throws DataAccessException; 	//查找用户名
	
	Long queryParentId(Long parentId)throws DataAccessException;     		//查找父评论是否存在
	Long queryCommentId(Long commentId)throws DataAccessException;   		//查找评论是否存在
	
	Long getCommentNum(@Param("commentType")Long commentType, @Param("commentTypeId")Long commentTypeId) throws DataAccessException;
	List<Comment> queryAllComments(@Param("commentType")Long commentType, @Param("commentTypeId")Long commentTypeId, @Param("offset")Long offset, @Param("pageSize")Long pageSize) throws DataAccessException;
	
	List<Comment> queryOldThree(@Param("commentType")Long commentType, @Param("commentTypeId")Long commentTypeId) throws DataAccessException;
	Comment queryNewOne(@Param("commentType")Long commentType, @Param("commentTypeId")Long commentTypeId) throws DataAccessException;
}
