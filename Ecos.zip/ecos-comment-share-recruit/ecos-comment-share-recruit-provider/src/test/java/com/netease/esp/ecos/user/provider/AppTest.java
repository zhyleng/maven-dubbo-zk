package com.netease.esp.ecos.user.provider;

import com.netease.esp.ecos.csr.service.CommentService;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */

public class AppTest {
	
	
}
