package com.netease.esp.ecos.csr.service;


import java.util.List;
import com.netease.esp.ecos.csr.model.Share;

public interface ShareService {
	public Share CreateShare(Long userId,String coverUrl,String title,String content,String imgIds,Long totalImages,Long type);
	public Share getShareDetail(Long shareId);
	public Boolean hasPraised(Long userId,Long type,Long refId);
	public Boolean hasFollowed(Long fromUserId,Long toUserId);
	public Long getCommentNum(Long commentType, Long commentTypeId);
	public Long getPraiseNum(Long type, Long refId);
	public Share delShare(Long shareId);
	public List <Share> getShareList(Long userId,String type,String keyWord,Long pageSize,Long pages,Long tag); 
}
