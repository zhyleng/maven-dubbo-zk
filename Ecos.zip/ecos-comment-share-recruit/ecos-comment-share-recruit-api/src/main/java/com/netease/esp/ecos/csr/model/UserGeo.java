package com.netease.esp.ecos.csr.model;

import java.io.Serializable;

public class UserGeo implements Serializable {
	private static final long serialVersionUID = 1L;
	private Long userId;
	private Double longitude;
	private Double latitude;
	/**
	 * @return the userId
	 */
	public Long getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	/**
	 * @return the longitude
	 */
	public Double getLongitude() {
		return longitude;
	}
	/**
	 * @param longitude the longitude to set
	 */
	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}
	/**
	 * @return the latitude
	 */
	public Double getLatitude() {
		return latitude;
	}
	/**
	 * @param latitude the latitude to set
	 */
	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "UserGeo [userId=" + userId + ", longitude=" + longitude + ", latitude=" + latitude + "]";
	}
	
	
	
	
	
}
