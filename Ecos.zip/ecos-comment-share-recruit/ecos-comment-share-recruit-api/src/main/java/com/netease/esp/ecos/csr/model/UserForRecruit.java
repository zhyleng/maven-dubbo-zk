package com.netease.esp.ecos.csr.model;

import java.io.Serializable;

public class UserForRecruit implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    private String imId;
    private Integer cityCode;
    private String nickname;
    private Long gender;
    private Long distance;
	/**
	 * @return the imId
	 */
	public String getImId() {
		return imId;
	}
	/**
	 * @param imId the imId to set
	 */
	public void setImId(String imId) {
		this.imId = imId;
	}
	/**
	 * @return the cityCode
	 */
	public Integer getCityCode() {
		return cityCode;
	}
	/**
	 * @param cityCode the cityCode to set
	 */
	public void setCityCode(Integer cityCode) {
		this.cityCode = cityCode;
	}
	/**
	 * @return the nickname
	 */
	public String getNickname() {
		return nickname;
	}
	/**
	 * @param nickname the nickname to set
	 */
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	/**
	 * @return the gender
	 */
	public Long getGender() {
		return gender;
	}
	/**
	 * @param gender the gender to set
	 */
	public void setGender(Long gender) {
		this.gender = gender;
	}
	/**
	 * @return the distance
	 */
	public Long getDistance() {
		return distance;
	}
	/**
	 * @param distance the distance to set
	 */
	public void setDistance(Long distance) {
		this.distance = distance;
	}
    
}
