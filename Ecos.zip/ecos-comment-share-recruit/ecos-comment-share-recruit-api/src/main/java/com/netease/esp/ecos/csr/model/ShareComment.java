package com.netease.esp.ecos.csr.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class ShareComment implements Serializable{

	private static final long serialVersionUID = 1L;
	private Long commentId;
    private Long commentType;
    private Long commentTypeId;
    private Timestamp commentTimeStamp;
    private String content;
	private String avatarUrl;
	private Long fromId;
	private String fromNickname;
    private Long parentId;
	private String parentNIickName;
	
	public String getAvatarUrl() {
		return this.avatarUrl;
	}
	public void setAvatarUrl(String avatarUrl) {
		this.avatarUrl = avatarUrl;
	}
	public Long getFromId() {
		return this.fromId;
	}
	public void setFromId(Long fromId) {
		this.fromId = fromId;
	}
	public String getFromNickname() {
		return this.fromNickname;
	}
	public void setFromNickname(String fromNickname) {
		this.fromNickname = fromNickname;
	}
	public String getParentNIickName() {
		return this.parentNIickName;
	}
	public void setParentNIickName(String parentNIickName) {
		this.parentNIickName = parentNIickName;
	}
	public Long getCommentId() {
		return this.commentId;
	}
	public void setCommentId(Long commentId) {
		this.commentId = commentId;
	}
	public Long getCommentType() {
		return this.commentType;
	}
	public void setCommentType(Long commentType) {
		this.commentType = commentType;
	}
	public Long getCommentTypeId(){
		return this.commentTypeId;
	}
	public void setCommentTypeId(Long commentTypeId){
		this.commentTypeId = commentTypeId;
	}
    public String getContent(){
    	return this.content;
    }
    public void setContent(String content){
    	this.content = content;
    }
    public Timestamp getCommentTimeStamp(){
    	return this.commentTimeStamp;
    }
    public void setCommentTimeStampTime(Timestamp time){
    	this.commentTimeStamp = time;
    }
	public Long getParentId() {
		return this.parentId;
	}
	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}
	public String toString() {
		return "Comment [commentId=" + commentId + ", commentType=" + commentType + " , commentTypeId=" + commentTypeId + " ,"
	             + " content=" + content + " , commentTimeStamp=" + commentTimeStamp + " , " 
				   + " parentId=" + parentId + ", fromId=" + fromId + "," + " avatarUrl=" + avatarUrl + ","
				   + "fromNickname=" + fromNickname + "parentNIickName=" + parentNIickName + "]";
	}
}
