package com.netease.esp.ecos.csr.service;

import java.util.List;

import com.netease.esp.ecos.csr.model.Comment;
import com.netease.esp.ecos.csr.model.ShareComment;

public interface CommentService {

	public Comment creatComment(Long commentType,Long commentTypeId, String content, Long parentId,Long userId);
	public Comment getCommentContent(Long commentId);
	public Comment deleteComment(Long commentId);
	public String getUserNameByUserId(Long userId);
	public String getAvatarUrlByUserId(Long userId);
	public List<ShareComment> getComments(Long commentType, Long commentTypeId,Long pageSize,Long pages); 
	public Long getCommentNum(Long commentType, Long commentTypeId);
	
}
