package com.netease.esp.ecos.csr.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class Recruit implements Serializable{
	private static final long serialVersionUID = 1L;
	private Long recruitId;
	private Timestamp issueTimeStamp;
	private Double price;
	private String description;
	private Long shareId;
	private String priceUnit;
	private String coverUrl;
	private String title;
	private Long recruitType;
	private Long userId;
	private Long state;
	/**
	 * @return the recruitId
	 */
	public Long getRecruitId() {
		return recruitId;
	}
	/**
	 * @param recruitId the recruitId to set
	 */
	/**
	 * @return the issueTimeStamp
	 */
	public Timestamp getIssueTimeStamp() {
		return issueTimeStamp;
	}
	/**
	 * @param issueTimeStamp the issueTimeStamp to set
	 */
	public void setIssueTimeStamp(Timestamp issueTimeStamp) {
		this.issueTimeStamp = issueTimeStamp;
	}
	/**
	 * @return the price
	 */
	public Double getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(Double price) {
		this.price = price;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the shareId
	 */
	public Long getShareId() {
		return shareId;
	}
	/**
	 * @param shareId the shareId to set
	 */
	public void setShareId(Long shareId) {
		this.shareId = shareId;
	}
	/**
	 * @return the priceUnit
	 */
	public String getPriceUnit() {
		return priceUnit;
	}
	/**
	 * @param priceUnit the priceUnit to set
	 */
	public void setPriceUnit(String priceUnit) {
		this.priceUnit = priceUnit;
	}
	/**
	 * @return the coverUrl
	 */
	public String getCoverUrl() {
		return coverUrl;
	}
	/**
	 * @param coverUrl the coverUrl to set
	 */
	public void setCoverUrl(String coverUrl) {
		this.coverUrl = coverUrl;
	}
	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return the recruitType
	 */
	public Long getRecruitType() {
		return recruitType;
	}
	/**
	 * @param recruitType the recruitType to set
	 */
	public void setRecruitType(Long recruitType) {
		this.recruitType = recruitType;
	}
	/**
	 * @return the userId
	 */
	public Long getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	/**
	 * @return the state
	 */
	public Long getState() {
		return state;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(Long state) {
		this.state = state;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Recruit [recruitId=" + recruitId + ", issueTimeStamp=" + issueTimeStamp + ", price=" + price
				+ ", description=" + description + ", shareId=" + shareId + ", priceUnit=" + priceUnit + ", coverUrl="
				+ coverUrl + ", title=" + title + ", recruitType=" + recruitType + ", userId=" + userId + ", state="
				+ state + "]";
	}
}
