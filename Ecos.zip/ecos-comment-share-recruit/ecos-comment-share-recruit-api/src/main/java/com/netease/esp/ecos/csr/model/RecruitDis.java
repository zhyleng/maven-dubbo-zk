package com.netease.esp.ecos.csr.model;

public class RecruitDis extends Recruit {
	private static final long serialVersionUID = 1L;
	
	private Long distance;

	public Long getDistance() {
		return distance;
	}
	public void setDistance(Long distance) {
		this.distance = distance;
	}
	@Override
	public String toString() {
		return super.toString() + "RecruitDis [distance=" + distance + "]";
	}
	
}
