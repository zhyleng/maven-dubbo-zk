package com.netease.esp.ecos.csr.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class Share implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long shareId;
	private Long userId;
	private String coverUrl;
	private Timestamp time;
	private String title;
	private String content;
	private String imgIds;
	private Long totalImages;
	private Long state;
	private Long type;
	

	public void setShareId(Long shareId){
		this.shareId = shareId;
	}
	public Long getShareId(){
		return this.shareId;
	}
	public void setUserId(Long userId){
		this.userId = userId;
	}
	public Long getUserId(){
		return this.userId;
	}
	public void setCoverUrl(String coverUrl){
		this.coverUrl = coverUrl;
	}
	public String getCoverUrl(){
		return this.coverUrl;
	}
	public void setTime(Timestamp time){
		this.time = time;
	}
	public Timestamp getTime(){
		return this.time;
	}
	public void setTitle(String title){
		this.title =title;
	}
	public String getTitle(){
		return this.title;
	}
	public void setContent(String content){
		this.content = content;
	}
	public String getContent() {
		return this.content;
	}
	public void setImgIds(String imgIds){
		this.imgIds = imgIds;
	}
	public String getImgIds() {
		return this.imgIds;
	}
	public void setTotalImages(Long totalImages){
		this.totalImages = totalImages;
	}
	public Long getTotalImages(){
		return this.totalImages;
	}
	public Long getState() {
		return state;
	}
	public void setState(Long state) {
		this.state = state;
	}
	/**
	 * @return the type
	 */
	public Long getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(Long type) {
		this.type = type;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Share [shareId=" + shareId + ", userId=" + userId + ", coverUrl=" + coverUrl + ", time=" + time
				+ ", title=" + title + ", content=" + content + ", imgIds=" + imgIds + ", totalImages=" + totalImages
				+ ", state=" + state + ", type=" + type + "]";
	}
	
}
