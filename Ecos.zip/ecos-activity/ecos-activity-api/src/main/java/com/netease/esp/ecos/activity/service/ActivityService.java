package com.netease.esp.ecos.activity.service;

import java.util.List;

import com.netease.esp.ecos.activity.model.Activity;
import com.netease.esp.ecos.activity.model.SignUp;

public interface ActivityService {
	Activity getActivity(long id);
	List<Activity> getActivityList(Long provinceId, Long typeId, Long pageSize, Long pages);
	List<Activity> getActivityListByUserId(Long userId, Long pageSize, Long pages);
	Activity setActivity(Activity activity);
	Activity delActivity(long activityId);
	SignUp signUpActivity(long userId, long activityId);
	List<Long> getSignUpUserIdList(long activityId, Long pages, Long pageSize);
	List<Long> getSignUpUserIdList(long activityId);
	boolean isSignUp(long userId, long activityId);
	SignUp cancelSignUpActivity(Long userId, Long activityId);
}
