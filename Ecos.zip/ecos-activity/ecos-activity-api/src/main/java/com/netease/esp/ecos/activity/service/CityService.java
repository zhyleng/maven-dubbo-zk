package com.netease.esp.ecos.activity.service;

import java.util.List;

import com.netease.esp.ecos.activity.model.City;

public interface CityService {
	City getCity(int cityId);
	int setCity(City city);
	String getCityName(int cityId);
	int getCityProvinceId(int cityId);
	List<City> getCityList();
}
