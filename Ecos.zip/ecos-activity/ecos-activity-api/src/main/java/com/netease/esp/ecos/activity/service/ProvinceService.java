package com.netease.esp.ecos.activity.service;

import java.util.List;

import com.netease.esp.ecos.activity.model.Province;

public interface ProvinceService {

	public List<Province> getProvinceList();
}
