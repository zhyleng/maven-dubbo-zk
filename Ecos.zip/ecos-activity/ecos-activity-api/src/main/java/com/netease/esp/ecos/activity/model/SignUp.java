package com.netease.esp.ecos.activity.model;

import java.io.Serializable;

public class SignUp implements Serializable {
	private static final long serialVersionUID = 1L;
	private int id;
	private int userId;
	private int activityId;
	private int time;
	private int status;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getActivityId() {
		return activityId;
	}

	public void setActivityId(int activityId) {
		this.activityId = activityId;
	}

	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String toString() {
		return "User [id=" + id + ", userId=" + userId + ", activityId=" + activityId + "]";
	}
}
