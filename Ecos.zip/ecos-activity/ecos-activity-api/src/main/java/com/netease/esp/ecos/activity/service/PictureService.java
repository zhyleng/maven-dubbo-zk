package com.netease.esp.ecos.activity.service;

import com.netease.esp.ecos.activity.model.Picture;

public interface PictureService {
	Picture getPicture(long pictureId);
	Picture setPicture(Picture picture);
}
