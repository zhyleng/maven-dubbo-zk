package com.netease.esp.ecos.activity.model;

import java.util.List;

import com.netease.esp.ecos.activity.model.Activity;

public class ActivityDTO extends Activity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String cityName;
	private List<Long> signUpUserIdList;
	private List<String> signUpUserNameList; 
	private List<String> signUpUserPhotoUrlList;
	private boolean isSignUp;
	private String owerUrl;
	private boolean isStarted;
	private boolean isFinished;
	private String logoUrl;
	private String owerNickName;
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public List<Long> getSignUpUserIdList() {
		return signUpUserIdList;
	}
	public void setSignUpUserIdList(List<Long> signUpUserIdList) {
		this.signUpUserIdList = signUpUserIdList;
	}
	public List<String> getSignUpUserNameList() {
		return signUpUserNameList;
	}
	public void setSignUpUserNameList(List<String> signUpUserNameList) {
		this.signUpUserNameList = signUpUserNameList;
	}
	public List<String> getSignUpUserPhotoUrlList() {
		return signUpUserPhotoUrlList;
	}
	public void setSignUpUserPhotoUrlList(List<String> signUpUserPhotoUrlList) {
		this.signUpUserPhotoUrlList = signUpUserPhotoUrlList;
	}
	public boolean isSignUp() {
		return isSignUp;
	}
	public void setSignUp(boolean isSignUp) {
		this.isSignUp = isSignUp;
	}
	public String getOwerUrl() {
		return owerUrl;
	}
	public void setOwerUrl(String owerUrl) {
		this.owerUrl = owerUrl;
	}
	public boolean isStarted() {
		return isStarted;
	}
	public void setStarted(boolean isStarted) {
		this.isStarted = isStarted;
	}
	public boolean isFinished() {
		return isFinished;
	}
	public void setFinished(boolean isFinished) {
		this.isFinished = isFinished;
	}
	public String getLogoUrl() {
		return logoUrl;
	}
	public void setLogoUrl(String logoUrl) {
		this.logoUrl = logoUrl;
	}
	public String getOwerNickName() {
		return owerNickName;
	}
	public void setOwerNickName(String userNickName) {
		this.owerNickName = userNickName;
	}
}
