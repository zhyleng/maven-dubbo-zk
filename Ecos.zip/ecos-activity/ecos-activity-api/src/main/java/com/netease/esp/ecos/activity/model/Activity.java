package com.netease.esp.ecos.activity.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class Activity implements Serializable {
    
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private int userId;
    private String title;
    private String description;
    private int logoUrlId;
    private List<String> imgUrlList;
    private List<String> imgIds;
    private Timestamp startTime;
    private Timestamp endTime;
    private String dayStartTime;
    private String dayEndTime;
    private double fee;
    private int type;
    private String qq;
    private String qqGroup;
    private String phone;
    private String weibo;
    private int provinceId;
    private int cityCode;
    private String detailedAddress;
    private Timestamp createTime;
    private int status;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getLogoUrlId() {
		return logoUrlId;
	}
	public void setLogoUrlId(int logoUrlId) {
		this.logoUrlId = logoUrlId;
	}
	public List<String> getImgUrlList() {
		return imgUrlList;
	}
	public void setImgUrlList(List<String> imgUrlList) {
		this.imgUrlList = imgUrlList;
	}
	public Timestamp getStartTime() {
		return startTime;
	}
	public void setStartTime(Timestamp startTime) {
		this.startTime = startTime;
	}
	public Timestamp getEndTime() {
		return endTime;
	}
	public void setEndTime(Timestamp endTime) {
		this.endTime = endTime;
	}
	public String getDayStartTime() {
		return dayStartTime;
	}
	public void setDayStartTime(String dayStartTime) {
		this.dayStartTime = dayStartTime;
	}
	public String getDayEndTime() {
		return dayEndTime;
	}
	public void setDayEndTime(String dayEndTime) {
		this.dayEndTime = dayEndTime;
	}
	public double getFee() {
		return fee;
	}
	public void setFee(double fee) {
		this.fee = fee;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String getQq() {
		return qq;
	}
	public void setQq(String qq) {
		this.qq = qq;
	}
	public String getQqGroup() {
		return qqGroup;
	}
	public void setQqGroup(String qqGroup) {
		this.qqGroup = qqGroup;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getWeibo() {
		return weibo;
	}
	public void setWeibo(String weibo) {
		this.weibo = weibo;
	}
	public int getProvinceId() {
		return provinceId;
	}
	public void setProvinceId(int provinceId) {
		this.provinceId = provinceId;
	}
	public int getCityCode() {
		return cityCode;
	}
	public void setCityCode(int cityCode) {
		this.cityCode = cityCode;
	}
	public String getDetailAddress() {
		return detailedAddress;
	}
	public void setDetailAddress(String detailAddress) {
		this.detailedAddress = detailAddress;
	}
	public Timestamp getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Timestamp createTime) {
		this.createTime = createTime;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public List<String> getImgIds() {
		return imgIds;
	}
	public void setImgIds(List<String> imgIds) {
		this.imgIds = imgIds;
	}
    
}
