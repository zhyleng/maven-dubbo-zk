//package com.netease.esp.ecos.user.provider;
//
//import javax.annotation.Resource;
//
//import org.junit.Test;
//
//import com.alibaba.fastjson.JSON;
//import com.netease.esp.ecos.activity.model.Activity;
//import com.netease.esp.ecos.activity.service.ActivityService;
//import com.netease.esp.ecos.activity.service.CityService;
//
////@RunWith(SpringJUnit4ClassRunner.class)
////@ContextConfiguration(locations={"classpath:config/spring.xml", "classpath:config/dubbo.xml"})
//public class AppTest  {
//	@Resource
//	private ActivityService acitivtyService;
//	
//	@Resource
//	private CityService cityService;
//
//	@Test
//	public void testAddOpinion1() {
//		Activity a = acitivtyService.getActivity(1);
//		System.out.println(JSON.toJSON(a));
//		String cityName = cityService.getCityName(1);
//		System.out.println(cityName);
//		
//	}
//	
//}