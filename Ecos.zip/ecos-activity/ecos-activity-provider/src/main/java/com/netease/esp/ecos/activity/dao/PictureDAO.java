package com.netease.esp.ecos.activity.dao;

import org.springframework.dao.DataAccessException;

import com.netease.esp.ecos.activity.model.Picture;

public interface PictureDAO {
	Picture query(long id) throws DataAccessException;
	int insert(Picture picture) throws DataAccessException;
}
