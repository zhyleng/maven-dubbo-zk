package com.netease.esp.ecos.activity.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.netease.esp.ecos.activity.dao.ActivityDAO;
import com.netease.esp.ecos.activity.model.Activity;
import com.netease.esp.ecos.activity.model.SignUp;
import com.netease.esp.ecos.activity.service.ActivityService;

@Service("activityService")
public class ActivityServiceImpl implements ActivityService {

	private static Logger logger = Logger.getLogger(ActivityServiceImpl.class);
	
	@Autowired
	ActivityDAO activityDAO;

	@Override
	public Activity getActivity(long id) {
		Activity activity = null;
		try {
			activity = activityDAO.query(id);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return activity;
	}

	@Override
	public List<Activity> getActivityList(Long provinceId, Long typeId, Long pageSize, Long pages) {
		List<Activity> activities = null;
		try {
			if (provinceId == null && typeId == null) {
				activities = activityDAO.queryList(pageSize, pages);
			} else if (provinceId == null) {
				activities = activityDAO.queryListByType(typeId, pageSize, pages);
			} else if (typeId == null) {
				activities = activityDAO.queryListByProvince(provinceId, pageSize, pages);
			} else {
				activities = activityDAO.queryListByProvinceAndType(provinceId, typeId, pageSize, pages);
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return activities;
	}
	
	@Override
	public List<Activity> getActivityListByUserId(Long userId, Long pageSize, Long pages) {
		List<Activity> activities = null;
		try {
			activities = activityDAO.queryListByUserId(userId, pageSize, pages);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return activities;
	}

	@Override
	public Activity setActivity(Activity activity) {
		try {
			activityDAO.insert(activity);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return activity;
	}

	@Override
	@Transactional
	public Activity delActivity(long activityId) {
		Activity activity = null;
		try {
			activityDAO.delActivity(activityId);
			activity = activityDAO.query(activityId);
		} catch (Exception e) {
			logger.error(e.getMessage());
			return null;
		}
		return activity;
	}

	@Override
	public SignUp signUpActivity(long userId, long activityId) {
		SignUp signUp = null;
		try {
			signUp = activityDAO.querySignUp(userId, activityId);
			if (null == signUp) {
				activityDAO.insertSignUp(userId, activityId);
				signUp = activityDAO.querySignUp(userId, activityId);
			} else if (signUp.getStatus() == 0) {
				activityDAO.updateSignUp(userId, activityId, 1);
				signUp = activityDAO.querySignUp(userId, activityId);
			} else {
				signUp.setStatus(2);
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return signUp;
	}

	@Override
	public List<Long> getSignUpUserIdList(long activityId, Long pages, Long pageSize) {
		List<Long> userIdList = new ArrayList<Long>();
		try {
			userIdList = activityDAO.querySignUpUserIdListPages(activityId, pages, pageSize);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return userIdList;
	}
	
	@Override
	public List<Long> getSignUpUserIdList(long activityId) {
		List<Long> userIdList = new ArrayList<Long>();
		try {
			userIdList = activityDAO.querySignUpUserIdList(activityId);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return userIdList;
	}

	@Override
	public boolean isSignUp(long userId, long activityId) {
		try {
			SignUp signUp = activityDAO.querySignUp(userId, activityId);
			if (null == signUp) {
				return false;
			}
			return true;
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return false;
	}

	@Override
	public SignUp cancelSignUpActivity(Long userId, Long activityId) {
		SignUp signUp = null;
		try {
			signUp = activityDAO.querySignUp(userId, activityId);
			if (signUp != null) {
				activityDAO.updateSignUp(userId, activityId, 0);
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return signUp;
	}

}
