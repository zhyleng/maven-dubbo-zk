package com.netease.esp.ecos.activity.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.netease.esp.ecos.activity.dao.PictureDAO;
import com.netease.esp.ecos.activity.model.Picture;
import com.netease.esp.ecos.activity.service.PictureService;

@Service("pictureService")
public class PictureServiceImpl implements PictureService {
	
	@Autowired
	PictureDAO pictureDAO;

	@Override
	public Picture getPicture(long pictureId) {
		return pictureDAO.query(pictureId);
	}

	@Override
	public Picture setPicture(Picture picture) {
		pictureDAO.insert(picture);
		return picture;
	}
	
}
