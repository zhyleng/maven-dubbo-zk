package com.netease.esp.ecos.activity.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.netease.esp.ecos.activity.model.City;

public interface CityDAO {
	int insert(City city) throws DataAccessException;
	City query(long id) throws DataAccessException;
	List<City> queryCityList() throws DataAccessException;
}
