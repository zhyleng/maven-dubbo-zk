package com.netease.esp.ecos.activity.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.dao.DataAccessException;

import com.netease.esp.ecos.activity.model.Activity;
import com.netease.esp.ecos.activity.model.SignUp;


public interface ActivityDAO {
	int insert(Activity activity) throws DataAccessException;
	Activity query(long id) throws DataAccessException;
	List<Activity> queryListByProvinceAndType(@Param("provinceId")long provinceId, @Param("typeId")long typeId, @Param("pageSize")long pageSize, @Param("pages")long pages) throws DataAccessException;
	List<Activity> queryListByProvince(@Param("provinceId")long provinceId, @Param("pageSize")long pageSize, @Param("pages")long pages) throws DataAccessException;
	List<Activity> queryListByType(@Param("typeId")long typeId, @Param("pageSize")long pageSize, @Param("pages")long pages) throws DataAccessException;
	List<Activity> queryList(@Param("pageSize")long pageSize, @Param("pages")long pages) throws DataAccessException;
	List<Activity> queryListByUserId(@Param("userId")long userId, @Param("pageSize")long pageSize, @Param("pages")long pages) throws DataAccessException;
	void delActivity(@Param("activityId")long activityId) throws DataAccessException;
	int insertSignUp(@Param("userId")long userId, @Param("activityId")long activityId) throws DataAccessException;
	List<Long> querySignUpUserIdListPages(@Param("activityId")long activityId, @Param("pages")long pages, @Param("pageSize")long pageSize) throws DataAccessException;
	List<Long> querySignUpUserIdList(@Param("activityId")long activityId) throws DataAccessException;
	SignUp querySignUp(@Param("userId")long userId, @Param("activityId")long activityId) throws DataAccessException;
	void updateSignUp(@Param("userId")long userId, @Param("activityId")long activityId, @Param("status")long status) throws DataAccessException;
}
