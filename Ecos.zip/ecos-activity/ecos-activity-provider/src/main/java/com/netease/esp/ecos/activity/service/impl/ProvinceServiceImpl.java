package com.netease.esp.ecos.activity.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.netease.esp.ecos.activity.dao.ProvinceDAO;
import com.netease.esp.ecos.activity.model.Province;
import com.netease.esp.ecos.activity.service.ProvinceService;

@Service("provinceService")
public class ProvinceServiceImpl implements ProvinceService {

	@Autowired
	ProvinceDAO provinceDAO;
	
	@Override
	public List<Province> getProvinceList() {
		List<Province> provinceList = provinceDAO.queryProvinceList();
		return provinceList;
	}

}
