package com.netease.esp.ecos.activity.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.netease.esp.ecos.activity.model.Province;

public interface ProvinceDAO {
	List<Province> queryProvinceList() throws DataAccessException;
}
