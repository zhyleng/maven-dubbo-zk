package com.netease.esp.ecos.activity.app;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
	public static boolean close = false;
	public static void main(String[] args) {
		System.out.println("ecos-activity-provider 启动 ...");
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(new String[] {"classpath:config/spring.xml", "classpath:config/dubbo.xml"});
		context.start();
		System.out.println("ecos-activity-provider 运行中 ...");

		Runtime r = Runtime.getRuntime();
		System.out.println("free mem:" + r.freeMemory()/(1024*1024) + "M");
		System.out.println("total mem:" + r.totalMemory()/(1024*1024) + "M");
		System.out.println("max mem:" + r.maxMemory()/(1024*1024) + "M");
		// 为保证服务一直开着，利用输入流的阻塞来模拟
		while(!close) {
			
		}
		context.close();
	}
}
