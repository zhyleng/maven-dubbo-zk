package com.netease.esp.ecos.activity.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.netease.esp.ecos.activity.dao.CityDAO;
import com.netease.esp.ecos.activity.model.City;
import com.netease.esp.ecos.activity.service.CityService;

@Service("cityService")
public class CityServiceImpl implements CityService {
	
	@Autowired
	CityDAO cityDAO;

	@Override
	public City getCity(int cityId) {
		City city = cityDAO.query(cityId);
		return city;
	}

	@Override
	public int setCity(City city) {
		cityDAO.insert(city);
		return 0;
	}

	@Override
	public String getCityName(int cityId) {
		String cityName = this.getCity(cityId).getCityName();
		return cityName;
	}

	@Override
	public int getCityProvinceId(int cityId) {
		int provinceId = this.getCity(cityId).getProvinceId();
		return provinceId;
	}

	@Override
	public List<City> getCityList() {
		List<City> cityList = cityDAO.queryCityList();
		return cityList;
	}

}
